﻿using System;
using System.IO;
using System.Net;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using word= Microsoft.Office.Interop;
using System.Xml;
using Microsoft.Office.Core;



namespace wordExtraction
{
    public partial class TestPaper : Form
    {
        public TestPaper()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            linkLabel1.Text = "";
            
            string fpath;
              
            fpath = txtfile.Text;
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Word Files|*.doc;*.docx;";
            if (dialog.ShowDialog() == DialogResult.OK)
                
                txtfile.Text = dialog.FileName;
           
        }
        private void Caluculate(int i)
        {
            double pow = Math.Pow(i, i);
        }
        bool asisendfoundintypegrid = false;
        private void button2_Click(object sender, EventArgs e)
        {

            DialogResult resultmsg = MessageBox.Show("Please Close All Word Documents Before Click On Ok Button", "Confirm", MessageBoxButtons.OKCancel);
            
             if (resultmsg == DialogResult.OK)
            {
                Process[] word_apps = Process.GetProcessesByName("winword");
                foreach (var word_app in word_apps)
                {
                    word_app.Kill();
                }
          

            
            string fpath;
            string inputtext;
            //string ParaText;
            string filename = null;
            String tagcrssentence=string.Empty;
            filename = Path.GetFileName(txtfile.Text);
            if (filename == "" || filename == null)
            {
                
            }
            else
            {

            fpath = txtfile.Text;
            string fname = Path.GetFileName(fpath);
            string dirpath = Path.GetDirectoryName(fpath);
            bool macrocomplete = false;

            string foutputfile=string.Empty;
            
            File.SetAttributes(fpath, FileAttributes.Normal);
            word.Word.Application app = new word.Word.Application();
            word.Word.Document doc;
            object missing = Type.Missing;
            object readOnly =false;
           // object 
            
            doc = app.Documents.Open(fpath, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
            
          
            doc.Activate();
           inputtext = doc.Content.Text;
            asispreprocess(doc, app);
            inputtext = doc.Content.Text;
            try
            {
                macrocomplete = true;
                bbpdconverter(app);
               // RunMacro(app, new object[] { "bbpdconverter" });
                fpath = fpath.Replace(Path.GetFileNameWithoutExtension(fpath), "converted" + Path.GetFileNameWithoutExtension(fpath));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please click ok to continue. This will not affect the conversion."+Environment.NewLine+"There was some difficulty in converting formattings.","Word macro");
                macrocomplete = false;
            }
            doc.Close(word.Word.WdSaveOptions.wdDoNotSaveChanges);
            app.Quit();
            GC.Collect();
            GC.WaitForPendingFinalizers();
            
            app = new word.Word.Application();
            doc = app.Documents.Open(fpath, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
            

            doc.Activate();
            foreach (word.Word.Paragraph objparagraph in doc.Paragraphs)
            {
                int TRUE_CODE = -1;
                bool bold_found = false;
                bool italicfound = false;
                bool colorfound = false;
                bool underlinefound = false;
                bool superscriptfound = false;
                bool subscriptfound = false;
                bool scriptedtextend = false;

                /*Microsoft.Office.Interop.Word.Range rWords = objparagraph.Range;
                foreach (Microsoft.Office.Interop.Word.Range format_word in rWords.Words)
                {
                    // sequence of if is important for closing the tags if word is bold and italics together
                    if (format_word.Text.StartsWith("#") && format_word.Text.EndsWith("#"))
                    {
                        break;
                    }
                    else if (format_word.Text.ToLower().Contains("\r".ToLower()) || format_word.Text.ToLower().Contains("\r\n".ToLower()) || format_word.Text.ToLower().Contains("\n\r".ToLower()) || format_word.Text.ToLower().Contains("\t".ToLower()) || format_word.Text.ToLower().Contains("\n".ToLower()) || format_word.Text.ToLower().Contains("\v".ToLower()) || (format_word.Text.ToLower() == " ") || (format_word.Text.ToLower() == ""))
                    {
                        break;
                    }
                    else
                    {
                        if (format_word.Bold == TRUE_CODE)
                        {
                            // handle bold cse
                            format_word.InsertBefore("<span style='font-weight:bold;'>");
                            format_word.InsertAfter("</span>");
                            bold_found = true;
                        }
                        if (format_word.Italic == TRUE_CODE)
                        {
                            // handle italic case
                            format_word.InsertBefore("<span style='font-style:italic;'>");
                            format_word.InsertAfter("</span>");
                            italicfound = true;
                        }
                        string color = format_word.Font.Color.ToString();

                        if (!color.ToString().ToLower().Contains("black") && !color.ToString().ToLower().Contains("wdColorAutomatic".ToLower()))
                        {
                            var getcolor_index = format_word.Font.ColorIndex.ToString();
                            format_word.InsertBefore("<span style='color:" + getcolor_index.Replace("wd", "") + ";'>");
                            format_word.InsertAfter("</span>");
                            colorfound = true;
                        }

                        var underline = format_word.Underline;
                        if (underline != Microsoft.Office.Interop.Word.WdUnderline.wdUnderlineNone)
                        {
                            format_word.InsertBefore("<span style='text-decoration:underline;'>");
                            format_word.InsertAfter("</span>");
                            underlinefound = true;
                        }

                        var xml_of_word = format_word.get_XML();
                        string[] checkscripts = superorsubscript(xml_of_word);
                        if (checkscripts[0] != "novalue")
                        {
                            // find which part of text is scripted
                            var scriptvalue = "sup";
                            if (checkscripts[0] == "superscript")
                            {
                                scriptvalue = "sup";
                                superscriptfound = true;
                            }
                            else if (checkscripts[0] == "subscript")
                            {
                                scriptvalue = "sub";
                                subscriptfound = true;
                            }
                            var scripted_part = checkscripts[1];
                            if (scripted_part == format_word.Text)
                            {
                                format_word.InsertBefore("<" + scriptvalue + ">");
                                format_word.InsertAfter("</" + scriptvalue + ">");
                            }
                            else
                            {
                                // part of format_word is scripted
                                var split_format_word = format_word.Text.Replace(scripted_part, "<" + scriptvalue + ">" + scripted_part + "</" + scriptvalue + ">");
                                format_word.Text = split_format_word;
                            }
                        }
                        format_word.Select();
                        app.Selection.ClearFormatting();
                    }
                }*/
            }


            // For Asis
            List<word.Word.Range> TablesRanges = new List<word.Word.Range>();
            for (int iCounter = 1; iCounter <= doc.Tables.Count; iCounter++)
            {
                word.Word.Range TRange = doc.Tables[iCounter].Range;
                TablesRanges.Add(TRange);
                int parentcounter = 1;
                //var parent = doc.Tables[iCounter].Range.Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 1).Text; //Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 2).Text;
                var parent = doc.Tables[iCounter].Range;
                var asisparent_result = AsisParent(parent, 1);
                if (asisparent_result)
                {
                    // asis = convert to tables
                    parentcounter = 1;
                    int rowcount = doc.Tables[iCounter].Rows.Count;
                    int columncount = doc.Tables[iCounter].Columns.Count;
                    for (var rowcounter = 1; rowcounter <= rowcount; rowcounter++)
                    {
                        for (var columncounter = 1; columncounter <= columncount; columncounter++)
                        {
                            if (rowcounter == 1 && columncounter == 1)
                            {
                                doc.Tables[iCounter].Cell(rowcounter, columncounter).Range.InsertBefore("<table class='asistable'><tr><td>");
                            }
                            else if (columncounter == 1)
                            {
                                doc.Tables[iCounter].Cell(rowcounter, columncounter).Range.InsertBefore("<tr><td>");
                            }
                            else
                            {
                                doc.Tables[iCounter].Cell(rowcounter, columncounter).Range.InsertBefore("<td>");
                            }
                            doc.Tables[iCounter].Cell(rowcounter, columncounter).Range.InsertAfter("</td>");
                        }
                        doc.Tables[iCounter].Cell(rowcounter, columncount).Range.InsertAfter("</tr>");
                    }
                    doc.Tables[iCounter].Cell(rowcount, columncount).Range.InsertAfter("</table>");
                    string content = doc.Tables[iCounter].ConvertToText(word.Word.WdSeparatorType.wdSeparatorHyphen).Text;
                }
            }
           
           
            try
            {
                var tables = doc.Content.Tables;
                var tablecount = tables.Count;
                int crosswordid = 1;
                List<word.Word.Range> crossword_TablesRanges = new List<word.Word.Range>();
                for (int iCounter = 1; iCounter <= doc.Tables.Count; iCounter++)
                {
                    word.Word.Range TRange = doc.Tables[iCounter].Range;
                    crossword_TablesRanges.Add(TRange);
                    bool singlelettercrossword = true;
                    List<bool> singlelettercrossword_average = new List<bool>();
                    //var parent = doc.Tables[iCounter].Range.Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 1).Text;
                    var parent = doc.Tables[iCounter].Range;
                    bool typegridparent_result = typegridparent(parent, 1);
                    asisendfoundintypegrid = false;
                    if (typegridparent_result)
                    {
                        word.Word.Table ihi = doc.Content.Tables[iCounter];
                        var rows = ihi.Rows.Count;
                        var columns = ihi.Columns.Count;
                        string[,] items = new string[100, 100];
                        string itemsStr = "[";
                        for (int i = 1; i <= rows; i++)
                        {
                            itemsStr += "[";
                            for (int j = 1; j <= columns; j++)
                            {
                                var cell = ihi.Cell(i, j);
                                var cell1 = cell.Range;
                                var cell2 = cell1.Text.Replace("\r\a", "");
                                cell2 = cell2.Replace("\r\n", "");
                                cell2 = cell2.Replace("\n", "");
                                cell2 = cell2.Replace("\r", "");
                                cell2 = cell2.Replace("\a", "");
                                cell2 = cell2.Replace("\v", "");
                                cell2 = cell2.Replace("\f\r", "");
                                cell2 = cell2.Replace("\t", "");
                                if (cell2.ToLower().Contains("[") && cell2.ToLower().Contains("]"))
                                {
                                    string splitinput = (cell2.Split(']'))[0];
                                    if (splitinput.ToLower().Contains("i"))
                                    {
                                        // cell2 is answer here
                                        // Preprocess cell2 here
                                        IniFile gridprocess = new IniFile();
                                         cell2 = gridprocess.preprocess(cell2);

                                        if (cell2.Contains("*"))
                                        {
                                            string ansstar = "<span style='visibility:hidden' class='splitstar'>*</span>";
                                            cell2 = cell2.Replace("*", ansstar);
                                        }
                                        if (cell2.Contains("&"))
                                        {
                                            cell2 = cell2.Replace("&", "<span style='color: black;' class='splitor'>OR</span>");
                                        }

                        

                                    }
                                }
                                if (cell2 != "")
                                {
                                    items[i, j] = cell2;
                                    cell2 = trimcellstring(cell2);
                                    if (j != columns)
                                    {
                                        itemsStr += '"' + cell2.Trim() + '"' + ",";
                                    }
                                    else
                                    {
                                        itemsStr += '"' + cell2.Trim() + '"';
                                    }
                                    string letterafterbracket = "";
                                    if (cell2.Contains("]"))
                                    {
                                        letterafterbracket = (cell2.Split(']'))[1];
                                    }
                                    else
                                    {
                                        letterafterbracket = cell2;
                                    }
                                    letterafterbracket = letterafterbracket.Trim();
                                    if (letterafterbracket.Length == 1)
                                    {
                                        singlelettercrossword_average.Add(true);
                                    }
                                    else if (letterafterbracket.Length == 0)
                                    {

                                    }
                                    else
                                    {
                                        singlelettercrossword_average.Add(false);
                                    }
                                }
                                else
                                {
                                    items[i, j] = "0";
                                    if (j != columns)
                                    {
                                        itemsStr += "0" + ",";
                                    }
                                    else
                                    {
                                        itemsStr += "0";
                                    }
                                }
                            }
                            if (i != rows)
                            {
                                itemsStr += "],";
                            }
                            else
                            {
                                itemsStr += "]";
                            }
                        }
                        // Final array of crossword
                        itemsStr += "]";
                        if (singlelettercrossword_average.Contains(false))
                        {
                            // Pick Sentence crossword
                            singlelettercrossword = false;
                        }
                        else
                        {
                            // Single letter crossword
                            singlelettercrossword = true;
                        }
                        // pick template and based on singlelettercrossword and write
                        //path =
                        if (singlelettercrossword)
                        {
                            string inctm;
                            string crssingle = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\crosssingle.txt";
                            String tagcrssingle = File.ReadAllText(crssingle);
                            inctm = "incrementor";
                            string arcrs = "array";
                            tagcrssingle = tagcrssingle.Replace(inctm, crosswordid.ToString());
                            tagcrssingle = tagcrssingle.Replace(arcrs, itemsStr);
                            doc.Tables[iCounter].Range.Previous().Previous().InsertParagraphAfter();
                            doc.Tables[iCounter].Range.Previous().Previous().InsertParagraphAfter();
                            doc.Tables[iCounter].Range.Previous().Previous().Previous().InsertAfter(tagcrssingle);
                            doc.Tables[iCounter].Delete();
                            iCounter--;
                            // single letter crossword template path
                        }
                        else {
                            string inct;
                            
                            string crssentence = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\crosssentence.txt";
                            tagcrssentence = File.ReadAllText(crssentence);
                            inct = "incrementor";
                            string arcrs="array";
                            tagcrssentence = tagcrssentence.Replace(inct, crosswordid.ToString());
                            tagcrssentence = tagcrssentence.Replace(arcrs, itemsStr);
                            //File.AppendAllText(dirpath + "\\" + foutputfile, tagcrssentence);
                            // sentence crossword template path
                            //doc.Tables[iCounter].Range.InsertBefore(tagcrssentence);
                            //doc.Tables[iCounter].Range.Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 1).InsertParagraphAfter();
                            //doc.Tables[iCounter].Range.Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 1).InsertAfter(tagcrssentence);
                            //doc.Tables[iCounter].Range.Delete();
                            doc.Tables[iCounter].Range.Previous().Previous().InsertParagraphAfter();
                            doc.Tables[iCounter].Range.Previous().Previous().InsertParagraphAfter();
                            doc.Tables[iCounter].Range.Previous().Previous().Previous().InsertAfter(tagcrssentence);
                            doc.Tables[iCounter].Delete();
                            iCounter--;
                        }
                        // Question id puzzle(incrementer)
                        // Answer id puzzelanswer(incrementer)
                        // Global int crosswordid = 1;
                        // write in the file
                        // 1. change incrementor with crosswordid
                        // 2. change array with itemsStr
                        crosswordid++;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            IniFile wd = new IniFile();
            //wd.wordtohtml(doc);

            // for listed numbers
            //object n = 1;
            //Microsoft.Office.Interop.Word.ListTemplate template =
            //    app.ListGalleries[Microsoft.Office.Interop.Word.WdListGalleryType.wdNumberGallery].ListTemplates.get_Item(ref n);
            //Microsoft.Office.Interop.Word.ListLevel level = template.ListLevels[1];
            //level.TrailingCharacter = Microsoft.Office.Interop.Word.WdTrailingCharacter.wdTrailingSpace;
            //level.Font.Bold = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.Italic = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.StrikeThrough = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.Subscript = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.Superscript = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.Shadow = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.Outline = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.Emboss = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.Engrave = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.AllCaps = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.Hidden = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.Underline = Microsoft.Office.Interop.Word.WdUnderline.wdUnderlineNone;
            //level.Font.Color = Microsoft.Office.Interop.Word.WdColor.wdColorAutomatic;
            //level.Font.Size = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.Font.Animation = Microsoft.Office.Interop.Word.WdAnimation.wdAnimationNone;
            //level.Font.DoubleStrikeThrough = (int)Microsoft.Office.Interop.Word.WdConstants.wdUndefined;
            //level.LinkedStyle = "";

            //template.Name = "";
            //object bContinuePrevList = false;
            //object applyTo = Microsoft.Office.Interop.Word.WdListApplyTo.wdListApplyToSelection;
            //object defBehavior = Microsoft.Office.Interop.Word.WdDefaultListBehavior.wdWord10ListBehavior;
            //doc.Select();

            var lists = doc.Lists;
            //for (int i = 1; i <= lists.Count; i++)
            //{
            //    lists[i].Range.Select();

            //    app.Selection.Range.ListFormat.ConvertNumbersToText();
            //    app.Selection.Range.ListFormat.ApplyListTemplateWithLevel(
            //    template, ref bContinuePrevList,
            //    ref applyTo, ref defBehavior, ref missing);
            //    //lists[i].ConvertNumbersToText();
            //}
            for (int i = lists.Count; i >= 1; i--)
            {
                lists[i].ConvertNumbersToText();
            }
            string newtext = Clipboard.GetText(TextDataFormat.UnicodeText);
            //doc.SaveAs2(Path.GetDirectoryName(fpath) + "/" + "new.docx");
            inputtext = doc.Content.Text;
            
            // for listed numbers
             //doc.Select();
             //app.Selection.Copy();
             //inputtext = Clipboard.GetText(TextDataFormat.Text);
             //inputtext = inputtext.Replace("\r\n", "\r");
            //-------------------------------------//
            string asisstr = asisconverter(inputtext);
            inputtext = asisstr;


            
            doc.Close(word.Word.WdSaveOptions.wdDoNotSaveChanges);
            app.Quit();
            if (macrocomplete) {
                try
                {
                    File.Delete(fpath);
                }
                catch (Exception)
                {
                    
                    throw;
                }
            }

            Marshal.FinalReleaseComObject(doc);
            IniFile docprocess = new IniFile();
            string outputtext = docprocess.preprocess(inputtext);

           

            string inipath = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\settings.ini";
            IniFile ini = new IniFile(inipath);
            string inimetadata = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\metadata.ini";
            IniFile inimeta = new IniFile(inimetadata);
            string linkini= System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\link.ini";
            
            string metacount = inimeta.readinimetadata("count", "Metacount");
            int mcount = 0;
            mcount = Convert.ToInt16(metacount);
           
            string sec1;
            string secini;
            string linefib;


          
            //*****************************initags**********************


            string seccount = ini.readinitag("sectioncount", "count");
            int scount = 0;
            scount = Convert.ToInt16(seccount);
            
            string tag1 = string.Empty;
            string tag2 = string.Empty;
            string tag3 = string.Empty;
            string tag4 = string.Empty;
            string tag5 = string.Empty;
            string tag6 = string.Empty;
            string tag7 = string.Empty;
            string tag8 = string.Empty;
            string tag9 = string.Empty;
            string tag10 = string.Empty;
            string tag11 = string.Empty;
            string tag12 = string.Empty;
            string tag13 = string.Empty;
            string tag14 = string.Empty;
            int instcount = 0;
            int fiblineno = 0;
            int tflineno = 0;
            int saqlineno = 0;
            int vsaqlineno = 0;
            int mcqlineno = 0;
            int laqlineno = 0;
            int linecount = 0;
            int multlineno = 0;
            bool fibcheck = false;
            bool tfcheck = false;
            bool saqcheck = false;
            bool vsaqcheck = false;
            bool vsaqchkcheck = false;
            bool mcqcheck = false;
            bool imgcheck = false;
            bool matchcheck = false;
            bool mediascheck = false;
            bool mediavcheck = false;
            bool mediaancheck = false;
            bool mcqmultcheck= false;
            bool gridcheck = false;
            bool Assignment2 = false;
            bool assignment3 = false;
            bool laqcheck = false;
            bool leftmatch = false;
            bool rightmatch = false;
            bool thirdcolmatch = false;
            bool headercheck = false;
            bool assigncheck = false;
            bool asischeck = false;
            bool mat2 = false;
            bool mat3 = false;
            bool gltag = false;
            bool gloverlookendstop = false;
            bool gloverlookcase = false;
            bool alwaysmatheval = false;
            string[] leftcol = new string[35];
            int ileft = 0;
            string[] rightcol = new string[35];
            int iright = 0;
            int threecol = 0;
            string[] thirdcol = new string[55];
            string[] leftcolstr;
            string[] rightcolstr;
            string[] matchcol = new string[35];
            int mcqmulright=0;
            int mcqmulques = 1;
            string[] mcqmult= new string[50];
            int mcqmore = 0;
            int mcqmoreques = 1;
            string[] mcqmopt = new string[50];
            int colcount = 0;
            int jk;
            int col = 0;
            string classnum = "1";
            string chapnum = "1";
            string assignnum="1";
            string matchanswer;
            string newmatchcolumnstag = "";
            string headchapter=string.Empty;
            string headsubject=string.Empty;
            bool timegiven = false;
            string headerlines = string.Empty;
            string loadfile = string.Empty;
            bool previouslineassignment = false;
            string subject = string.Empty;
            string asisline = string.Empty;
            string globaltag = string.Empty;
            string bxrm = string.Empty;
            string beststr = string.Empty;
            for (int i = 1; i <= scount; i++)
            {

                sec1 = ini.readinitag("SectionInfo", "section" + i);
               
                if (sec1 == "#Type-FIB#")
                {
                    tag1 = sec1;
                    //sec1.ToLower();

                }
                if (sec1 == "#Type-TF#")
                {
                    tag2 = sec1;
                }
                if (sec1 == "#Type-SAQ#")
                {
                    tag3 = sec1;
                }
                if (sec1 == "#Type-ImageBased#")
                {
                    tag4 = sec1;
                }
                if (sec1 == "#Type-Match#")
                {
                    tag5 = sec1;
                }
                if (sec1 == "#Type-MCQ#")
                {
                    tag6 = sec1;
                }
                if (sec1 == "#Type-LAQ#")
                {
                    tag7 = sec1;
                }
                if (sec1 == "#Type-VSAQ#")
                {
                    tag8 = sec1;
                }
                if (sec1 == "#Media-S#")
                {
                    tag9 = sec1;
                }
                if (sec1 == "#Media-V#")
                {
                    tag10= sec1;
                }
                if (sec1 == "#Media-A#")
                {
                    tag11 = sec1;
                }
                if (sec1 == "#Type-MCQ-MultiRight#")
                {
                    tag12 = sec1;
                }
                if (sec1 == "#Type-VSAQ-CHECK#")
                {
                    tag13 = sec1;
                }
                if (sec1 == "#Type-Grid#")
                {
                    tag14 = sec1;
                }
                
            }
            
            string[] Doclines = outputtext.Split(new[] { "\r\n" }, StringSplitOptions.None);//Entire docfile data splitting by line by line

           
            
            // File.WriteAllText(dirpath + "\\" + foutputfile, "<form>" + Environment.NewLine);

            // splitting each line of a document line by line using line break
            foreach (string lines in Doclines)
            {

                if(lines.ToLower().StartsWith("#always"))
                {
                    globaltag += lines;
                    gltag = true;

                }
                if (lines.ToLower().StartsWith("#end"))
                {
                    //globaltag += lines;
                    gltag = false;
                    globaltag = "";
                    

                }


                if (lines.ToLower().Contains("#asis#")&&(lines.ToLower().Contains("#asisend#")))
                {
                    string asisboth;
                    asisboth = lines;
                    asisboth = asisboth.ToLower().Replace("#asis#", "");
                    asisboth = asisboth.ToLower().Replace("#asisend#", "");
                    File.AppendAllText(dirpath + "\\" + foutputfile, asisboth);
                
                }
                 
               
                else if (lines.ToLower().Contains("#asis#"))
                {
                    asischeck = true;
                    asisline = lines;
                    asisline = asisline.ToLower().Replace("#asis#", "");
                   /*if(asisline.ToLower().EndsWith("#asisend#"))
                    {
                        asischeck = false;
                    }*/
                    //asisline = asisline.ToLower().Replace("#asisend#", "");
                    File.AppendAllText(dirpath + "\\" + foutputfile, asisline);
                }

                else if (lines.ToLower().Contains("#asisend#"))
                {

                    asischeck = false;
                    string asisendline;
                    asisendline = lines;

                    asisendline = asisendline.ToLower().Replace("#asisend#", "");
                    File.AppendAllText(dirpath + "\\" + foutputfile, asisendline);
                } 
               
                if ((asischeck) && !(lines.ToLower().Contains("#asis#")))
                {
                    File.AppendAllText(dirpath + "\\" + foutputfile, lines);

                }
                 

                
                /*if(lines.Contains("Pix"))
                {
                    string picline = lines;
                    IniFile loadimg = new IniFile();
                   // loadimg.getimagename(lines);
                    string oldName = "#Pix#";
                    string imagename = loadimg.getimagename(picline);
                    string newName = @"<img src='../../../../../../../../../images/" + classnum + "/" + subject + "/" + imagename + @".jpg'>";
                    System.Text.RegularExpressions.Regex regex = new Regex(oldName, RegexOptions.IgnoreCase);
                    picline = regex.Replace(picline, newName);
                    lines= picline;
                }*/

                string alllines = lines.TrimEnd();
                if (lines.StartsWith("#Type"))
                {
                    lines.ToLower();
                }
                if (alllines.StartsWith("#")) {

                      if ((alllines != tag3))
                      {
                          if (saqcheck)
                          {
                             /* if (!alllines.StartsWith("#Instruction") && (!alllines.StartsWith("#Pix#")))
                              {
                                  saqcheck = false;
                              }*/
                          }
                          
                      }
                      if ((alllines != tag6))
                      {
                          if (mcqcheck)
                          {
                              if (!alllines.StartsWith("#Instruction"))
                              {
                                  mcqcheck = false;
                                  mcqlineno = 0;
                              }
                          }

                      }
                      if ((alllines != tag7))
                      {
                          if (laqcheck)
                          {
                             /* if (!alllines.StartsWith("#Instruction"))
                              {
                                  laqcheck = false;
                              }*/
                          }

                         }
                      if ((alllines != tag8))
                      {
                          if (vsaqcheck)
                          {
                             /* if ((!alllines.StartsWith("#Instruction")) && (!alllines.StartsWith("#Instruction")))
                              {
                                  vsaqcheck = false;
                              }*/
                          }
                          
                      }
                      if (alllines != tag13)
                      {

                          
                         /* if (vsaqchkcheck)
                          {
                              if ((!alllines.StartsWith("#Instruction")) && (!alllines.ToLower().StartsWith("#asis#")))
                              {
                                  vsaqchkcheck = false;
                              }
                          }*/

                      }
                      if ((alllines != tag12))
                      {
                          if (mcqmultcheck)
                          {
                             /* if (!alllines.StartsWith("#Instruction")&&(!alllines.StartsWith("#A#")))
                              {
                                  mcqmultcheck = false;
                                  multlineno = 0;
                              }*/
                          }

                      }
                      if ((alllines != tag6))
                      {
                          if (mcqcheck)
                          {
                              if (!alllines.StartsWith("#Instruction") && (!alllines.StartsWith("#A#")))
                              {
                                  mcqcheck = false;
                              }
                          }

                      }
                      
                      
                      if ((alllines != tag14))
                      {
                          if (gridcheck)
                          {
                            /*  if (!alllines.StartsWith("#Instruction") && (!alllines.ToLower().StartsWith("#asis#")))
                              {
                                  gridcheck = false;
                              }*/
                          }

                      }
                }
               
                if (lines.Contains("#Class#"))
                {
                    int cl = lines.IndexOf("#Class#");
                    string cls = lines.Substring(lines.IndexOf("#Class#"));
                    classnum = cls.Substring(7);
                    classnum = classnum.Trim();
                    
                }

                if (lines.Contains("#Subject#"))
                {
                    int posline = lines.IndexOf("t#");
                    subject = lines.Substring(posline + 2);
                    subject = subject.Trim();
                    
                    string tagmetadata = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\headersubjectname.txt";
                    String metadetails = File.ReadAllText(tagmetadata);
                    string subnamesearch = "Type subject name here";
                    metadetails = metadetails.Replace(subnamesearch, subject + " for Class " + classnum);
                    //File.AppendAllText(dirpath + "\\" + foutputfile, metadetails);
                    headsubject = metadetails;
                }

                if (lines.Contains("#ChapterName#"))
                {
                    int poschptno = lines.IndexOf("r#");
                    string chaptno = lines.Substring(poschptno + 3);
                    int posname = lines.IndexOf("e#");
                    string chaptname = lines.Substring(posname + 2);
                    string tagmetadata = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\headerchaptername.txt";
                    String metadetails = File.ReadAllText(tagmetadata);
                    string chaptername = "Type chapter number and name here";

                    //metadetails = metadetails.Replace(chapterno, chaptno);
                    //string chaptername = ""Type chapter number and type chapter name here";
                    metadetails = metadetails.Replace(chaptername, chapnum + ". " + chaptname);

                    //File.AppendAllText(dirpath + "\\" + foutputfile, metadetails + Environment.NewLine);
                    headchapter = metadetails;
                }

                //For each assignment there must be a header part with subject and topic details and a footer 
                //part with submit option.Document is splitted to each assignment and will create a text file for each assignment
                //assigncheck is a flag for writing header and footer. flag will be true upto next assignment. whent next assignment comes it will write
                //footer and flag will become false.
                if ((assigncheck == true) && (lines.Contains("#AssignmentNo#")))
                {
                      
                string submit = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsubmit.txt";
                string submitstr = File.ReadAllText(submit);
                File.AppendAllText(dirpath + "\\" + foutputfile, "</div>");
                File.AppendAllText(dirpath + "\\" + foutputfile, submitstr);
                
                IniFile loadtxt = new IniFile();
                string resultloadtxt = loadtxt.uploadtextfile(dirpath + "\\" + foutputfile, classnum,subject);
                loadfile = Path.GetFileNameWithoutExtension(foutputfile);
                loadfile = loadfile + ".php";
                //linkLabel1.Text = "";
                if (resultloadtxt == "success")

                {
                    string sitelink = inimeta.readinimetadata("count", "Metacount");
                    string site = ini.readlink("LinkInfo", "Link");
                    string weblink = site + "/forms/" + classnum.ToLower() + "/" + subject.ToLower() + "/";
                   
                    //MessageBox.Show("Uploaded Successfully : Please Go To link :https://halantbooks.com/bbpd/upload/forms/" + loadfile);
                    MessageBox.Show("Uploaded Successfully : Please Go To link " + weblink +loadfile);
                    
                    string finallink = weblink + loadfile + Environment.NewLine + Environment.NewLine;
                    linkLabel1.Text+=finallink;
                    //linkLabel1.Links.Add("https://halantbooks.com/bbp + loadfile);
                    //linkLabel1.Links.Add("https://halantbooks.com/bbpd/upload/forms/" + loadfile;
                }
                else
                    MessageBox.Show("Uploading Failed");
                   // string lkname;
                    //lkname = ini.readlink("LinkInfo", "Link");
                    //string linkname="https://halantbooks.com/bbpd/upload/forms/" + loadfile;
                    //string linkname = lkname + loadfile;
                    //linkLabel1.Text = linkname;
                    //linkLabel1.LinkClicked
                    
                    string[] alllinks;

                    //linkLabel1.Links.Add(linkname);
                    assigncheck = false;
                    globaltag = "";
                
                    //create new text file
                    // write subject header headsubject
                    // write chapter header headchapter
                }
                
                string tm = string.Empty;
               /*  if (lines.Contains("#Free#"))
                {
                    previouslineassignment = true;
                }*/
                if (lines.Contains("#Time#"))
                {
                    int tme = lines.IndexOf("e#");
                    tm= lines.Substring(tme + 2);
                    timegiven = true;
                    //string tagtime = foutputfile;
                    //String tagtimedata = File.ReadAllText(tagtime);
                    //string timerep = "Type Time";
                    //tagtimedata = tagtimedata.Replace(timerep, tm);
                    //File.WriteAllText(dirpath + "\\" + foutputfile, tagtimedata);
                }
                if (timegiven) {
                    if (previouslineassignment)
                    {
                        String assignmentfilename = Path.GetFileNameWithoutExtension(fname) + assignnum;
                        foutputfile = assignmentfilename + ".txt";
                        //foutputfile = Path.ChangeExtension(fname, ".txt");
                        if (File.Exists(dirpath + "\\" + foutputfile))
                        {
                            File.Delete(dirpath + "\\" + foutputfile);
                        }
                        File.AppendAllText(dirpath + "\\" + foutputfile, headsubject);
                        string timerep = "00";
                        string finalheader = headchapter.Replace(timerep, tm);
                        File.AppendAllText(dirpath + "\\" + foutputfile, finalheader + Environment.NewLine);
                        string tagassignt = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagassignment.txt";
                        String tagassigntdata = File.ReadAllText(tagassignt);
                        String assigntnum = "Type Assignment No";
                        tagassigntdata = tagassigntdata.Replace(assigntnum, "Assignment " + assignnum);
                        File.AppendAllText(dirpath + "\\" + foutputfile, tagassigntdata);
                        timegiven = false;
                        previouslineassignment = false;
                    }
                    else {
                        timegiven = false;
                    }
                }
                else if (previouslineassignment) { 
                    String assignmentfilename = Path.GetFileNameWithoutExtension(fname) + assignnum;
                    foutputfile = assignmentfilename + ".txt";
                    //foutputfile = Path.ChangeExtension(fname, ".txt");
                    if (File.Exists(dirpath + "\\" + foutputfile))
                    {
                        File.Delete(dirpath + "\\" + foutputfile);
                    }
                    File.AppendAllText(dirpath + "\\" + foutputfile, headsubject);
                    File.AppendAllText(dirpath + "\\" + foutputfile, headchapter + Environment.NewLine);
                    string tagassignt= System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagassignment.txt";
                    String tagassigntdata = File.ReadAllText(tagassignt);
                    String assigntnum = "Type Assignment No";
                    tagassigntdata = tagassigntdata.Replace(assigntnum, "Assignment " + assignnum);
                    File.AppendAllText(dirpath + "\\" + foutputfile, tagassigntdata);
                    previouslineassignment = false;
                }
                if (lines.Contains("#AssignmentNo#"))
                {
                    previouslineassignment = true;
                    string assn = "#AssignmentNo#";
                    int assnt = assn.Length;
                    int asn = lines.IndexOf("#AssignmentNo#");
                    string assignt = lines.Substring(lines.IndexOf("#AssignmentNo#"));
                    assignnum = assignt.Substring(assnt);
                    assignnum.Trim();
                    

                    assigncheck = true;
                }
               
                if (lines.Contains("#ChapterNumber#"))
                {
                    int cl = lines.IndexOf("#ChapterNumber#");
                    string cls = lines.Substring(lines.IndexOf("#ChapterNumber#"));
                    chapnum = cls.Substring(15);
                }
               
               /* if ((assigncheck == true) && (lines.Contains("#AssignmentNo#")))
                {
                 string submit = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsubmit.txt";
                string submitstr = File.ReadAllText(submit);
                File.AppendAllText(dirpath + "\\" + foutputfile, "</div>");
                File.AppendAllText(dirpath + "\\" + foutputfile, submitstr);
                assigncheck = false;
                }*/

                

                //***************Fill in the blanks****************************************//
                if (alllines.ToLower() == tag1.ToLower())
                {
                    
                    fibcheck = true;
                    tfcheck = false;
                    saqcheck = false;
                    laqcheck = false;
                    matchcheck = false;
                    mcqcheck = false;
                    saqcheck = false;
                    vsaqcheck = false;
                    vsaqchkcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                }
                if (alllines.ToLower() == tag2.ToLower())
                {
                    
                    fibcheck = false;
                    tfcheck = true;
                    saqcheck = false;
                    laqcheck = false;
                    mcqcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    vsaqcheck = false;
                    vsaqchkcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                }
                if (alllines.ToLower() == tag3.ToLower())
                {
                    
                    saqcheck = true;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    laqcheck = false;
                    mcqcheck = false;
                    vsaqcheck = false;
                    vsaqchkcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                }
                if (alllines.ToLower() == tag4.ToLower())
                {
                    
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = true;
                    laqcheck = false;
                    vsaqcheck = false;
                    vsaqchkcheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                }
                if (alllines.ToLower() == tag5.ToLower())
                {
                    
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = true;
                    laqcheck = false;
                    vsaqcheck = false;
                    vsaqchkcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                }
                if (alllines.ToLower() == tag6.ToLower())
                {
                   
                    mcqcheck = true;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = false;
                    vsaqcheck = false;
                    vsaqchkcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                }
                if (alllines.ToLower() == tag7.ToLower())
                {
                    
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = true;
                    vsaqcheck = false;
                    vsaqchkcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;

                }
                if (alllines.ToLower() == tag8.ToLower())
                {
                    
                    vsaqcheck = true;
                    vsaqchkcheck = false;
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                }
                if (alllines.ToLower() == tag12.ToLower())
                {
                    
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = false;
                    vsaqcheck = false;
                    vsaqchkcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = true;
                    gridcheck = false;
                    mcqmulques = 1;
                }
                if (alllines.ToLower() == tag13.ToLower())
                {
                   
                    vsaqchkcheck = true;
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = false;
                    vsaqcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                    mcqmulques = 1;
                }
                if (alllines.ToLower() == tag14.ToLower())
                {

                    vsaqchkcheck = false;
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = false;
                    vsaqcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = true;
                    mcqmulques = 1;
                }
                if (alllines.Contains("#AssignmentNo#"))
                {

                    vsaqchkcheck = false;
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = false;
                    vsaqcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                    gridcheck = false;
                    mcqmulques = 1;
                }
                if (alllines.Contains("#Time#"))
                {

                    vsaqchkcheck = false;
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = false;
                    vsaqcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                    mcqmulques = 1;
                }
               /* if (alllines.StartsWith("#Always"))
                {

                    vsaqchkcheck = false;
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = false;
                    vsaqcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                    mcqmulques = 1;
                }*/
                /*if (alllines.StartsWith("#EndAlways"))
                {

                    vsaqchkcheck = false;
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = false;
                    vsaqcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    gridcheck = false;
                    mcqmulques = 1;
                }*/

               /* if (lines.Contains("#Type-VSAQ-Check#"))
                {
                    
                    vsaqchkcheck = true;
                    mcqcheck = false;
                    saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = false;
                    vsaqcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = false;
                    mcqmultcheck = false;
                    mcqmulques = 1;
                }*/
                if (alllines.Contains("#Media-S#"))
                {
                    
                    mcqcheck = false;
                    //saqcheck = false;
                    //fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    laqcheck = false;
                    //vsaqcheck = false;
                    //vsaqchkcheck = false;
                    mediascheck = true;
                }
                if (alllines.Contains("#Media-V#"))
                {
                    
                    //mcqcheck = false;
                    //saqcheck = false;
                    fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                    //laqcheck = false;
                    //vsaqcheck = false;
                    //vsaqchkcheck = false;
                    mediavcheck = true;
                    mediascheck = false;
                    mediaancheck = false;
                }
                 if (alllines.Contains("#Media-A#"))
                {
                    
                    //mcqcheck = false;
                   // saqcheck = false;
                    //fibcheck = false;
                    tfcheck = false;
                    imgcheck = false;
                    matchcheck = false;
                   // laqcheck = false;
                    //vsaqcheck = false;
                    //vsaqchkcheck = false;
                    mediascheck = false;
                    mediavcheck = false;
                    mediaancheck = true;

                }

                ////#A#

                 /*if ((saqcheck) && !(lines.Contains("#A#"))
                 {
                     saqlines = lines;
                     lines = lines + "#A#";
                 }*/




                /*****************MEDIA FILES*******************/
              /*   if (alllines == "#Type-VSAQ-Check#") {
                     MessageBox.Show("#Type-VSAQ-Check#" + vsaqcheck.ToString());
                 }
                 if (alllines == "#Time#")
                 {
                     MessageBox.Show("#Time#" + vsaqcheck.ToString());
                 }*/

                //****************Media with Audio**************//
                 if ((mediascheck) && (!mcqcheck) && (!matchcheck) && (lines.Contains("#Media-S#")))
                {
                    //int pi = lines.IndexOf("#Media-S#");
                    string meds = lines.Substring(lines.IndexOf("#Media-S#"));
                    string medias = meds.Substring(9);
                    medias = medias.Trim();
                   //string medfname= Path.GetFileNameWithoutExtension(medias);
                    string medsext=Path.GetExtension(medias);
                    string medsou = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagaudio.txt";
                    string medsdata = File.ReadAllText(medsou);
                    string medsfind = "fileextension";
                    string medsfnamefind = "filenamewithextension";
                    medsdata = medsdata.Replace(medsfind, medsext.Split('.')[1]);
                    medsdata=medsdata.Replace(medsfnamefind,classnum.ToLower() + "/" + subject.ToLower() + "/" + medias);
                    File.AppendAllText(dirpath + "\\" + foutputfile, medsdata + Environment.NewLine);
                }


                //****************Media with Video**************//
                if ((mediavcheck) && (!mcqcheck) && (!matchcheck) && (lines.Contains("#Media-V#")))
                {
                    //int pi = lines.IndexOf("#Media-S#");
                    string medv = lines.Substring(lines.IndexOf("#Media-V#"));
                    string mediav = medv.Substring(9);
                    mediav = mediav.Trim();
                    //string medfname= Path.GetFileNameWithoutExtension(medias);
                    string medvext = Path.GetExtension(mediav);
                    string medvid = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagvideo.txt";
                    string medvdata = File.ReadAllText(medvid);
                    string medvfind = "fileextension";
                    string medvfnamefind = "filenamewithextension";
                    medvdata = medvdata.Replace(medvfind, medvext.Split('.')[1]);
                    medvdata = medvdata.Replace(medvfnamefind, classnum.ToLower() + "/" + subject.ToLower() + "/" + mediav);
                    File.AppendAllText(dirpath + "\\" + foutputfile, medvdata + Environment.NewLine);
                }


               
                 /*PIX*/ // for Pix other than mcqcheck and match
                /*if ((!saqcheck)&&(!fibcheck) && (!mcqcheck) && (!matchcheck) && (lines.Contains("Pix") || (lines.Contains("pix"))))
                {
                    int pi = lines.IndexOf("#Pix#");
                    string matpi = lines.Substring(lines.IndexOf("#Pix#"));
                    string matpic = matpi.Substring(5) + ".jpg";
                    matpic = matpic.Trim();
                    string pix = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagresizeimage.txt";
                    string pixdata = File.ReadAllText(pix);
                    string pixfind = "imagename";
                    pixdata = pixdata.Replace(pixfind, matpic);

                    File.AppendAllText(dirpath + "\\" + foutputfile, pixdata + Environment.NewLine);
                }*/

                if ((gridcheck) && (lines.Contains("#Instruction#")) && !(lines.Contains("#AssignmentNo# ")))
                {

                    string gridlines;
                    gridlines = lines;
                    if (gridlines.Contains("Pix"))
                    {
                        IniFile loadimg = new IniFile();
                        string imagename = loadimg.getimagename(gridlines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        gridlines = regex.Replace(gridlines, newName);
                        gridlines = regex1.Replace(gridlines, newName);
                    }
                                      
                    
                    
                    
                    instcount = instcount + 1;
                    string outfile;
                    string taginst = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taginstruction.txt";
                    outfile = File.ReadAllText(taginst);
                    string inst = gridlines.Substring(0, gridlines.IndexOf(' '));
                    string inst1 = gridlines.Substring(gridlines.IndexOf(' ') + 1);
                    string srchinst = "Instructions";
                    string srchinstcount = "uniqueid";
                    outfile = outfile.Replace(srchinst, inst1);
                    outfile = outfile.Replace(srchinstcount, "INST" + instcount);
                    File.AppendAllText(dirpath + "\\" + foutputfile, outfile + Environment.NewLine);
                }

                if ((!asischeck) && (gridcheck) && !(lines.Contains("#Instruction#")) && !(lines.ToLower().Contains("#type-grid#")) && !(lines.Contains("#AssignmentNo# ")) && (lines != "") && !(lines.ToLower().Contains("#asis#")) && !(lines.ToLower().Contains("#asisend#")) && (lines.Contains("Pix"))&&!(lines.ToLower().StartsWith("#always")) && !(lines.ToLower().StartsWith("#end")))
                {
                string gridlines;
                gridlines = lines;
                if (gridlines.Contains("Pix"))
                {
                    IniFile loadimg = new IniFile();
                    string imagename = loadimg.getimagename(gridlines);
                    string oldName1 = "#Pix#" + imagename;
                    string oldName2 = "#Pix# " + imagename;
                    string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                    System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                    System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                    gridlines = regex.Replace(gridlines, newName);
                    gridlines = regex1.Replace(gridlines, newName);
                    File.AppendAllText(dirpath + "\\" + foutputfile, gridlines + Environment.NewLine);
                }
            }

                if ((!asischeck) && (gridcheck) && !(lines.Contains("#Instruction#")) && !(lines.ToLower().Contains("#type-grid#")) && !(lines.Contains("#AssignmentNo# ")) && (lines != "") && !(lines.ToLower().Contains("#asis#")) && !(lines.ToLower().Contains("#asisend#")) && !(lines.Contains("Pix")) && !(lines.ToLower().StartsWith("#always")) && !(lines.ToLower().StartsWith("#end")))
                {
                                        
                    string temp = lines;
                    temp = temp.Replace("style=\"","style='");
                    temp = temp.Replace("bold\">", "bold\'>");
                    temp = temp.Replace("italic\">", "italic\'>");
                    temp = temp.Replace("underline\">", "underline\'>");
                    File.AppendAllText(dirpath + "\\" + foutputfile, temp + Environment.NewLine);
                    
                }
                    
                    
                    /****************************FIB********************************/
                if ((fibcheck) && (lines.Contains("#Instruction#"))  && !(lines.Contains("#AssignmentNo# ")))
                {
                    
                    string fiblines = lines;
                    //fiblines = fiblines.Replace(@"<img src='../../../../../../../../../images/", @"<img src='../../../../../../../../../images/" + classnum + "/" + subject + "/");
                    if (fiblines.Contains("Pix"))
                    {
                        IniFile loadimg = new IniFile();
                        string imagename = loadimg.getimagename(fiblines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        fiblines = regex.Replace(fiblines, newName);
                        fiblines = regex1.Replace(fiblines, newName);
                    }
                    
                    instcount = instcount + 1;
                    string outfile;
                    string taginst = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taginstruction.txt";
                    outfile = File.ReadAllText(taginst);
                    string inst = fiblines.Substring(0, fiblines.IndexOf(' '));
                    string inst1 = fiblines.Substring(fiblines.IndexOf(' ') + 1);
                    string srchinst = "Instructions";
                    string srchinstcount = "uniqueid";
                    outfile = outfile.Replace(srchinst, inst1);
                    outfile = outfile.Replace(srchinstcount, "INST" + instcount);
                    // string bbpdtxtinst = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\BBPD.txt";


                    File.AppendAllText(dirpath + "\\" + foutputfile, outfile + Environment.NewLine);
                }
              /*  if ((fibcheck)&&(mediascheck) && (lines.Contains("#Media-S#")))
                {
                    //int pi = lines.IndexOf("#Media-S#");
                    string meds = lines.Substring(lines.IndexOf("#Media-S#"));
                    string medias = meds.Substring(9);
                    medias = medias.Trim();
                    //string medfname= Path.GetFileNameWithoutExtension(medias);
                    string medsext = Path.GetExtension(medias);
                    string medsou = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagaudio.txt";
                    string medsdata = File.ReadAllText(medsou);
                    string medsfind = "fileextension";
                    string medsfnamefind = "filenamewithextension";
                    medsdata = medsdata.Replace(medsfind, medsext.Split('.')[1]);
                    medsdata = medsdata.Replace(medsfnamefind, medias);
                    File.AppendAllText(dirpath + "\\" + foutputfile, medsdata + Environment.NewLine);
                }*/
                /*if ((fibcheck) && lines.Contains("#Pix#"))
                {
                    int pi = lines.IndexOf("#Pix#");
                    string matpi = lines.Substring(lines.IndexOf("#Pix#"));
                    string matpic = matpi.Substring(5) + ".jpg";
                    matpic = matpic.Trim();
                    string pix = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagresizeimage.txt";
                    string pixdata = File.ReadAllText(pix);
                    string pixfind = "imagename";
                    pixdata = pixdata.Replace(pixfind, matpic);

                    File.AppendAllText(dirpath + "\\" + foutputfile, pixdata + Environment.NewLine);
                }*/

               

                if ((fibcheck) && (lines.Contains("Pix") && !(lines.Contains("#Instruction#")) && !(lines.Contains("_"))))
                {
                    string fiblines = lines;
                    /*int pi = lines.IndexOf("#Pix#");
                    string matpi = lines.Substring(lines.IndexOf("#Pix#"));
                    string matpic = matpi.Substring(5) + ".jpg";
                    matpic = matpic.Trim();
                    string pix = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagresizeimage.txt";
                    string pixdata = File.ReadAllText(pix);
                    string pixfind = "imagename";
                    pixdata = pixdata.Replace(pixfind, matpic);

                    File.AppendAllText(dirpath + "\\" + foutputfile, pixdata + Environment.NewLine);*/

                    IniFile loadimg = new IniFile();
                    // loadimg.getimagename(lines);
                    //string oldName = "#Pix#";
                    string imagename = loadimg.getimagename(fiblines);
                    string oldName1 = "#Pix#" + imagename;
                    string oldName2 = "#Pix# " + imagename;
                    string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                    System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                    System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                    fiblines = regex.Replace(fiblines, newName);
                    fiblines = regex1.Replace(fiblines, newName);
                     File.AppendAllText(dirpath + "\\" + foutputfile, fiblines + Environment.NewLine);
                }
                if ((!asischeck)&&(fibcheck) && (lines.Contains("_")) && (lines.Contains("#A")))
                {

                   
                    
                    fiblineno = fiblineno + 1;
                    string blank = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\underscore.txt";
                    string blankfib = File.ReadAllText(blank);
                    string fibstr;

                    string fibquest = "FIB";
                    string fibanswer = "AFIB";
                    string searchuid = "same-uniqueid-as-label";
                    string searchanswerid = "answer uniqueid";
                    string searchuid1 = "uniqueid";
                    //string fiboutput;
                    string fibtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagfib.txt";
                    fibstr = File.ReadAllText(fibtag);
                    string fiblines = lines;
                   

                    if (fiblines.Contains("_"))
                    {
                        fiblines = fiblines.Replace("_______________________________", "_");
                        fiblines = fiblines.Replace("___________________________", "_");
                        fiblines = fiblines.Replace("_______________________", "_");
                        fiblines = fiblines.Replace("______________________", "_");
                        fiblines = fiblines.Replace("_____________________", "_");
                        fiblines = fiblines.Replace("____________________", "_");
                        fiblines = fiblines.Replace("___________________", "_");
                        fiblines = fiblines.Replace("__________________", "_");
                        fiblines = fiblines.Replace("_________________", "_");
                        fiblines = fiblines.Replace("________________", "_");
                        fiblines = fiblines.Replace("_______________", "_");
                        fiblines = fiblines.Replace("______________", "_");
                        fiblines = fiblines.Replace("_____________", "_");
                        fiblines = fiblines.Replace("____________", "_");
                        fiblines = fiblines.Replace("___________", "_");
                        fiblines = fiblines.Replace("__________", "_");
                        fiblines = fiblines.Replace("_________", "_");
                        fiblines = fiblines.Replace("________", "_");
                        fiblines = fiblines.Replace("_______", "_");
                        fiblines = fiblines.Replace("______", "_");
                        fiblines = fiblines.Replace("_____", "_");
                        fiblines = fiblines.Replace("____", "_");
                        fiblines = fiblines.Replace("___", "_");
                        fiblines = fiblines.Replace("__", "_");
                     }
                    if (fiblines.Contains("Pix"))
                    {
                        IniFile loadimg = new IniFile();
                        // loadimg.getimagename(lines);
                        //string oldName = "#Pix#";
                        string imagename = loadimg.getimagename(fiblines);
                        string oldName1 = "#Pix#"+imagename;
                        string oldName2 = "#Pix# " +imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        fiblines = regex.Replace(fiblines, newName);
                        fiblines = regex1.Replace(fiblines, newName);
                    }
                    /*if (fiblines.Contains("Pix"))
                    {

                        string[] fibpix = fiblines.Split(new[] { "\t" }, StringSplitOptions.None);

                        string pixopt = fibpix[0];
                        string[] fibpixno = fiblines.Split(new[] { "#" }, StringSplitOptions.None);
                        string fibpixnumber = fibpixno[0];
                        string fibpi = pixopt.Substring(pixopt.IndexOf("#Pix#"));
                        string fibpic = fibpi.Substring(5) + ".jpg";
                        fibpic = fibpic.Trim();
                        string pixfib = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taginlineimage.txt";
                        string pixfibdata = File.ReadAllText(pixfib);
                        string pixfindmatch = "imagename";
                        pixfibdata = pixfibdata.Replace(pixfindmatch, fibpic);
                        // File.AppendAllText(dirpath + "\\" + foutputfile, pixfibdata + Environment.NewLine);
                        fiblines = fiblines.Replace(pixopt, fibpixnumber + pixfibdata);

                    }*/
                   
                       
                    
                    string linereplace = fiblines.Replace("_", blankfib);
                    int sfib = linereplace.IndexOf("#A");
                   
                    string afib = linereplace.Substring(linereplace.IndexOf("#A"));

                    int hashlast = afib.LastIndexOf("#");
                    string afib1 = afib.Substring(hashlast+1);
                    afib1.Trim();
                    string finalfilter;
                   

                    
                   
                    if (afib1.Contains("*"))
                    {
                        string ansstar = "<span style='visibility:hidden' class='splitstar'>*</span>";
                        afib1 = afib1.Replace("*", ansstar);
                    }
                    if (afib1.Contains("&"))
                    {
                        afib1 = afib1.Replace("&", "<span style='color: black;' class='splitor'>OR</span>");
                    }
                    string sfib1 = linereplace.Substring(0, sfib);

                    if (sfib1.Contains("#"))
                    {

                        int c = sfib1.IndexOf("#");
                        int c1 = sfib1.LastIndexOf("#");
                        int len = c1 - c + 1;
                        string part = sfib1.Substring(c, len);

                        //int quespart = sfib1..Length;
                        string[] checkitem = part.Split(new[] { "#" }, StringSplitOptions.None);
                        string[] filteritem = new string[10];
                        int counter = 0;
                        //string[] newcheck=checkitem.Except()
                        foreach (string filter in checkitem)
                        {
                            if (filter.ToLower().Contains("box"))
                            {
                                //mbx.Except(bxrm);
                            }
                            else if (filter != "")
                            {
                                filteritem[counter++] = filter;
                            }

                        }
                        sfib1 = sfib1.Substring(0,c);
                        finalfilter = String.Join(" ", filteritem);
                        finalfilter = finalfilter.Trim();
                        finalfilter = finalfilter.Replace(" ", "# #");
                        finalfilter = finalfilter.Replace("##", " ");
                        finalfilter = "#" + finalfilter + "#";
                        finalfilter = finalfilter.Replace("##", "");
                        afib1 = finalfilter + afib1;
                    }

                    if (gltag)
                    {
                        afib1 = globaltag + afib1;
                    }
                    string searchfib = "Type question here";
                    string searchans = "Type answer here";
                    fibstr = fibstr.Replace("_", "blankfib");
                    
                    fibstr = fibstr.Replace(searchfib, sfib1);
                    fibstr = fibstr.Replace(searchans, afib1);
                    fibstr = fibstr.Replace(searchuid, fibquest + fiblineno);
                    fibstr = fibstr.Replace(searchanswerid, fibanswer + fiblineno);
                    fibstr = fibstr.Replace(searchuid1, fibquest + fiblineno);
                    File.AppendAllText(dirpath + "\\" + foutputfile, fibstr + Environment.NewLine);
                    // File.AppendAllText(dirpath + "\\" + foutputfile, fibstr);
                    // File.AppendAllText(dirpath + "\\" + foutputfile, "</form>");


                }
                /*if ((fibcheck) && !(mediascheck) && !(mediavcheck) && !(lines.Contains("#A#")) && !(lines.Contains("#Instruction#")) && !(lines.Contains("#A#")) && !(lines.Contains("#Type-FIB#")) && !(lines.Contains("#Type-FIB# ")) && !(lines.Contains("#AssignmentNo# 3")))
                {
                    string fibquest = "FIB";
                    string fibanswer = "AFIB";
                    string searchuid = "same-uniqueid-as-label";
                    string searchanswerid = "answer uniqueid";
                    string searchuid1 = "uniqueid";
                    string fibunderscore;
                    string[] linefib = lines.Split(new[] { "\r" }, StringSplitOptions.None);
                    //string lg;
                    foreach (string l in linefib)
                    {
                        string la = l.Replace("_(a)_", "(a)_");
                        string lb = la.Replace("_(b)_", "(b)_");
                        string lc = lb.Replace("_(c)_", "(c)_");
                        string ld = lc.Replace("_(d)_", "(d)_");
                        string le = ld.Replace("_(e)_", "(e)_");
                        string lf = le.Replace("_(f)_", "(f)_");
                        string lg = lf.Replace("_(g)_", "(g)_");

                        string blank = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\multipleunderscore.txt";
                        string blankfib = File.ReadAllText(blank);
                        string fibtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagfibmultipleunderscore.txt";
                        fibunderscore = File.ReadAllText(fibtag);
                        string linereplace = lg.Replace("_", blankfib);
                        int sfib = linereplace.IndexOf("#A#");
                        string afib = linereplace.Substring(linereplace.IndexOf("#A#"));
                        string afib1 = afib.Substring(4);
                        string sfib1 = linereplace.Substring(0, sfib);
                        string searchfibline = "Type question here";
                        string searchans = "Type answer here";
                        //fibstr = fibstr.Replace("_","blankfib");
                        fibunderscore = fibunderscore.Replace(searchfibline, linereplace);
                        fibunderscore = fibunderscore.Replace(searchans, afib1);
                        fibunderscore = fibunderscore.Replace(searchuid, fibquest + fiblineno);
                        fibunderscore = fibunderscore.Replace(searchanswerid, fibanswer + fiblineno);
                        fibunderscore = fibunderscore.Replace(searchuid1, fibquest + fiblineno);
                        File.AppendAllText(dirpath + "\\" + foutputfile, fibunderscore + Environment.NewLine);
                    }
                }*/


                //*************************TF****************************************************************//*

                
                if ((tfcheck) && lines.Contains("#Instruction#") && !(lines.Contains("#AssignmentNo# ")))
                {

                    //int Pos3 = text.IndexOf(sec2);
                    instcount = instcount + 1;
                    string outfiletf;
                    // outfile = File.ReadAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt");
                    string taginst1 = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taginstruction.txt";
                    outfiletf = File.ReadAllText(taginst1);
                    string insttf = lines.Substring(0, lines.IndexOf(' '));
                    string insttf1 = lines.Substring(lines.IndexOf(' ') + 1);
                    string srchinsttf = "Instructions";
                    string srchinstcounttf = "uniqueid";
                    outfiletf = outfiletf.Replace(srchinsttf, insttf1);
                    outfiletf = outfiletf.Replace(srchinstcounttf, "INST" + instcount);
                    File.AppendAllText(dirpath + "\\" + foutputfile, outfiletf + Environment.NewLine);

                }

                if ((tfcheck) && !(lines.Contains("_")) && (lines.Contains("#A#")))
                {
                    tflineno = tflineno + 1;
                    string tfstr;
                    string tfquest = "TF";
                    string tfanswer = "ATF";
                    string searchuid = "same-uniqueid-as-fieldset";
                    string searchanswerid = "answer uniqueid";
                    string searchuid1 = "uniqueid";
                    string tftag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagtf.txt";
                    tfstr = File.ReadAllText(tftag);
                    int stf = lines.IndexOf("#A#");
                    string atf = lines.Substring(lines.IndexOf("#A#"));
                    string atf1 = atf.Substring(4);
                    if (atf1.Contains("*"))
                    {
                        string ansstar = "<span style='visibility:hidden' class='splitstar'>*</span>";
                        atf1 = atf1.Replace("*", ansstar);
                    }
                    if (atf1.Contains("&"))
                    {
                        atf1 = atf1.Replace("&", "<span class='splitor'>OR</span>");
                    }
                    string stf1 = lines.Substring(0, stf);
                    string searchtf = "Type question here";
                    string searchans = "Type answer here";
                    tfstr = tfstr.Replace(searchtf, stf1);
                    tfstr = tfstr.Replace(searchans, atf1);
                    tfstr = tfstr.Replace(searchuid, tfquest + tflineno);
                    tfstr = tfstr.Replace(searchanswerid, tfanswer + tflineno);
                    tfstr = tfstr.Replace(searchuid1, tfquest + tflineno);

                    // string tfout = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\BBPD.txt";

                    File.AppendAllText(dirpath + "\\" + foutputfile, tfstr + Environment.NewLine);

                }
                //***************************************SAQ*********************************************************
                
                
                if ((saqcheck) && lines.Contains("#Instruction#"))
                {

                    string saqlines;
                    saqlines = lines;
                    if (saqlines.Contains("Pix"))
                    {
                        IniFile loadimg = new IniFile();
                        string imagename = loadimg.getimagename(saqlines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        saqlines = regex.Replace(saqlines, newName);
                        saqlines = regex1.Replace(saqlines, newName);
                    }
                    
                    
                    instcount = instcount + 1;
                    string outfilesaq;
                    // outfile = File.ReadAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt");
                    string taginst1 = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taginstruction.txt";
                    outfilesaq = File.ReadAllText(taginst1);
                    string inst = saqlines.Substring(0, saqlines.IndexOf(' '));
                    string inst1 = saqlines.Substring(saqlines.IndexOf(' ') + 1);
                    string srchinst = "Instructions";
                    string srchinstcount = "uniqueid";
                    outfilesaq = outfilesaq.Replace(srchinst, inst1);
                    outfilesaq = outfilesaq.Replace(srchinstcount, "INST" + instcount);
                    File.AppendAllText(dirpath + "\\" + foutputfile, outfilesaq + Environment.NewLine);
                }

                if ((saqcheck) && (lines.StartsWith("#Pix") && !(lines.Contains("#Instruction#")) && !(lines.Contains("#A#"))))
                {
                    string saqlines;
                    saqlines = lines;

                    IniFile loadimg = new IniFile();
                    // loadimg.getimagename(lines);
                    //string oldName = "#Pix#";
                    string imagename = loadimg.getimagename(saqlines);
                    string oldName1 = "#Pix#" + imagename;
                    string oldName2 = "#Pix# " + imagename;
                    string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                    System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                    System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                    saqlines = regex.Replace(saqlines, newName);
                    saqlines = regex1.Replace(saqlines, newName);



                    File.AppendAllText(dirpath + "\\" + foutputfile, saqlines + Environment.NewLine);
                
                
                }
                if ((!asischeck) && (saqcheck) && !(lines.Contains("#Instruction#")) && !(lines.ToLower().Contains("#type-saq#")) && !(lines.Contains("#AssignmentNo# ")) && (lines != "")&&!(lines.ToLower().Contains("#asis#")) && !(lines.ToLower().Contains("#asisend#")) && !(lines.ToLower().StartsWith("#always")) && !(lines.ToLower().StartsWith("#end")))
               // if ((!asischeck) && (saqcheck) && !(lines.Contains("#Instruction#")) && !(lines.ToLower().Contains("#type-saq#")) && !(lines.Contains("#AssignmentNo# ")) && (lines != "") && !(lines.ToLower().StartsWith("#always")) && !(lines.ToLower().StartsWith("#end")))
                {
                    string saqlines;
                    saqlines = lines;
                    string anstag;
                    if (!(saqlines.Contains("#A#")))
                    {
                        saqlines = saqlines + "#A# ";

                    }
                    if (saqlines.Contains("Pix") && (!saqlines.Contains(".jpg")) && (lines.Contains("#A#")))
                    {
                        IniFile loadimg = new IniFile();
                        // loadimg.getimagename(lines);
                        //string oldName = "#Pix#";
                        string imagename = loadimg.getimagename(saqlines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        saqlines = regex.Replace(saqlines, newName);
                        saqlines = regex1.Replace(saqlines, newName);
                        if (saqlines.Contains(".jpg'>\t"))
                        {
                            saqlines = saqlines.Replace(".jpg'>\t", ".jpg'><br/>");
                        }
                        
                    }

                    // else if (!saqlines.Contains("#Pix"))
                    //{
                    /*if (saqlines.Contains("#BestVariant"))
                    {
                       
                        int b = saqlines.IndexOf("#BestVariant");
                        int b1 = saqlines.LastIndexOf("#BestVariant-");
                        int len = b1 - b;
                        string best = "#BestVariant-";
                        int lenbest = best.Length;
                        beststr = saqlines.Substring(b, len + lenbest + 2);
                        if (saqlines.Contains("#BestVariant-any"))
                        {
                            beststr = saqlines.Substring(b, len + lenbest + 4);
                        }
                    }*/



                    if ((!saqlines.Contains("#Pix")) && (lines != ""))
                    {
                        saqlineno = saqlineno + 1;
                        string saqstr;
                        string finalfilter;
                        string saqquest = "SAQ";
                        string saqanswer = "ASAQ";
                        string searchuid = "unique-textarea1";
                        string searchanswerid = "answer uniqueid";
                        string searchuid1 = "same-uniqueid-as-label";
                        string saqtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsaq.txt";
                        saqstr = File.ReadAllText(saqtag);
                        int saqqs = saqlines.IndexOf("#A#");
                        string answer = "#A#";
                        int ans = answer.Length;
                        string asaq = saqlines.Substring(saqlines.IndexOf("#A#"));
                        string asaq1 = asaq.Substring(ans);
                        if (saqlines.Contains("#BestVariant"))
                        {
                            asaq1 = beststr + asaq1;
                        }

                        if (asaq1.Contains("*"))
                        {
                            string ansstar = "<span style='visibility:hidden' class='splitstar'>*</span>";
                            asaq1 = asaq1.Replace("*", ansstar);
                        }
                        if (asaq1.Contains("&"))
                        {
                            asaq1 = asaq1.Replace("&", "<span style='color: black;' class='splitor'>OR</span>");
                        }
                        string saqqes = saqlines.Substring(0, saqqs);
                        string searchtf = "Type question here";
                        string searchans = "Type answer here";
                        if (saqqes.Contains("#"))
                        {

                            int c = saqqes.IndexOf("#");
                            int c1 = saqqes.LastIndexOf("#");
                            int length = c1 - c + 1;
                            string part = saqqes.Substring(c, length);
                            string[] checkitem = part.Split(new[] { "#" }, StringSplitOptions.None);
                            string[] filteritem = new string[10];
                            int counter = 0;
                            //string[] newcheck=checkitem.Except()
                            foreach (string filter in checkitem)
                            {
                                if (filter.ToLower().Contains("box"))
                                {
                                    //mbx.Except(bxrm);
                                }
                                else if (filter != "")
                                {
                                    filteritem[counter++] = filter;
                                }

                            }

                            finalfilter = String.Join(" ", filteritem);
                            finalfilter = finalfilter.Trim();
                            finalfilter = finalfilter.Replace(" ", "# #");
                            finalfilter = finalfilter.Replace("##", " ");
                           // finalfilter = finalfilter.Replace("## #A-Order#", "#A-Order#");
                            finalfilter = "#" + finalfilter + "#";
                            finalfilter = finalfilter.Replace("##", "");
                            asaq1 = finalfilter + asaq1;
                        }




                        if (saqqes.Contains("Box"))
                        {
                            String mboxstr;
                            
                            string mboxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsaqmbox.txt";
                            mboxstr = File.ReadAllText(mboxtag);
                            string[] mbx = saqqes.Split(new[] { "#" }, StringSplitOptions.None);
                            mboxstr = mboxstr.Replace(searchtf, mbx[0].ToString());
                            mboxstr = mboxstr.Replace(searchans, asaq1);
                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxstr + Environment.NewLine);
                            string mbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmbox.txt";
                            string mbxstr = File.ReadAllText(mbxtag);
                            foreach (string boxopt in mbx)
                            {
                                //string anstag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\answertag.txt";
                                //string anstagstr = File.ReadAllText(anstag);
                                //anstagstr = anstagstr.Replace(searchans, asaq1);
                                if (boxopt.ToLower().Contains("mbox"))
                                {
                                    string mbxoutput = mbxstr;
                                    string[] mbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                    // for multiple boxes
                                    string mbxno = mbxopt[1];
                                    int mboxno = Convert.ToInt32(mbxno);
                                    int m;
                                    //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                    if (mboxno > 1)
                                    {
                                        int sno = mbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = mbxopt[2];
                                            string searchbx = "Answer";
                                            mbxoutput = mbxoutput.Replace(searchbx, sbxans);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxoutput + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {
                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                        }

                                        for (m = 1; m < mboxno; m++)
                                        {
                                            string mbxnumber = @"<input id='SAQ3' name='SAQ3' type='text' placeholder='' class='form-control input-md saqm vsaqregular' autocorrect='off' autocapitalize='none'>";
                                            //string mnostr = "paste here";
                                            //mbxoutput = mbxstr.Replace(mnostr, mbxnumber);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                        }
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                     //   File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                    if (mboxno == 1)
                                    {
                                        string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmbox.txt";
                                        string mboxonestr = File.ReadAllText(mboxone);
                                        int sno = mbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = mbxopt[2];
                                            string searchbx = "Answer";
                                            mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                        //File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                       
                                    }
                                    //File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                }

                                //sbox

                                if (boxopt.ToLower().Contains("sbox"))
                                {
                                    string sbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsbox.txt";
                                    string sbxstr = File.ReadAllText(sbxtag);
                                    string sbxoutput = sbxstr;
                                    string[] sbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                    // for multiple boxes
                                    string sbxno = sbxopt[1];
                                    int sboxno = Convert.ToInt32(sbxno);
                                    int s;
                                    //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                    if (sboxno > 1)
                                    {
                                        int sno = sbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = sbxopt[2];
                                            string searchbx = "Answer";
                                            sbxoutput = sbxoutput.Replace(searchbx, sbxans);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, sbxoutput + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {
                                            File.AppendAllText(dirpath + "\\" + foutputfile, sbxstr + Environment.NewLine);
                                        }

                                        for (s = 1; s < sboxno; s++)
                                        {
                                            // string mbxnumber = @"<input id='SAQ3' name='SAQ3' type='text' placeholder='' class='form-control input-md saqm' autocorrect='off' autocapitalize='none'>";
                                            string mbxnumber = @"<input id='SAQS1' name='SAQS1' type='text' placeholder='' class='form-control input-md saqs vsaqregular' autocorrect='off' autocapitalize='none'>";

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                        }
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                       // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                    if (sboxno == 1)
                                    {
                                        string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsbox.txt";
                                        string mboxonestr = File.ReadAllText(mboxone);
                                        int sno = sbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = sbxopt[2];
                                            string searchbx = "Answer";
                                            mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                     //   File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                }

                                //Lbox

                                if (boxopt.ToLower().Contains("lbox"))
                                {
                                    if (boxopt.ToLower().Contains("nousualbox"))
                                    {
                                    }
                                    else {
                                        string lbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taglbox.txt";
                                        string lbxstr = File.ReadAllText(lbxtag);
                                        string lbxoutput = lbxstr;
                                        string[] lbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                        // for multiple boxes
                                        string lbxno = lbxopt[1];
                                        int lboxno = Convert.ToInt32(lbxno);
                                        int l;
                                        //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                        if (lboxno > 1)
                                        {
                                            int sno = lbxopt.Count();
                                            if (sno > 2)
                                            {
                                                string sbxans = lbxopt[2];
                                                string searchbx = "Answer";
                                                lbxoutput = lbxoutput.Replace(searchbx, sbxans);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, lbxoutput + Environment.NewLine);
                                            }
                                            if (sno <= 2)
                                            {
                                                File.AppendAllText(dirpath + "\\" + foutputfile, lbxstr + Environment.NewLine);
                                            }

                                            for (l = 1; l < lboxno; l++)
                                            {

                                                string mbxnumber = @"<input id='SAQ4' name='SAQ4' type='text' placeholder='' class='form-control input-md saqlg vsaqregular' autocorrect='off' autocapitalize='none'>";
                                                File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                            }
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                            //  File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                        }
                                        if (lboxno == 1)
                                        {
                                            string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taglbox.txt";
                                            string mboxonestr = File.ReadAllText(mboxone);
                                            int sno = lbxopt.Count();
                                            if (sno > 2)
                                            {
                                                string sbxans = lbxopt[2];
                                                string searchbx = "Answer";
                                                mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                                File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                            }
                                            if (sno <= 2)
                                            {

                                                File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                            }
                                            //  File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                        }
                                    }
                                    
                                }

                            }

                             anstag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\answertag.txt";
                            string anstagstr = File.ReadAllText(anstag);
                            anstagstr = anstagstr.Replace(searchans, asaq1); 
                            
                            File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                        }


                        else
                        {

                            string ansetag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\answertag.txt";
                            string anstagstr = File.ReadAllText(ansetag);
                            anstagstr = anstagstr.Replace(searchans, asaq1);
                            if (saqqes.Contains("#"))
                            {
                                int c = saqqes.IndexOf("#");
                                saqqes = saqqes.Substring(0, c);
                            }
                            saqstr = saqstr.Replace(searchtf, saqqes);
                            // saqstr = saqstr.Replace(searchans, asaq1);
                            saqstr = saqstr.Replace(searchuid, saqquest + vsaqlineno);
                            saqstr = saqstr.Replace(searchanswerid, saqanswer + vsaqlineno);
                            saqstr = saqstr.Replace(searchuid1, saqquest + vsaqlineno);
                            File.AppendAllText(dirpath + "\\" + foutputfile, saqstr + Environment.NewLine);
                            File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                        }
                    }
                }
                    //File.AppendAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt","</form>");
                //}




                /*****************************************VSAQ********************************/
               
                if ((vsaqcheck) && lines.Contains("#Instruction#"))
                {

                    string vsaqlines;
                    vsaqlines = lines;
                    if (vsaqlines.Contains("Pix"))
                    {
                        IniFile loadimg = new IniFile();
                        string imagename = loadimg.getimagename(vsaqlines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        vsaqlines = regex.Replace(vsaqlines, newName);
                        vsaqlines = regex1.Replace(vsaqlines, newName);
                    }
                    
                    
                    
                    instcount = instcount + 1;
                    string outfilevsaq;
                    // outfile = File.ReadAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt");
                    string taginst1 = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taginstruction.txt";
                    outfilevsaq = File.ReadAllText(taginst1);
                    string inst = vsaqlines.Substring(0, vsaqlines.IndexOf(' '));
                    string inst1 = vsaqlines.Substring(vsaqlines.IndexOf(' ') + 1);
                    string srchinst = "Instructions";
                    string srchinstcount = "uniqueid";
                    outfilevsaq = outfilevsaq.Replace(srchinst, inst1);
                    outfilevsaq = outfilevsaq.Replace(srchinstcount, "INST" + instcount);
                    File.AppendAllText(dirpath + "\\" + foutputfile, outfilevsaq + Environment.NewLine);
                }


                if ( (vsaqcheck) && (lines.StartsWith("#Pix") && !(lines.Contains("#Instruction#")) && !(lines.Contains("#A#"))))
                {
                    string vsaqlines;
                    vsaqlines = lines;
                    IniFile loadimg = new IniFile();
                    // loadimg.getimagename(lines);
                    //string oldName = "#Pix#";
                    string imagename = loadimg.getimagename(vsaqlines);
                    string oldName1 = "#Pix#" + imagename;
                    string oldName2 = "#Pix# " + imagename;
                    string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                    System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                    System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                    vsaqlines = regex.Replace(vsaqlines, newName);
                    vsaqlines = regex1.Replace(vsaqlines, newName);

                    File.AppendAllText(dirpath + "\\" + foutputfile, vsaqlines + Environment.NewLine);
                }

                if ((!asischeck) && (vsaqcheck) && !(lines.Contains("#Instruction#")) && !(lines.ToLower().Contains("#type-vsaq")) && !(lines.Contains("AssignmentNo# ")) && (lines != "")&&!(lines.ToLower().Contains("#asis#")) && !(lines.ToLower().Contains("#asisend#")) && !(lines.ToLower().StartsWith("#always")) && !(lines.ToLower().StartsWith("#end")))
                {
                    string vsaqlines;
                    vsaqlines = lines;

                    if (!(vsaqlines.Contains("#A#")))
                    {
                        vsaqlines = vsaqlines + "#A# ";

                    }
                    
                    if (vsaqlines.Contains("Pix") && (lines.Contains("#A#")))
                    {
                        IniFile loadimg = new IniFile();
                        // loadimg.getimagename(lines);
                        //string oldName = "#Pix#";
                        string imagename = loadimg.getimagename(vsaqlines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        vsaqlines = regex.Replace(vsaqlines, newName);
                        vsaqlines = regex1.Replace(vsaqlines, newName);
                        if (vsaqlines.Contains(".jpg'>\t"))
                        {
                            vsaqlines = vsaqlines.Replace(".jpg'>\t", ".jpg'><br/>");
                        }
                    }


                    if (!vsaqlines.Contains("#Pix")  && (vsaqlines != ""))
                    {
                            vsaqlineno = vsaqlineno + 1;
                            string saqstr;
                            string finalfilter;
                            string saqquest = "SAQ";
                            string saqanswer = "ASAQ";
                            string searchuid = "unique-textarea1";
                            string searchanswerid = "answer uniqueid";
                            string searchuid1 = "same-uniqueid-as-label";
                            string saqtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagvsaq.txt";
                            saqstr = File.ReadAllText(saqtag);
                            int saqqs = vsaqlines.IndexOf("#A#");
                            string answer = "#A#";
                            int ans = answer.Length;
                            string asaq = vsaqlines.Substring(vsaqlines.IndexOf("#A#"));
                            string asaq1 = asaq.Substring(ans);
                           if(gltag)
                           {
                               asaq1 = globaltag + asaq1;
                           }
                            
                            if (asaq1.Contains("*"))
                            {
                                string ansstar = "<span style='visibility:hidden' class='splitstar'>*</span>";
                                asaq1 = asaq1.Replace("*", ansstar);
                            }
                            if (asaq1.Contains("&"))
                            {
                                asaq1 = asaq1.Replace("&", "<span style='color: black;' class='splitor'>OR</span>");
                            } 
                            string saqqes = vsaqlines.Substring(0, saqqs);
                            string searchtf = "Type question here";
                            string searchans = "Type answer here";
                            if (saqqes.Contains("#"))
                            {

                                int c = saqqes.IndexOf("#");
                                int c1 = saqqes.LastIndexOf("#");
                                int length = c1 - c + 1;
                                string part = saqqes.Substring(c, length);
                                string[] checkitem = part.Split(new[] { "#" }, StringSplitOptions.None);
                                string[] filteritem = new string[10];
                                int counter = 0;
                                //string[] newcheck=checkitem.Except()
                                foreach (string filter in checkitem)
                                {
                                    if (filter.ToLower().Contains("box"))
                                    {
                                        //mbx.Except(bxrm);
                                    }
                                    else if (filter != "")
                                    {
                                        filteritem[counter++] = filter;
                                    }

                                }

                                finalfilter = String.Join(" ", filteritem);
                                finalfilter = finalfilter.Trim();
                                finalfilter = finalfilter.Replace(" ", "# #");
                                finalfilter = finalfilter.Replace("##", " ");
                                finalfilter = "#" + finalfilter + "#";
                                finalfilter = finalfilter.Replace("##", "");
                                asaq1 = finalfilter + asaq1;
                            }
                            if(saqqes.Contains("Box"))
                            {
                                String mboxstr ;
                                string mboxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsaqmbox.txt";
                                mboxstr = File.ReadAllText(mboxtag);
                                string[] mbx = saqqes.Split(new[] { "#" }, StringSplitOptions.None);
                                mboxstr = mboxstr.Replace(searchtf, mbx[0].ToString());
                                mboxstr = mboxstr.Replace(searchans, asaq1);
                                File.AppendAllText(dirpath + "\\" + foutputfile, mboxstr + Environment.NewLine);
                                string mbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmbox.txt";
                                string mbxstr = File.ReadAllText(mbxtag);
                                foreach (string boxopt in mbx)
                                {
                                    
                                    if (boxopt.ToLower().Contains("mbox"))
                                    {
                                        string mbxoutput = mbxstr;
                                        string[] mbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                        // for multiple boxes
                                        string mbxno = mbxopt[1];
                                        int mboxno = Convert.ToInt32(mbxno);
                                        int m;
                                        //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                        if (mboxno > 1)
                                        {
                                            int sno = mbxopt.Count();
                                            if (sno > 2)
                                            {
                                                string sbxans = mbxopt[2];
                                                string searchbx = "Answer";
                                                mbxoutput = mbxoutput.Replace(searchbx, sbxans);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, mbxoutput + Environment.NewLine);
                                            }
                                            if (sno <= 2)
                                            {
                                                File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                            }

                                            for (m = 1; m < mboxno; m++)
                                            {
                                                string mbxnumber = @"<input id='SAQ3' name='SAQ3' type='text' placeholder='' class='form-control input-md saqm vsaqregular' autocorrect='off' autocapitalize='none'>";
                                                //string mnostr = "paste here";
                                                //mbxoutput = mbxstr.Replace(mnostr, mbxnumber);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                            }
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                            //anstagstr = anstagstr.Replace(searchans, asaq1);
                                            //File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                        }
                                        if (mboxno == 1)
                                        {
                                            string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmbox.txt";
                                            string mboxonestr = File.ReadAllText(mboxone);
                                            int sno = mbxopt.Count();
                                            if (sno > 2)
                                            {
                                                string sbxans = mbxopt[2];
                                                string searchbx = "Answer";
                                                mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                                File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                            }
                                            if (sno <= 2)
                                            {

                                                File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                            }
                                           // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                        }
                                    }
                                    //sbox

                                    if (boxopt.ToLower().Contains("sbox"))
                                    {
                                        string sbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsbox.txt";
                                        string sbxstr = File.ReadAllText(sbxtag);
                                        string sbxoutput = sbxstr;
                                        string[] sbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                        // for multiple boxes
                                        string sbxno = sbxopt[1];
                                        int sboxno = Convert.ToInt32(sbxno);
                                        int s;
                                        //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                        if (sboxno > 1)
                                        {
                                            int sno = sbxopt.Count();
                                            if (sno > 2)
                                            {
                                                string sbxans = sbxopt[2];
                                                string searchbx = "Answer";
                                                sbxoutput = sbxoutput.Replace(searchbx, sbxans);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, sbxoutput + Environment.NewLine);
                                            }
                                            if (sno <= 2)
                                            {
                                                File.AppendAllText(dirpath + "\\" + foutputfile, sbxstr + Environment.NewLine);
                                            }

                                            for (s = 1; s < sboxno; s++)
                                            {
                                                // string mbxnumber = @"<input id='SAQ3' name='SAQ3' type='text' placeholder='' class='form-control input-md saqm' autocorrect='off' autocapitalize='none'>";
                                                string mbxnumber = @"<input id='SAQS1' name='SAQS1' type='text' placeholder='' class='form-control input-md saqs vsaqregular' autocorrect='off' autocapitalize='none'>";

                                                File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                            }
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                           // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                        }
                                        if (sboxno == 1)
                                        {
                                            string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsbox.txt";
                                            string mboxonestr = File.ReadAllText(mboxone);
                                            int sno = sbxopt.Count();
                                            if (sno > 2)
                                            {
                                                string sbxans = sbxopt[2];
                                                string searchbx = "Answer";
                                                mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                                File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                            }
                                            if (sno <= 2)
                                            {

                                                File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                            }
                                            //File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                        }
                                    }

                                    //Lbox

                                    if (boxopt.ToLower().Contains("lbox"))
                                    {
                                    if (boxopt.ToLower().Contains("nousualbox"))
                                    {

                                    }
                                    else
                                    {

                                        string lbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taglbox.txt";
                                        string lbxstr = File.ReadAllText(lbxtag);
                                        string lbxoutput = lbxstr;
                                        string[] lbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                        // for multiple boxes
                                        string lbxno = lbxopt[1];
                                        int lboxno = Convert.ToInt32(lbxno);
                                        int l;
                                        //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                        if (lboxno > 1)
                                        {
                                            int sno = lbxopt.Count();
                                            if (sno > 2)
                                            {
                                                string sbxans = lbxopt[2];
                                                string searchbx = "Answer";
                                                lbxoutput = lbxoutput.Replace(searchbx, sbxans);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, lbxoutput + Environment.NewLine);
                                            }
                                            if (sno <= 2)
                                            {
                                                File.AppendAllText(dirpath + "\\" + foutputfile, lbxstr + Environment.NewLine);
                                            }

                                            for (l = 1; l < lboxno; l++)
                                            {

                                                string mbxnumber = @"<input id='SAQ4' name='SAQ4' type='text' placeholder='' class='form-control input-md saqlg vsaqregular' autocorrect='off' autocapitalize='none'>";
                                                File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                            }
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                            // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                        }
                                        if (lboxno == 1)
                                        {
                                            string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taglbox.txt";
                                            string mboxonestr = File.ReadAllText(mboxone);
                                            int sno = lbxopt.Count();
                                            if (sno > 2)
                                            {
                                                string sbxans = lbxopt[2];
                                                string searchbx = "Answer";
                                                mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                                File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                            }
                                            if (sno <= 2)
                                            {

                                                File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                            }
                                            // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                        }
                                    }
                                        
                                    }

                                }

                                string anstag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\answertag.txt";
                                string anstagstr = File.ReadAllText(anstag);
                                anstagstr = anstagstr.Replace(searchans, asaq1);
                                File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);

                            }
                       
                            else
                            {
                                string anstag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\answertag.txt";
                                string anstagstr = File.ReadAllText(anstag);
                                anstagstr = anstagstr.Replace(searchans, asaq1);
                                if (saqqes.Contains("#"))
                                {
                                    int c = saqqes.IndexOf("#");
                                    saqqes = saqqes.Substring(0, c);
                                }
                                saqstr = saqstr.Replace(searchtf, saqqes);
                                // saqstr = saqstr.Replace(searchans, asaq1);
                                saqstr = saqstr.Replace(searchuid, saqquest + vsaqlineno);
                                saqstr = saqstr.Replace(searchanswerid, saqanswer + vsaqlineno);
                                saqstr = saqstr.Replace(searchuid1, saqquest + vsaqlineno);
                                File.AppendAllText(dirpath + "\\" + foutputfile, saqstr + Environment.NewLine);
                                File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                            }
                     } /*pix*/
                }


                /*************************************VSAQ-Check***************************************/
                
                
                if ((vsaqchkcheck) && lines.Contains("#Instruction#"))
                {
                    string vsaqchecklines;
                    vsaqchecklines = lines;
                    if (vsaqchecklines.Contains("Pix"))
                    {
                        IniFile loadimg = new IniFile();
                        string imagename = loadimg.getimagename(vsaqchecklines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        vsaqchecklines = regex.Replace(vsaqchecklines, newName);
                        vsaqchecklines = regex1.Replace(vsaqchecklines, newName);
                    }
                    
                    instcount = instcount + 1;
                    string outfilevsaqchk;
                    // outfile = File.ReadAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt");
                    string taginst1 = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taginstruction.txt";
                    outfilevsaqchk = File.ReadAllText(taginst1);
                    string inst = vsaqchecklines.Substring(0, vsaqchecklines.IndexOf(' '));
                    string inst1 = vsaqchecklines.Substring(vsaqchecklines.IndexOf(' ') + 1);
                    string srchinst = "Instructions";
                    string srchinstcount = "uniqueid";
                    outfilevsaqchk = outfilevsaqchk.Replace(srchinst, inst1);
                    outfilevsaqchk = outfilevsaqchk.Replace(srchinstcount, "INST" + instcount);
                    File.AppendAllText(dirpath + "\\" + foutputfile, outfilevsaqchk + Environment.NewLine);
                }
                if ((vsaqchkcheck) && (lines.StartsWith("#Pix") && !(lines.Contains("#Instruction#")) && !(lines.Contains("#A#"))))
                {
                    //string vsaqchecklines;
                    string vsaqchecklines;
                    vsaqchecklines = lines;
                    IniFile loadimg = new IniFile();
                    // loadimg.getimagename(lines);
                    //string oldName = "#Pix#";
                    string imagename = loadimg.getimagename(vsaqchecklines);
                    string oldName1 = "#Pix#" + imagename;
                    string oldName2 = "#Pix# " + imagename;
                    string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                    System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                    System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                    vsaqchecklines = regex.Replace(vsaqchecklines, newName);
                    vsaqchecklines = regex1.Replace(vsaqchecklines, newName);

                    File.AppendAllText(dirpath + "\\" + foutputfile, vsaqchecklines + Environment.NewLine);
                }
                /*if ((vsaqchkcheck) && (lines.ToLower().StartsWith("#always")))
                {
                    vsaqchkcheck=false;
                }*/

                if ((!asischeck) && (vsaqchkcheck) && !(lines.Contains("#Instruction#")) && !(lines.ToLower().Contains("#type-vsaq-check")) && !(lines.Contains("AssignmentNo# ")) && (lines != "") && !(lines.ToLower().Contains("#asis#")) && !(lines.ToLower().Contains("#asisend#")) && !(lines.ToLower().StartsWith("#always")) && !(lines.ToLower().StartsWith("#end")))
                {
                    string vsaqchecklines;
                    vsaqchecklines = lines;
                    if ( !(vsaqchecklines.Contains("#A#")))
                    {
                        vsaqchecklines = vsaqchecklines + "#A# ";

                    }
                    

                    if (vsaqchecklines.Contains("Pix") &&!(vsaqchecklines.Contains(".jpg")) &&(lines.Contains("#A#")))
                    {
                        IniFile loadimg = new IniFile();
                        // loadimg.getimagename(lines);
                        //string oldName = "#Pix#";
                        string imagename = loadimg.getimagename(vsaqchecklines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        vsaqchecklines = regex.Replace(vsaqchecklines, newName);
                        vsaqchecklines = regex1.Replace(vsaqchecklines, newName);
                        if(vsaqchecklines.Contains(".jpg'>\t"))
                        {
                            vsaqchecklines = vsaqchecklines.Replace(".jpg'>\t",".jpg'><br/>");
                        }
                    }

                    if ((!vsaqchecklines.Contains("#Pix")) && (lines != ""))
                    {

                        vsaqlineno = vsaqlineno + 1;
                        string saqstr;
                        string finalfilter;
                        string saqquest = "SAQ";
                        string saqanswer = "ASAQ";
                        string searchuid = "unique-textarea1";
                        string searchanswerid = "answer uniqueid";
                        string searchuid1 = "same-uniqueid-as-label";
                        string saqtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagvsaqcheck.txt";
                        saqstr = File.ReadAllText(saqtag);
                        int saqqs = vsaqchecklines.IndexOf("#A#");
                        string answer = "#A#";
                        int ans = answer.Length;
                        string asaq = vsaqchecklines.Substring(vsaqchecklines.IndexOf("#A#"));
                        string asaq1 = asaq.Substring(ans);
                        if (gltag)
                        {
                            asaq1 = globaltag + asaq1;
                        }
                        if (asaq1.Contains("*"))
                        {
                            string ansstar = "<span style='visibility:hidden' class='splitstar'>*</span>";
                            asaq1 = asaq1.Replace("*", ansstar);
                        }
                        if (asaq1.Contains("&"))
                        {
                            asaq1 = asaq1.Replace("&", "<span style='color: black;' class='splitor'>OR</span>");
                        }
                        
                                             
                        
                        
                        string saqqes = vsaqchecklines.Substring(0, saqqs);
                        string searchtf = "Type question here";
                        string searchans = "Type answer here";
                        // For MBOx SBOX
                        if (saqqes.Contains("#"))
                        {

                            int c = saqqes.IndexOf("#");
                            int c1 = saqqes.LastIndexOf("#");
                            int length = c1 - c + 1;
                            string part = saqqes.Substring(c, length);
                            string[] checkitem = part.Split(new[] { "#" }, StringSplitOptions.None);
                            string[] filteritem = new string[10] ;
                            int counter = 0;
                            //string[] newcheck=checkitem.Except()
                            foreach (string filter in checkitem)
                            {
                                if (filter.ToLower().Contains("box"))
                                {
                                     //mbx.Except(bxrm);
                                }
                                else if(filter != "")
                                {
                                    filteritem[counter++] = filter;
                                }

                            }

                            finalfilter = String.Join(" ",filteritem);
                            finalfilter = finalfilter.Trim();
                            finalfilter = finalfilter.Replace(" ", "# #");
                            finalfilter = finalfilter.Replace("##", " ");
                            finalfilter = "#" + finalfilter + "#";
                            finalfilter = finalfilter.Replace("##", "");
                            asaq1 = finalfilter + asaq1;
                        }
                        if (saqqes.Contains("Box"))
                        {
                            String mboxstr;
                            string mboxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsaqmbox.txt";
                            mboxstr = File.ReadAllText(mboxtag);
                            string[] mbx = saqqes.Split(new[] { "#" }, StringSplitOptions.None);
                        
                            mboxstr = mboxstr.Replace(searchtf, mbx[0].ToString());
                            mboxstr = mboxstr.Replace(searchans, asaq1);
                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxstr + Environment.NewLine);
                            string mbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmboxcheck.txt";
                            string mbxstr = File.ReadAllText(mbxtag);
                            foreach (string boxopt in mbx)
                            {
                               
                                if (boxopt.ToLower().Contains("mbox"))
                                {
                                    
                                    string mbxoutput = mbxstr;
                                    string[] mbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                    // for multiple boxes
                                    string mbxno = mbxopt[1];
                                    int mboxno = Convert.ToInt32(mbxno);
                                    int m;
                                    //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                    if (mboxno > 1)
                                    {
                                        int sno = mbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = mbxopt[2];
                                            string searchbx = "Answer";
                                            mbxoutput = mbxoutput.Replace(searchbx, sbxans);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxoutput + Environment.NewLine);
                                        }
                                        if (sno<=2)
                                        {
                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                        }
                                                                                                                           
                                            for (m = 1; m < mboxno; m++)
                                            {
                                                string mbxnumber = @"<input id='SAQ3' name='SAQ3' type='text' placeholder='' class='form-control input-md saqm vsaqcheck' autocorrect='off' autocapitalize='none'>";
                                                //string mnostr = "paste here";
                                                //mbxoutput = mbxstr.Replace(mnostr, mbxnumber);
                                                File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                            }
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                          //  anstagstr = anstagstr.Replace(searchans, asaq1);
                                         //   File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                   
                                    }
                                    if(mboxno==1)
                                    {
                                        string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmboxcheck.txt";
                                        string mboxonestr = File.ReadAllText(mboxone);
                                        int sno = mbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = mbxopt[2];
                                            string searchbx = "Answer";
                                            mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {
                                            
                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                       // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                }
                                //sbox

                                if (boxopt.ToLower().Contains("sbox"))
                                {
                                    string sbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsboxcheck.txt";
                                    string sbxstr = File.ReadAllText(sbxtag);
                                    string sbxoutput = sbxstr;
                                    string[] sbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                    // for multiple boxes
                                    string sbxno = sbxopt[1];
                                    int sboxno = Convert.ToInt32(sbxno);
                                    int s;
                                    //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                    if (sboxno > 1)
                                    {
                                        int sno = sbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = sbxopt[2];
                                            string searchbx = "Answer";
                                            sbxoutput = sbxoutput.Replace(searchbx, sbxans);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, sbxoutput + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {
                                            File.AppendAllText(dirpath + "\\" + foutputfile, sbxstr + Environment.NewLine);
                                        }

                                        for (s = 1; s < sboxno; s++)
                                        {
                                            // string mbxnumber = @"<input id='SAQ3' name='SAQ3' type='text' placeholder='' class='form-control input-md saqm' autocorrect='off' autocapitalize='none'>";
                                            string mbxnumber = @"<input id='SAQS1' name='SAQS1' type='text' placeholder='' class='form-control input-md saqs vsaqcheck' autocorrect='off' autocapitalize='none'>";

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                        }
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                       // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                    if (sboxno == 1)
                                    {
                                        string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsboxcheck.txt";
                                        string mboxonestr = File.ReadAllText(mboxone);
                                        int sno = sbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = sbxopt[2];
                                            string searchbx = "Answer";
                                            mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                       // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                }

                                //Lbox

                                if (boxopt.ToLower().Contains("lbox"))
                                {
                                    if (boxopt.ToLower().Contains("nousualbox"))
                                    {
                                    }
                                    
                                    else
                                    {
                                     string lbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taglboxcheck.txt";
                                    string lbxstr = File.ReadAllText(lbxtag);
                                    string lbxoutput = lbxstr;
                                    string[] lbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                    // for multiple boxes
                                    string lbxno = lbxopt[1];
                                    int lboxno = Convert.ToInt32(lbxno);
                                    int l;
                                    //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                    if (lboxno > 1)
                                    {
                                        int sno = lbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = lbxopt[2];
                                            string searchbx = "Answer";
                                            lbxoutput = lbxoutput.Replace(searchbx, sbxans);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, lbxoutput + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {
                                            File.AppendAllText(dirpath + "\\" + foutputfile, lbxstr + Environment.NewLine);
                                        }

                                        for (l = 1; l < lboxno; l++)
                                        {

                                            string mbxnumber = @"<input id='SAQ4' name='SAQ4' type='text' placeholder='' class='form-control input-md saqlg vsaqcheck' autocorrect='off' autocapitalize='none'>";
                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                        }
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                      //  File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                    if (lboxno == 1)
                                    {
                                        string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taglboxcheck.txt";
                                        string mboxonestr = File.ReadAllText(mboxone);
                                        int sno = lbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = lbxopt[2];
                                            string searchbx = "Answer";
                                            mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);    
                                        }
                                        if (sno <= 2)
                                        {

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                       // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                    }
                                   
                                }

                            }
                            string anstag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\answertag.txt";
                            string anstagstr = File.ReadAllText(anstag);
                            anstagstr = anstagstr.Replace(searchans, asaq1);
                            File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                        }
                       
                       
                        else
                        {
                            string anstag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\answertag.txt";
                            string anstagstr = File.ReadAllText(anstag);
                            anstagstr = anstagstr.Replace(searchans, asaq1);
                            if (saqqes.Contains("#"))
                            {
                                int c = saqqes.IndexOf("#");
                                saqqes = saqqes.Substring(0, c);
                            }
                            saqstr = saqstr.Replace(searchtf, saqqes);
                           // saqstr = saqstr.Replace(searchans, asaq1);
                            saqstr = saqstr.Replace(searchuid, saqquest + vsaqlineno);
                            saqstr = saqstr.Replace(searchanswerid, saqanswer + vsaqlineno);
                            saqstr = saqstr.Replace(searchuid1, saqquest + vsaqlineno);
                            File.AppendAllText(dirpath + "\\" + foutputfile, saqstr + Environment.NewLine);
                            File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                        }
                    }
                    //File.AppendAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt","</form>");
                }
                

                

                /***********************************MCQ******************************************/
                if ((mcqcheck) && lines.Contains("#Instruction#"))
                {
                    instcount = instcount + 1;
                    string outfilemcq;
                    // outfile = File.ReadAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt");
                    string taginst1 = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taginstruction.txt";
                    outfilemcq = File.ReadAllText(taginst1);
                    string inst = lines.Substring(0, lines.IndexOf(' '));
                    string inst1 = lines.Substring(lines.IndexOf(' ') + 1);
                    string srchinst = "Instructions";
                    string srchinstcount = "uniqueid";
                   
                    outfilemcq = outfilemcq.Replace(srchinst, inst1);
                    outfilemcq = outfilemcq.Replace(srchinstcount, "INST" + instcount);
                    File.AppendAllText(dirpath + "\\" + foutputfile, outfilemcq + Environment.NewLine);


                }
                

                /* modified mcq for unlimited options 7-1-21*/
                 if ((mcqcheck) && !lines.Contains("#Instruction#")&&!lines.ToLower().Contains("#type-mcq#")&& !(lines.Contains("#AssignmentNo#")))
                {
                string mcqmoretag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmcqmore.txt";
                string tagmcqmore = File.ReadAllText(mcqmoretag);
                string mcqlines;
                mcqlines = lines;
                string imagename;
               // imagename = "";
                if (mcqlines.Contains("Pix"))
                {

                    if (mcqlines.Contains("\t#Pix#"))
                    {
                        mcqlines = mcqlines.Replace("\t#Pix#", "<br/>#Pix#");
                    }
                    IniFile loadimg = new IniFile();
                    imagename = loadimg.getimagename(mcqlines);
                    string oldName1 = "#Pix#" + imagename;
                    string oldName2 = "#Pix# " + imagename;
                    string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                    System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                    System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                    mcqlines = regex.Replace(mcqlines, newName);
                    mcqlines = regex1.Replace(mcqlines, newName);
                    
                    if (mcqlines.Contains(".jpg'> \t"))
                    {
                        mcqlines = mcqlines.Replace(".jpg'> \t", ".jpg'><br/>");
                    }
                    if (mcqlines.Contains(".jpg'>\t"))
                    {
                        mcqlines = mcqlines.Replace(".jpg'>\t", ".jpg'><br/>");
                    }
                }
                    string outmcq = "";

                    if ((mcqlines != null) && (mcqlines != "") && (mcqlines != " "))
                    {
                        /*if(mcqlines.StartsWith("#A#"))
                        {
                            mcqlines = mcqlines.Replace("#A#", "\t#A#");
                        }*/

                        if(mcqlines.Contains(".\t"))
                        {
                            IniFile mcprocess = new IniFile();
                            mcqlines = mcprocess.mcqpreprocess(mcqlines);
                        }
                        /*if(mcqlines.Contains("\r\n#A#"))
                        {
                            mcqlines = mcqlines.Replace("\r\n#A#", "\t#A#");
                        }*/
                        if (mcqlines.Contains("\t \t"))
                        {
                            mcqlines = mcqlines.Replace("\t \t", "\t");
                        }
                        if (mcqlines.Contains("\t\t"))
                        {
                            mcqlines = mcqlines.Replace("\t\t", "\t");
                        }
                        if (mcqlines.EndsWith("\t"))
                        {
                            mcqlines = mcqlines.Replace("\t", "");
                        }
                        
                        if (mcqlines.Contains("\t"))
                        {
                            //mcqmult = null;
                            if(mcqlines.Contains("<br/>("))
                            {
                                mcqlines=mcqlines.Replace("<br/>(","<br/>\t(");
                            }
                            mcqlines = mcqlines.Replace("\t", "\r\n");
                            string[] mcqarr = mcqlines.Split(new[] { "\r\n" }, StringSplitOptions.None);

                            foreach (string multopt in mcqarr)
                                {
                                  if(multopt.Contains(".jpg")&& multopt.Contains("#A#"))
                                  {
                                      int mcqno = multopt.IndexOf("#A#");
              
                                      string mcqoption;
                                      string mcqoptfinal;
                                      string mcqoptfinalstr1;
                                      mcqoption = multopt;
                                    //  mcqoptfinal = mcqoption.Substring(3, mcqno);
                                      string mcqoptfinalstr = mcqoption.Substring(0, mcqno);
                                      
                                      //mcqoptfinalstr1 = mcqoptfinalstr.Substring(3);
                                     
                                      mcqoptfinalstr1=mcqoptfinalstr.Replace("'../../../","\"../../../");
                                      mcqoptfinalstr1 = mcqoptfinalstr1.Replace(".jpg'>", ".jpg\">");  
                                      mcqmopt[mcqmore] = mcqoptfinalstr1.ToString();
                                  }

                                    if (!multopt.Contains("#A#"))
                                    {
                                        if (multopt.Contains("Pix"))
                                        {
                                            int pi = multopt.IndexOf("#Pix#");
                                            string matchpi = multopt.Substring(multopt.IndexOf("#Pix#"));
                                            string matchpic = matchpi.Substring(5) + ".jpg";
                                            string selopt = multopt.Substring(0, pi);
                                            matchpic = matchpic.Trim();
                                            string pixmatch = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagimage.txt";
                                            string pixmdata = File.ReadAllText(pixmatch);
                                            string pixfindmatch = "imagename";
                                            pixmdata = pixmdata.Replace(pixfindmatch, classnum.ToLower() + "/" + subject.ToLower() + "/" + matchpic);
                                            pixmdata = selopt + pixmdata;
                                            mcqmopt[mcqmore] = pixmdata.ToString();
                                            mcqmore++;
                                        }
                                        else
                                        {
                                            if (multopt.Contains(">      ("))
                                            {
                                                string mulpic;
                                                mulpic = multopt;
                                                mulpic = mulpic.Replace("      ", "<br/>");
                                                mcqmult[mcqmulright] = mulpic.ToString();
                                                mcqmulright++;
                                            }
                                            else
                                            {

                                                mcqmopt[mcqmore] = multopt.ToString();
                                                mcqmore++;

                                            }
                                        }
                                   }
                                    
                                }
                                
                                
                        }

                        if (!mcqlines.Contains("#A#"))
                        {

                            mcqmopt[mcqmore] = mcqlines.ToString();
                            mcqmore++;
                        }
                        else
                        {
                            string multipletemp = "";
                            for (int i = 0; i < mcqmopt.Length; i++)
                            {
                                if ((mcqmopt[i] != null))
                                {
                                    if (i == 0)
                                    {
                                        string multsearch = "Type question here";
                                        outmcq = tagmcqmore.Replace(multsearch, mcqmopt[i]);
                                        mcqmulques++;
                                    }
                                    else
                                    {
                                        //string[] mulsplit = mcqmult[i].Split(new[] { "\t" }, StringSplitOptions.None);
                                        //multitemp += "<div class='checkbox'><label for='checkboxes-0'><input type='checkbox' name='uniqueid' id='checkboxes-0' value='(" + optionvalue[i-1] + ") " + mcqmult[i] + "'>(" + optionvalue[i-1] + ") " + mcqmult[i] + "</label></div>";
                                       // multipletemp += "<div class='checkbox'><label for='checkboxes-0'><input type='checkbox' name='uniqueid' id='checkboxes-0' value='" + mcqmult[i] + "'>" + " " + mcqmult[i] + "</label></div>";

                                        //multitemp += "<div class='checkbox'><label for='checkboxes-0'><input type='checkbox' name='" + mcqmruniqueid + "' id='" + mcqmruniqueid + "' value='" + mcqmult[i] + "'>" + " " + mcqmult[i] + "</label></div>";
                                        string mcqiduniqueid = "mcqid" + mcqlineno.ToString();
                                        if (mcqmopt[i].Contains("'"))
                                        {
                                            mcqmopt[i] = mcqmopt[i].Replace("'", '"'.ToString());
                                        }
                                        multipletemp += "<div class='radio'><label for='radio-0'><input type='radio' name='" + mcqiduniqueid + "' id='" + mcqiduniqueid + "'" + "value='" + mcqmopt[i] + "'>" + " " + mcqmopt[i] + "</label></div>";
                                     
                                    }
                                
                                }

                            }

                            string searchuid = "uniqueid";
                            outmcq = outmcq.Replace(searchuid, mcqlineno++.ToString());
                            string mulsearchoption = "Type options here";
                            outmcq = outmcq.Replace(mulsearchoption, multipletemp);
                            mcqmore = 0;
                            mcqmopt = new string[50];
                           // mcqmult = null;
                            
                        }
                    
                    }

                    File.AppendAllText(dirpath + "\\" + foutputfile, outmcq + Environment.NewLine);
                   
                }

                if  ((mcqcheck)&&lines.Contains("#A#"))
                {
                    string mcqlines;
                    mcqlines = lines;
                    if (mcqlines.Contains("Pix") && (mcqlines.Contains("#A#")))
                    {
                        IniFile loadimg = new IniFile();
                        // loadimg.getimagename(lines);
                        //string oldName = "#Pix#";
                        string imagename = loadimg.getimagename(mcqlines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        mcqlines = regex.Replace(mcqlines, newName);
                        mcqlines = regex1.Replace(mcqlines, newName);
                    }
                    //string outmulans;
                    string amcqmulrtag = "";
                    string mcqmulatag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmulrightanswer.txt";
                    amcqmulrtag = File.ReadAllText(mcqmulatag);


                    string tagmulr = mcqlines.Substring(mcqlines.IndexOf("#A#"));
                    string tagmultr = tagmulr.Substring(4);
                    if (tagmultr.Contains("*"))
                    {
                        string ansstar = "<span style='visibility:hidden' class='splitstar'>*</span>";
                        tagmultr = tagmultr.Replace("*", ansstar);
                    }
                    if (tagmultr.Contains("&"))
                    {
                        tagmultr = tagmultr.Replace("&", "<span style='color: black;' class='splitor'>OR</span>");
                    }
                    string mulans = "Type answer here";
                    amcqmulrtag = amcqmulrtag.Replace(mulans, tagmultr);
                    File.AppendAllText(dirpath + "\\" + foutputfile, amcqmulrtag + Environment.NewLine);
                }  


               
                /*if ((mcqcheck) && (lines.Contains("#A#")))
                {
                       
           
                    mcqlineno = mcqlineno + 1;
                    string mcqstr;
                    string mcqquest = "MCQ";
                    string mcqanswer = "AMCQ";
                    string searchuid = "uniqueid-same-as-feildset";
                    string searchanswerid = "answer uniqueid";
                    string searchuid1 = "uniqueid";
                    string mcqtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmcq.txt";
                    mcqstr = File.ReadAllText(mcqtag);
                    int smcq = lines.IndexOf("#A#");
                    string amcq = lines.Substring(lines.IndexOf("#A#"));
                    string amcq1 = amcq.Substring(4);
                    if (amcq1.Contains("*"))
                    {
                        string ansstar = "<span style='visibility:hidden' class='splitstar'>*</span>";
                        amcq1 = amcq1.Replace("*", ansstar);
                    }
                    if (amcq1.Contains("&"))
                    {
                        amcq1 = amcq1.Replace("&", "<span style='color: black;' class='splitor'>OR</span>");
                    }
                    string smcq1 = lines.Substring(0, smcq);
                    //for pix in question

                    if (smcq1.Contains("Pix"))
                    {
                        IniFile loadimg = new IniFile();
                        string imagename = loadimg.getimagename(smcq1);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum + "/" + subject + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        smcq1 = regex.Replace(smcq1, newName);
                        smcq1 = regex1.Replace(smcq1, newName);
                        if(smcq1.Contains(".jpg'> \t"))
                        {
                            smcq1 = smcq1.Replace(".jpg'> \t", ".jpg'>      ");
                        }
                        if (smcq1.Contains(".jpg'>\t"))
                        {
                            smcq1 = smcq1.Replace(".jpg'>\t", ".jpg'>      ");
                        }
                        //if(smcq1.Contains("\t"))
                    }
                    string[] lineoption = smcq1.Split(new[] { "\t","\r" }, StringSplitOptions.None);
                    foreach (string mcopt in lineoption)
                    {

                        //FOR IMAGE
                        if (smcq1.Contains("Pix") || smcq1.Contains("pix"))
                        {
                            if (mcopt.Contains("Pix") )
                            {
                                int pi = mcopt.IndexOf("#Pix#");
                                string matchpi = mcopt.Substring(mcopt.IndexOf("#Pix#"));
                                string matchpic = matchpi.Substring(5) + ".jpg";
                                matchpic = matchpic.Trim();
                                string pixmatch = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagimage.txt";
                                string pixmdata = File.ReadAllText(pixmatch);
                                string pixfindmatch = "imagename";
                                pixmdata = pixmdata.Replace(pixfindmatch, matchpic);
                                // File.AppendAllText(dirpath + "\\" + foutputfile, pixdata + Environment.NewLine);
                                if (mcopt.Contains("(a)"))
                                {
                                    string searchopt1 = "Type option1 here";
                                    mcqstr = mcqstr.Replace(searchopt1, pixmdata);
                                }
                                if (mcopt.Contains("(b)"))
                                {
                                    string searchopt2 = "Type option2 here";
                                    mcqstr = mcqstr.Replace(searchopt2, pixmdata);
                                }
                                if (mcopt.Contains("(c)"))
                                {
                                    string searchopt3 = "Type option3 here";
                                    mcqstr = mcqstr.Replace(searchopt3, pixmdata);
                                }
                                if (mcopt.Contains("(d)"))
                                {
                                    string searchopt4 = "Type option4 here";
                                    mcqstr = mcqstr.Replace(searchopt4, pixmdata);
                                }
                                if (mcopt.Contains("(e)"))
                                {
                                    string searchopt5 = "Type option5 here";
                                    mcqstr = mcqstr.Replace(searchopt5, pixmdata);
                                }
                                if (mcopt.Contains("(f)"))
                                {
                                    string searchopt6 = "Type option6 here";
                                    mcqstr = mcqstr.Replace(searchopt6, pixmdata);
                                }
                            }

                        }
                        if (lines.Contains("Media-S") || lines.Contains("Media-S"))
                        {
                            if (mcopt.Contains("Media-S") || (lines.Contains("Media-S")))
                            {
                                                                string matmeds = lines.Substring(lines.IndexOf("#Media-S#"));
                                string matmedias = matmeds.Substring(9);
                                matmedias = matmedias.Trim();
                                //string medfname= Path.GetFileNameWithoutExtension(medias);
                                string matmedsext = Path.GetExtension(matmedias);
                                string matmedsou = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagaudio.txt";
                                string matmedsdata = File.ReadAllText(matmedsou);
                                string matmedsfind = "fileextension";
                                string matmedsfnamefind = "filenamewithextension";
                                matmedsdata = matmedsdata.Replace(matmedsfind, matmedsext);
                                matmedsdata = matmedsdata.Replace(matmedsfnamefind,classnum + "/" + subject + "/" + matmedias);
                               
                                
                                // File.AppendAllText(dirpath + "\\" + foutputfile, pixdata + Environment.NewLine);
                                if (mcopt.Contains("(a)"))
                                {
                                    string searchopt1 = "Type option1 here";
                                    mcqstr = mcqstr.Replace(searchopt1, matmedsdata);
                                }
                                if (mcopt.Contains("(b)"))
                                {
                                    string searchopt2 = "Type option2 here";
                                    mcqstr = mcqstr.Replace(searchopt2, matmedsdata);
                                }
                                if (mcopt.Contains("(c)"))
                                {
                                    string searchopt3 = "Type option3 here";
                                    mcqstr = mcqstr.Replace(searchopt3, matmedsdata);
                                }
                                if (mcopt.Contains("(d)"))
                                {
                                    string searchopt4 = "Type option4 here";
                                    mcqstr = mcqstr.Replace(searchopt4, matmedsdata);
                                }
                            }

                        }


                        if (lines.Contains("Media-V") || lines.Contains("Media-V"))
                        {
                            if (mcopt.Contains("Media-V") || (lines.Contains("Media-V")))
                            {
                                string matmedv = lines.Substring(lines.IndexOf("#Media-V#"));
                                string matmediav = matmedv.Substring(9);
                                matmediav = matmediav.Trim();
                                //string medfname= Path.GetFileNameWithoutExtension(medias);
                                string matmedvext = Path.GetExtension(matmediav);
                                string matmedvid = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagvideo.txt";
                                string matmedvdata = File.ReadAllText(matmedvid);
                                string matmedvfind = "fileextension";
                                string matmedvfnamefind = "filenamewithextension";
                                matmedvdata = matmedvdata.Replace(matmedvfind, matmedvext);
                                matmedvdata = matmedvdata.Replace(matmedvfnamefind, classnum + "/" + subject + "/" +matmediav);


                                // File.AppendAllText(dirpath + "\\" + foutputfile, pixdata + Environment.NewLine);
                                if (mcopt.Contains("(a)"))
                                {
                                    string searchopt1 = "Type option1 here";
                                    mcqstr = mcqstr.Replace(searchopt1, matmedvdata);
                                }
                                if (mcopt.Contains("(b)"))
                                {
                                    string searchopt2 = "Type option2 here";
                                    mcqstr = mcqstr.Replace(searchopt2, matmedvdata);
                                }
                                if (mcopt.Contains("(c)"))
                                {
                                    string searchopt3 = "Type option3 here";
                                    mcqstr = mcqstr.Replace(searchopt3, matmedvdata);
                                }
                                if (mcopt.Contains("(d)"))
                                {
                                    string searchopt4 = "Type option4 here";
                                    mcqstr = mcqstr.Replace(searchopt4, matmedvdata);
                                }
                            }

                        }
                        else
                        {
                            if (mcopt.Contains("(a)"))
                            {
                                string searchopt1 = "Type option1 here";
                                mcqstr = mcqstr.Replace(searchopt1, mcopt);
                                searchopt1 = "Type option1 value here";
                                mcqstr = mcqstr.Replace(searchopt1, mcopt);
                            }
                            if (mcopt.Contains("(b)"))
                            {
                                string searchopt2 = "Type option2 here";
                                mcqstr = mcqstr.Replace(searchopt2, mcopt);
                                searchopt2 = "Type option2 value here";
                                mcqstr = mcqstr.Replace(searchopt2, mcopt);
                            }
                            if (mcopt.Contains("(c)"))
                            {
                                string searchopt3 = "Type option3 here";
                                mcqstr = mcqstr.Replace(searchopt3, mcopt);
                                searchopt3 = "Type option3 value here";
                                mcqstr = mcqstr.Replace(searchopt3, mcopt);
                            }
                            if (mcopt.Contains("(d)"))
                            {
                                string searchopt4 = "Type option4 here";
                                mcqstr = mcqstr.Replace(searchopt4, mcopt);
                                searchopt4 = "Type option4 value here";
                                mcqstr = mcqstr.Replace(searchopt4, mcopt);
                            }
                        }

                        
                        string searchmcq = "Type question here";

                        
                        mcqstr = mcqstr.Replace(searchmcq, mcopt);
                                                
                    }


                    // string searchtf = "Type question here";
                    string searchans = "Type answer here";
                    //mcqstr = mcqstr.Replace(searchtf, mcopt);
                    mcqstr = mcqstr.Replace(searchans, amcq1);
                    mcqstr = mcqstr.Replace(searchuid, mcqquest + mcqlineno);
                    mcqstr = mcqstr.Replace(searchanswerid, mcqanswer + mcqlineno);
                    mcqstr = mcqstr.Replace(searchuid1, mcqquest + mcqlineno);
                    File.AppendAllText(dirpath + "\\" + foutputfile, mcqstr + Environment.NewLine);
                    //File.AppendAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt","</form>");

                }*/

                /********************************* /**************MCQ-Multright******************************************/
                if ((mcqmultcheck) && lines.Contains("#Instruction#"))
                {
                    instcount = instcount + 1;
                    string outfilemcq;
                    // outfile = File.ReadAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt");
                    string taginst1 = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taginstruction.txt";
                    outfilemcq = File.ReadAllText(taginst1);
                    string inst = lines.Substring(0, lines.IndexOf(' '));
                    string inst1 = lines.Substring(lines.IndexOf(' ') + 1);
                    string srchinst = "Instructions";
                    string srchinstcount = "uniqueid";
                    outfilemcq = outfilemcq.Replace(srchinst, inst1);
                    outfilemcq = outfilemcq.Replace(srchinstcount, "INST" + instcount);
                    File.AppendAllText(dirpath + "\\" + foutputfile, outfilemcq + Environment.NewLine);
                }

               
                if ((mcqmultcheck) && !lines.Contains("#Instruction#")&&!lines.ToLower().Contains("#type-mcq-multiright#")&& !(lines.Contains("#AssignmentNo#")))
                {
                    //multlineno = multlineno + 1;
                    string multrlines;
                    multrlines = lines;
                    string imagename;
                   
                    if (multrlines.Contains("Pix"))
                    {
                        if (multrlines.Contains("\t#Pix#"))
                        {
                            multrlines = multrlines.Replace("\t#Pix#", "<br/>#Pix#");
                        }
                        IniFile loadimg = new IniFile();
                        imagename = loadimg.getimagename(multrlines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        multrlines = regex.Replace(multrlines, newName);
                        multrlines = regex1.Replace(multrlines, newName);
                        if (multrlines.Contains(".jpg'> \t"))
                        {
                            multrlines = multrlines.Replace(".jpg'> \t", ".jpg'><br/>");
                        }
                        if (multrlines.Contains(".jpg'>\t"))
                        {
                            multrlines = multrlines.Replace(".jpg'>\t", ".jpg'><br/>");
                        }
                       
                    }
                    
                    
                    
                    string mcqmultag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmcqmultiright.txt";
                    string mcqmulrtag = File.ReadAllText(mcqmultag);
                    
                    
                    
                    string outmulmcq = "";

                    //string[] optionvalue = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l" };
                   // string mulsearch = "Type question here";
                    //string outmulmcq = mcqmulrtag.Replace(mulsearch, lines);
                   // string muloption="";
                    //string[] mulsplit = lines.Split(new[] { "\t" }, StringSplitOptions.None);
                    if ((multrlines != null) && (multrlines != "") && (multrlines != " "))
                    {

                       // string multrlines;
                        //multrlines = lines;
                        if (multrlines.Contains(".\t"))
                        {
                            IniFile mcprocess = new IniFile();
                            multrlines = mcprocess.mcqpreprocess(multrlines);
                        }
                        
                     
                        
                        if (multrlines.Contains("\t \t"))
                        {
                            multrlines = multrlines.Replace("\t \t", "\t");
                        }
                        if (multrlines.Contains("\t\t"))
                        {
                            multrlines = multrlines.Replace("\t\t", "\t");
                        }
                        if (multrlines.EndsWith("\t"))
                        {
                            multrlines = multrlines.Replace("\t", "");
                        }
                        
                       
                        if (multrlines.Contains("\t"))
                        {
                            //mcqmult = null;
                            if (multrlines.Contains("<br/>("))
                            {
                                multrlines = multrlines.Replace("<br/>(", "<br/>\t(");
                            }
                            multrlines=multrlines.Replace("\t","\r\n");
                            string[] multarr = multrlines.Split(new[] { "\r\n" }, StringSplitOptions.None);
                            
                                foreach ( string mulopt in multarr)
                                {
                                    if (mulopt.Contains(".jpg") && mulopt.Contains("#A#"))
                                    {
                                        int mcqno = mulopt.IndexOf("#A#");

                                        string mcqoption;
                                        string mcqoptfinal;
                                        string multoptfinalstr1;
                                        mcqoption = mulopt;
                                        //mcqoptfinal = mcqoption.Substring(3, mcqno);
                                        string mcqoptfinalstr = mcqoption.Substring(0, mcqno);

                                        multoptfinalstr1 = mcqoptfinalstr.Substring(3);

                                        multoptfinalstr1 = multoptfinalstr1.Replace("'../../../", "\"../../../");
                                        multoptfinalstr1 = multoptfinalstr1.Replace(".jpg'>", ".jpg\">");
                                        mcqoptfinal = mcqoption.Substring(0, mcqno);
                                        mcqmopt[mcqmore] = mcqoptfinal.ToString();
                                        
                                        
                                    }
                                    if (!mulopt.Contains("#A#"))
                                    {

                                        if (mulopt.Contains("Pix"))
                                        {
                                            int pi = mulopt.IndexOf("#Pix#");
                                            string matchpi = mulopt.Substring(mulopt.IndexOf("#Pix#"));
                                            string matchpic = matchpi.Substring(5) + ".jpg";
                                            string selopt = mulopt.Substring(0, pi);
                                            matchpic = matchpic.Trim();
                                            string pixmatch = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagimage.txt";
                                            string pixmdata = File.ReadAllText(pixmatch);
                                            string pixfindmatch = "imagename";
                                            pixmdata = pixmdata.Replace(pixfindmatch, classnum.ToLower() + "/" + subject.ToLower() + "/" + matchpic);
                                           // mcqmopt[mcqmore] = pixmdata.ToString();
                                           // mcqmore++;
                                            pixmdata = selopt + pixmdata;
                                            mcqmult[mcqmulright] = pixmdata.ToString(); ;
                                            mcqmulright++;
                                        }
                                        else
                                        {
                                            if (mulopt.Contains(">      ("))
                                            {
                                                string mulpic;
                                                mulpic = mulopt;
                                                mulpic = mulpic.Replace("      ", "<br/>");
                                                mcqmult[mcqmulright] = mulpic.ToString();
                                                mcqmulright++;
                                            }
                                            else
                                            {
                                                mcqmult[mcqmulright] = mulopt.ToString();
                                                mcqmulright++;
                                            }
                                           /// mcqmopt[mcqmore] = mulopt.ToString();
                                           // mcqmore++;
                                        }
                                   }
                                    
                                }
                                
                                
                        }
                       
                        if (!multrlines.Contains("#A#"))
                        {

                            mcqmult[mcqmulright] = multrlines.ToString();
                            mcqmulright++;
                        }
                        else
                        {
                            string multitemp = "";
                            for (int i = 0; i < mcqmult.Length; i++)
                            {
                                if ((mcqmult[i] != null))
                                {
                                    if (i == 0)
                                    {
                                        
                                        string mulsearch = "Type question here";
                                        outmulmcq = mcqmulrtag.Replace(mulsearch,  mcqmult[i]);
                                        mcqmulques++;
                                    }
                                    else
                                    {
                                        string mcqmruniqueid = "mcqmr" + multlineno.ToString();
                                        //string[] mulsplit = mcqmult[i].Split(new[] { "\t" }, StringSplitOptions.None);
                                        //multitemp += "<div class='checkbox'><label for='checkboxes-0'><input type='checkbox' name='uniqueid' id='checkboxes-0' value='(" + optionvalue[i-1] + ") " + mcqmult[i] + "'>(" + optionvalue[i-1] + ") " + mcqmult[i] + "</label></div>";
                                        if (mcqmult[i].Contains("'")) {
                                            mcqmult[i] = mcqmult[i].Replace("'", '"'.ToString());
                                        }
                                        multitemp += "<div class='checkbox'><label for='checkboxes-0'><input type='checkbox' name='" + mcqmruniqueid + "' id='" + mcqmruniqueid + "' value='" + mcqmult[i] + "'>" + " " + mcqmult[i] + "</label></div>";
                                        
                                    }
                                    
                                }

                            }

                            string searchuid = "uniqueid";
                            outmulmcq = outmulmcq.Replace(searchuid, multlineno++.ToString());
                            string mulsearchoption = "Type options here";
                            outmulmcq = outmulmcq.Replace(mulsearchoption, multitemp);
                            mcqmulright = 0;
                            mcqmult = new string[50];
                           // mcqmult = null;
                            
                        }
                    
                    }
                   
                    File.AppendAllText(dirpath + "\\" + foutputfile, outmulmcq + Environment.NewLine);
                   
                }

                if  ((mcqmultcheck)&&lines.Contains("#A#"))
                {
                    string mcqmultlines;
                    mcqmultlines = lines;
                    if (mcqmultlines.StartsWith("#A#"))
                    {
                        mcqmultlines = mcqmultlines.Replace("#A#", "\t#A#");
                    }
                    if (mcqmultlines.Contains("Pix") && (mcqmultlines.Contains("#A#")))
                    {
                        IniFile loadimg = new IniFile();
                        // loadimg.getimagename(lines);
                        //string oldName = "#Pix#";
                        string imagename = loadimg.getimagename(mcqmultlines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        mcqmultlines = regex.Replace(mcqmultlines, newName);
                        mcqmultlines = regex1.Replace(mcqmultlines, newName);
                    }
                    //string outmulans;
                    string amcqmulrtag = "";
                    string mcqmulatag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmulrightanswer.txt";
                    amcqmulrtag = File.ReadAllText(mcqmulatag);


                    string tagmulr = mcqmultlines.Substring(mcqmultlines.IndexOf("#A#"));
                    string tagmultr = tagmulr.Substring(4);
                    if (tagmultr.Contains("*"))
                    {
                        string ansstar = "<span style='visibility:hidden' class='splitstar'>*</span>";
                        tagmultr = tagmultr.Replace("*", ansstar);
                    }
                    if (tagmultr.Contains("&"))
                    {
                        tagmultr = tagmultr.Replace("&", "<span style='color: black;' class='splitor'>OR</span>");
                    }
                    string mulans = "Type answer here";
                    amcqmulrtag = amcqmulrtag.Replace(mulans, tagmultr);
                    File.AppendAllText(dirpath + "\\" + foutputfile, amcqmulrtag + Environment.NewLine);
                }  



                //***************************************LAQ*********************************************************//

                if ((laqcheck) && lines.Contains("#Instruction#"))
                {
                    string laqlines;
                    laqlines = lines;
                    if (laqlines.Contains("Pix"))
                    {
                        IniFile loadimg = new IniFile();
                        string imagename = loadimg.getimagename(laqlines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        laqlines = regex.Replace(laqlines, newName);
                        laqlines = regex1.Replace(laqlines, newName);
                    }
                    
                    
                    instcount = instcount + 1;
                    string outfilelaq;
                    // outfile = File.ReadAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt");
                    string taginst1 = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taginstruction.txt";
                    outfilelaq = File.ReadAllText(taginst1);
                    string inst = lines.Substring(0, lines.IndexOf(' '));
                    string inst1 = lines.Substring(lines.IndexOf(' ') + 1);
                    string srchinst = "Instructions";
                    string srchinstcount = "uniqueid";
                    outfilelaq = outfilelaq.Replace(srchinst, inst1);
                    outfilelaq = outfilelaq.Replace(srchinstcount, "INST" + instcount);
                    File.AppendAllText(dirpath + "\\" + foutputfile, outfilelaq + Environment.NewLine);
                }


                if ((laqcheck) && (lines.StartsWith("#Pix") && !(lines.Contains("#Instruction#")) && !(lines.Contains("#A#"))))
                {
                    string laqlines;
                    laqlines = lines;

                    IniFile loadimg = new IniFile();
                    // loadimg.getimagename(lines);
                    //string oldName = "#Pix#";
                    string imagename = loadimg.getimagename(laqlines);
                    string oldName1 = "#Pix#" + imagename;
                    string oldName2 = "#Pix# " + imagename;
                    string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                    System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                    System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                    laqlines = regex.Replace(laqlines, newName);
                    laqlines = regex1.Replace(laqlines, newName);

                    File.AppendAllText(dirpath + "\\" + foutputfile, laqlines + Environment.NewLine);


                }





                if ((!asischeck) && (laqcheck) && !(lines.Contains("#Instruction#")) && !(lines.ToLower().Contains("#type-laq")) && !(lines.Contains("AssignmentNo# ")) && (lines != "") && !(lines.ToLower().Contains("#asis#")) && !(lines.ToLower().Contains("#asisend#")) && !(lines.ToLower().StartsWith("#always")) && !(lines.ToLower().StartsWith("#end")))
                {
                    string laqlines;
                    laqlines = lines;
                    if (!(laqlines.Contains("#A#")))
                    {
                        laqlines = laqlines + "#A# ";

                    }

                    if (laqlines.Contains("Pix") && (lines.Contains("#A#")))
                    {
                        IniFile loadimg = new IniFile();
                        // loadimg.getimagename(lines);
                        //string oldName = "#Pix#";
                        string imagename = loadimg.getimagename(laqlines);
                        string oldName1 = "#Pix#" + imagename;
                        string oldName2 = "#Pix# " + imagename;
                        string newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                        System.Text.RegularExpressions.Regex regex = new Regex(oldName1, RegexOptions.IgnoreCase);
                        System.Text.RegularExpressions.Regex regex1 = new Regex(oldName2, RegexOptions.IgnoreCase);
                        laqlines = regex.Replace(laqlines, newName);
                        laqlines = regex1.Replace(laqlines, newName);
                        if (laqlines.Contains(".jpg'>\t"))
                        {
                            laqlines = laqlines.Replace(".jpg'>\t", ".jpg'><br/>");
                        }
                        
                    }
                    if ((!laqlines.Contains("#Pix"))  && (laqlines != ""))
                    {

                        laqlineno = laqlineno + 1;
                        string laqstr;
                        string finalfilter;
                        string laqquest = "LAQ";
                        string saqanswer = "ASA";
                        string searchuid = "unique-textarea1";
                        string searchanswerid = "answer uniqueid";
                        string searchuid1 = "same-uniqueid-as-label";
                        string laqtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taglaq.txt";
                        laqstr = File.ReadAllText(laqtag);
                        int laqqs = laqlines.IndexOf("#A#");
                        string answer = "#A#";
                        int ans = answer.Length;
                        string alaq = laqlines.Substring(laqlines.IndexOf("#A#"));
                        string alaq1 = alaq.Substring(ans);
                        if (alaq1.Contains("*"))
                        {
                            string ansstar = "<span style='visibility:hidden' class='splitstar'>*</span>";
                            alaq1 = alaq1.Replace("*", ansstar);
                        }
                        if (alaq1.Contains("&"))
                        {
                            alaq1 = alaq1.Replace("&", "<span style='color: black;' class='splitor'>OR</span>");
                        }
                        string laqqes = laqlines.Substring(0, laqqs);
                        string searchtf = "Type question here";
                        string searchans = "Type answer here";

                        if (laqqes.Contains("#"))
                        {

                            int c = laqqes.IndexOf("#");
                            int c1 = laqqes.LastIndexOf("#");
                            int length = c1 - c + 1;
                            string part = laqqes.Substring(c, length);
                            string[] checkitem = part.Split(new[] { "#" }, StringSplitOptions.None);
                            string[] filteritem = new string[10];
                            int counter = 0;
                            //string[] newcheck=checkitem.Except()
                            foreach (string filter in checkitem)
                            {
                                if (filter.ToLower().Contains("box"))
                                {
                                    //mbx.Except(bxrm);
                                }
                                else if (filter != "")
                                {
                                    filteritem[counter++] = filter;
                                }

                            }

                            finalfilter = String.Join(" ", filteritem);
                            finalfilter = finalfilter.Trim();
                            finalfilter = finalfilter.Replace(" ", "# #");
                            finalfilter = finalfilter.Replace("##", " ");
                            finalfilter = "#" + finalfilter + "#";
                            finalfilter = finalfilter.Replace("##", "");
                            alaq1 = finalfilter + alaq1;
                        }
                        //MBOX SBOXif (saqqes.Contains("Box"))
                        if (laqqes.Contains("Box"))
                        {
                            String mboxstr;
                            string mboxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsaqmbox.txt";
                            mboxstr = File.ReadAllText(mboxtag);
                            string[] mbx = laqqes.Split(new[] { "#" }, StringSplitOptions.None);
                            mboxstr = mboxstr.Replace(searchtf, mbx[0].ToString());
                            mboxstr = mboxstr.Replace(searchans, alaq1);
                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxstr + Environment.NewLine);
                            string mbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmbox.txt";
                            string mbxstr = File.ReadAllText(mbxtag);
                            foreach (string boxopt in mbx)
                            {

                                if (boxopt.ToLower().Contains("mbox"))
                                {
                                    string mbxoutput = mbxstr;
                                    string[] mbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                    // for multiple boxes
                                    string mbxno = mbxopt[1];
                                    int mboxno = Convert.ToInt32(mbxno);
                                    int m;
                                    //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                    if (mboxno > 1)
                                    {
                                        int sno = mbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = mbxopt[2];
                                            string searchbx = "Answer";
                                            mbxoutput = mbxoutput.Replace(searchbx, sbxans);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxoutput + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {
                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                        }

                                        for (m = 1; m < mboxno; m++)
                                        {
                                            string mbxnumber = @"<input id='SAQ3' name='SAQ3' type='text' placeholder='' class='form-control input-md saqm vsaqregular' autocorrect='off' autocapitalize='none'>";
                                            //string mnostr = "paste here";
                                            //mbxoutput = mbxstr.Replace(mnostr, mbxnumber);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                        }
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                    if (mboxno == 1)
                                    {
                                        string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmbox.txt";
                                        string mboxonestr = File.ReadAllText(mboxone);
                                        int sno = mbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = mbxopt[2];
                                            string searchbx = "Answer";
                                            mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                        //   File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                }
                                //sbox

                                if (boxopt.ToLower().Contains("sbox"))
                                {
                                    string sbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsbox.txt";
                                    string sbxstr = File.ReadAllText(sbxtag);
                                    string sbxoutput = sbxstr;
                                    string[] sbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                    // for multiple boxes
                                    string sbxno = sbxopt[1];
                                    int sboxno = Convert.ToInt32(sbxno);
                                    int s;
                                    //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                    if (sboxno > 1)
                                    {
                                        int sno = sbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = sbxopt[2];
                                            string searchbx = "Answer";
                                            sbxoutput = sbxoutput.Replace(searchbx, sbxans);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, sbxoutput + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {
                                            File.AppendAllText(dirpath + "\\" + foutputfile, sbxstr + Environment.NewLine);
                                        }

                                        for (s = 1; s < sboxno; s++)
                                        {
                                            // string mbxnumber = @"<input id='SAQ3' name='SAQ3' type='text' placeholder='' class='form-control input-md saqm' autocorrect='off' autocapitalize='none'>";
                                            string mbxnumber = @"<input id='SAQS1' name='SAQS1' type='text' placeholder='' class='form-control input-md saqs vsaqregular' autocorrect='off' autocapitalize='none'>";

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                        }
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        //  File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                    if (sboxno == 1)
                                    {
                                        string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsbox.txt";
                                        string mboxonestr = File.ReadAllText(mboxone);
                                        int sno = sbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = sbxopt[2];
                                            string searchbx = "Answer";
                                            mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                        // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                }

                                //Lbox

                                if (boxopt.ToLower().Contains("lbox"))
                                {

                                    if (boxopt.ToLower().Contains("nousualbox"))
                                    {
                                    }                                  
                                    else
                                    {
                                    string lbxtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taglbox.txt";
                                    string lbxstr = File.ReadAllText(lbxtag);
                                    string lbxoutput = lbxstr;
                                    string[] lbxopt = boxopt.Split(new[] { "-" }, StringSplitOptions.None);
                                    // for multiple boxes
                                    string lbxno = lbxopt[1];
                                    int lboxno = Convert.ToInt32(lbxno);
                                    int l;
                                    //File.AppendAllText(dirpath + "\\" + foutputfile, mbxstr + Environment.NewLine);
                                    if (lboxno > 1)
                                    {
                                        int sno = lbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = lbxopt[2];
                                            string searchbx = "Answer";
                                            lbxoutput = lbxoutput.Replace(searchbx, sbxans);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, lbxoutput + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {
                                            File.AppendAllText(dirpath + "\\" + foutputfile, lbxstr + Environment.NewLine);
                                        }

                                        for (l = 1; l < lboxno; l++)
                                        {

                                            string mbxnumber = @"<input id='SAQ4' name='SAQ4' type='text' placeholder='' class='form-control input-md saqlg vsaqregular' autocorrect='off' autocapitalize='none'>";
                                            File.AppendAllText(dirpath + "\\" + foutputfile, mbxnumber + Environment.NewLine);
                                        }
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</label>" + Environment.NewLine);
                                        File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                    if (lboxno == 1)
                                    {
                                        string mboxone = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taglbox.txt";
                                        string mboxonestr = File.ReadAllText(mboxone);
                                        int sno = lbxopt.Count();
                                        if (sno > 2)
                                        {
                                            string sbxans = lbxopt[2];
                                            string searchbx = "Answer";
                                            mboxonestr = mboxonestr.Replace(searchbx, sbxans);

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                        if (sno <= 2)
                                        {

                                            File.AppendAllText(dirpath + "\\" + foutputfile, mboxonestr + Environment.NewLine);
                                            File.AppendAllText(dirpath + "\\" + foutputfile, "</div>" + Environment.NewLine);
                                        }
                                        // File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);
                                    }
                                    }
                                    
                                }

                            }
                            string anstag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\answertag.txt";
                            string anstagstr = File.ReadAllText(anstag);
                            anstagstr = anstagstr.Replace(searchans, alaq1);
                            File.AppendAllText(dirpath + "\\" + foutputfile, anstagstr + Environment.NewLine);

                        }
                        else
                        {
                            if (laqqes.Contains("#"))
                            {
                                int c = laqqes.IndexOf("#");
                                laqqes = laqqes.Substring(0, c);
                            }

                            laqstr = laqstr.Replace(searchtf, laqqes);
                            laqstr = laqstr.Replace(searchans, alaq1);
                            laqstr = laqstr.Replace(searchuid, laqquest + laqlineno);
                            laqstr = laqstr.Replace(searchanswerid, saqanswer + saqlineno);
                            laqstr = laqstr.Replace(searchuid1, laqquest + laqlineno);
                            File.AppendAllText(dirpath + "\\" + foutputfile, laqstr + Environment.NewLine + Environment.NewLine);
                            //File.AppendAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt","</form>");
                        }
                    }
                }


                //***************************************Match the following*********************************************************//

                if ((matchcheck) && lines.Contains("#Instruction#"))
                {
                    instcount = instcount + 1;
                    string outfilelaq;
                    // outfile = File.ReadAllText("D:\\sithara\\Bharati Bhavan 22-7-20\\Project-c#\\BBPD.txt");
                    string taginst1 = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\taginstruction.txt";
                    outfilelaq = File.ReadAllText(taginst1);
                    string inst = lines.Substring(0, lines.IndexOf(' '));
                    string inst1 = lines.Substring(lines.IndexOf(' ') + 1);
                    string srchinst = "Instructions";
                    string srchinstcount = "uniqueid";
                    outfilelaq = outfilelaq.Replace(srchinst, inst1);
                    outfilelaq = outfilelaq.Replace(srchinstcount, "INST" + instcount);
                    File.AppendAllText(dirpath + "\\" + foutputfile, outfilelaq + Environment.NewLine);
                }

                if ((matchcheck) && !(lines.Contains("#Instruction#")) && !(lines.ToLower().Contains("#type-match#")))
                {
                    //normal match

                    string matchtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmatch.txt";
                    matchanswer = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmatchv2answer.txt";
                    if (lines.Contains("#Columns2#"))
                    {
                        col = 2;
                        matchtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmatch.txt";
                    }
                    else if (lines.Contains("#Columns3#") || (col == 3))
                    {
                        if ((col == 3) && mat3)
                        {
                            matchtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmatchv3.txt";
                        }
                        else
                        {
                            matchtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmatch3col.txt";
                        }
                        col = 3;

                    }
                    else if (lines.Contains("#Columns2-") || mat2)
                    {
                        col = 2;
                        matchtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmatchV2.txt";
                    }
                    else if (lines.Contains("#Columns3-") || mat3)
                    {
                        col = 3;
                        matchtag = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmatchv3.txt";
                    }
                    string matchstr = File.ReadAllText(matchtag);
                    string matchreplace = matchstr;

                    string matchans = File.ReadAllText(matchanswer);
                    string matchvans = matchans;

                    if (lines.Contains("#Columns2-"))
                    {
                        mat2 = true;
                        newmatchcolumnstag = lines.ToString();
                    }
                    if (lines.Contains("#Columns3-"))
                    {
                        mat3 = true;
                        newmatchcolumnstag = lines.ToString();
                    }

                    if ((matchcheck) && (lines.Contains("#Header#")))
                    {
                        headerlines = lines;

                        // headerlines = headerlines.Replace("\t", "\r\n");
                        headercheck = true;

                    }
                    if (headercheck)
                    {
                        if (colcount < col)
                        {
                            //if (col == 2)
                            //{
                            if (colcount == 0)
                            {
                                int mcol2 = headerlines.IndexOf("#Header#");
                                string hr = "#Header#";
                                int hrlen = hr.Length;
                                if (headerlines.Contains("     "))
                                {
                                    headerlines = headerlines.Replace("             ", "\t");
                                }
                                if (headerlines.Contains("#Header# \t"))
                                {
                                    headerlines = headerlines.Replace("#Header# \t", "#Header# ");
                                }
                                if (headerlines.Contains("#Header#\t"))
                                {
                                    headerlines = headerlines.Replace("#Header#\t", "#Header# ");
                                }
                                if (headerlines.Contains("\t"))
                                {
                                    headerlines = headerlines.Replace("\t\t\t\t\t\t", "\t");
                                    headerlines = headerlines.Replace("\t\t\t\t\t", "\t");
                                    headerlines = headerlines.Replace("\t\t\t\t", "\t");
                                    headerlines = headerlines.Replace("\t\t\t", "\t");
                                    headerlines = headerlines.Replace("\t\t\t", "\t");
                                    headerlines = headerlines.Replace("\t\t", "\t");
                                    headerlines = headerlines.Replace("\t", "\r\n");

                                    //string[] headerlines1= new headerlines.Split{"\r\n"};
                                    string[] headerlines1 = headerlines.Split(new[] { "\r\n" }, StringSplitOptions.None);
                                    //matchcol[colcount++] = headerlines1[1];
                                    String matcolh = headerlines1[0].Substring(headerlines.IndexOf("#Header#"));
                                    string matcolhval = matcolh.Substring(hrlen);
                                    //matchcol[0]=matcolhval;
                                    // matchcol[0] = headerlines1[0];
                                    matchcol[colcount++] = matcolhval;
                                    matchcol[colcount++] = headerlines1[1];

                                }
                                else
                                {
                                    string matcol = headerlines.Substring(headerlines.IndexOf("#Header#"));
                                    string matcolval = matcol.Substring(hrlen);
                                    matchcol[colcount++] = matcolval;
                                    //matchcol[colcount++] = matcolval;
                                }

                            }
                            else
                            {
                                matchcol[colcount++] = lines;
                            }
                            //}
                        }
                        else
                        {
                            if ((col == 2) || (col == 3))
                            {
                                string matchheader = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmatchheader.txt";
                                string matchhead = File.ReadAllText(matchheader);
                                string matchheadrep = matchhead;
                                string some = "";
                                for (int i = 0; i < col; i++)
                                {
                                    some += @"<div>
    		<label class='col-form-label question'>" + matchcol[i] + @"</label>
    	</div>";
                                }
                                string matchf = "Paste here";
                                matchheadrep = matchheadrep.Replace(matchf, some);
                                File.AppendAllText(dirpath + "\\" + foutputfile, matchheadrep);
                            }

                            colcount = 0;
                            headercheck = false;
                        }

                    }

                    linecount = linecount + 1;
                    if (lines.Contains("#A#"))
                    {
                        //#A# with last question
                        if (lines.Contains("\t"))
                        {
                            string mlines;
                            mlines = lines;
                            int m = mlines.IndexOf("#A#");
                            string newmatch = mlines.Substring(0, m);
                            if ((ileft == 0) || (leftmatch == true))
                            {
                                leftcol[ileft++] = newmatch.ToString();
                                // ileft++;
                                leftmatch = false;
                                rightmatch = true;
                            }
                            else if (rightmatch)
                            {
                               rightcol[iright++] = newmatch.ToString();
                                
                                rightmatch = false;
                                // iright++;
                                
                                if (mat2)
                                {
                                    leftmatch = true;
                                }

                                if (mat3)
                                {
                                    thirdcolmatch = true;
                                }
                            }
                            else if (thirdcolmatch)
                            {
                                thirdcolmatch = false;

                                leftmatch = true;
                                thirdcol[threecol++] = newmatch.ToString();
                            }
                        }
                        //
                        string matans = lines.Substring(lines.IndexOf("#A#"));
                        string tagmatchanswer = matans.Substring(4);
                        string ansreplace = "Type answer here";


                        string[] optionvalue = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l","m","n","o","p","q","r","s","t","u","v","w","x","y","z" };
                        string[] optionvalue2 = { "i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x","xi","xii","xiii","xiv","xv","xvi","xvii","xviii","xix","xx","xxi","xxii","xxiii","xxiv","xxv","xxvi" };
                        string optionmatch = "";
                        string optionmatch2 = "";

                        for (int j = 0; j < iright; j++)
                        {
                            var result = rightcol[0].Trim();
                            if (rightcol[0].Trim().StartsWith("<")) {
                                result=Regex.Replace(rightcol[0], "<.*?>", string.Empty);
                            }
                            if (rightcol[j] != "" && rightcol[j] != " " && rightcol[j] != "\t") { 
                            
                                if (result.StartsWith("(a)") || result.StartsWith("a"))
                                {
                                    optionmatch += "<option value='(" + optionvalue[j] + ")'>(" + optionvalue[j] + ")</option>" + Environment.NewLine;
                                }
                                else
                                    optionmatch += "<option value='(" + optionvalue2[j] + ")'>(" + optionvalue2[j] + ")</option>" + Environment.NewLine;
                            }
                        }
                        if (col == 3)
                        {
                            for (int j = 0; j < threecol; j++)
                            {
                                var result = thirdcol[0].Trim();
                                if (thirdcol[0].Trim().StartsWith("<"))
                                {
                                    result = Regex.Replace(thirdcol[0], "<.*?>", string.Empty);
                                }
                                    
                                if (result.StartsWith("(i)") || (result.StartsWith("i")))
                                {
                                    optionmatch2 += "<option value='(" + optionvalue2[j] + ")'>(" + optionvalue2[j] + ")</option>" + Environment.NewLine;

                                }
                                else
                                    optionmatch2 += "<option value='(" + optionvalue[j] + ")'>(" + optionvalue[j] + ")</option>" + Environment.NewLine;
                            }
                        }
                        for (int k = 0; k < iright; k++)
                        {
                            matchstr = matchreplace;
                            string leftreplace = "Type left question here";
                            string lefttemp = leftcol[k];
                            string righttemp = rightcol[k];
                            if (lefttemp.Contains("Pix") || lefttemp.Contains("pix"))
                            {
                                string[] prelpic = lefttemp.Split(new[] { "#" }, StringSplitOptions.None);
                                string piclno = prelpic[0];
                                int pi = lefttemp.IndexOf("#Pix#");
                                string mpic = lefttemp.Substring(lefttemp.IndexOf("#Pix#"));
                                string mapic = mpic.Substring(5) + ".jpg";
                                mapic = mapic.Trim();
                                string pixmatch = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagimage.txt";
                                string pixmdata = File.ReadAllText(pixmatch);
                                string pixfindmatch = "imagename";
                                pixmdata = pixmdata.Replace(pixfindmatch, classnum.ToLower() + "/" + subject.ToLower() + "/" + mapic);
                               // pixmdata = " " + (k + 1) + ". " + pixmdata;
                                pixmdata = " " + piclno + pixmdata;
                                matchstr = matchstr.Replace(leftreplace, pixmdata);
                            }
                            if (lefttemp.Contains("Media-S"))
                            {
                                string matmeds = lefttemp.Substring(lefttemp.IndexOf("#Media-S#"));
                                string matmedias = matmeds.Substring(9);
                                matmedias = matmedias.Trim();
                                //string medfname= Path.GetFileNameWithoutExtension(medias);
                                string matmedsext = Path.GetExtension(matmedias);
                                string matmedsou = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagaudio.txt";
                                string matmedsdata = File.ReadAllText(matmedsou);
                                string matmedsfind = "fileextension";
                                string matmedsfnamefind = "filenamewithextension";
                                matmedsdata = matmedsdata.Replace(matmedsfind, matmedsext);
                                matmedsdata = matmedsdata.Replace(matmedsfnamefind,classnum.ToLower() + "/" + subject.ToLower() + "/" + matmedias);
                                matchstr = matchstr.Replace(leftreplace, matmedsdata);
                            }


                            if (lefttemp.Contains("Media-V"))
                            {
                                string matmedv = lefttemp.Substring(lefttemp.IndexOf("#Media-V#"));
                                string matmediav = matmedv.Substring(9);
                                matmediav = matmediav.Trim();
                                //string medfname= Path.GetFileNameWithoutExtension(medias);
                                string matmedvext = Path.GetExtension(matmediav);
                                string matmedvid = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagvideo.txt";
                                string matmedvdata = File.ReadAllText(matmedvid);
                                string matmedvfind = "fileextension";
                                string matmedvfnamefind = "filenamewithextension";
                                matmedvdata = matmedvdata.Replace(matmedvfind, matmedvext);
                                matmedvdata = matmedvdata.Replace(matmedvfnamefind, classnum.ToLower() + "/" + subject.ToLower() + "/" +matmediav);
                                matchstr = matchstr.Replace(leftreplace, matmedvdata);
                            }
                            else
                            {
                                matchstr = matchstr.Replace(leftreplace, lefttemp);
                                //matchstr = matchstr.Replace(searchans, anmatch);

                            }

                            string rightreplace = "Type right answer here";
                            if (righttemp.Contains("Pix") || righttemp.Contains("pix"))
                            {
                                string[] prerpic = righttemp.Split(new[] { "#" }, StringSplitOptions.None);
                                string picrno = prerpic[0];
                                int pi = righttemp.IndexOf("#Pix#");
                                string mpic = righttemp.Substring(righttemp.IndexOf("#Pix#"));
                                string mapic = mpic.Substring(5) + ".jpg";
                                mapic = mapic.Trim();
                                string pixmatch = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagimage.txt";
                                string pixmdata = File.ReadAllText(pixmatch);
                                string pixfindmatch = "imagename";
                                pixmdata = pixmdata.Replace(pixfindmatch, classnum.ToLower() + "/" + subject.ToLower() + "/" + mapic);
                                //pixmdata = " " + (k + 1) + ". " + pixmdata;
                                pixmdata = " " + picrno +  pixmdata;
                                matchstr = matchstr.Replace(rightreplace, pixmdata);
                            }
                            if (righttemp.Contains("Media-S"))
                            {
                                string matmeds = righttemp.Substring(righttemp.IndexOf("#Media-S#"));
                                string matmedias = matmeds.Substring(9);
                                matmedias = matmedias.Trim();
                                //string medfname= Path.GetFileNameWithoutExtension(medias);
                                string matmedsext = Path.GetExtension(matmedias);
                                string matmedsou = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagaudio.txt";
                                string matmedsdata = File.ReadAllText(matmedsou);
                                string matmedsfind = "fileextension";
                                string matmedsfnamefind = "filenamewithextension";
                                matmedsdata = matmedsdata.Replace(matmedsfind, matmedsext);
                                matmedsdata = matmedsdata.Replace(matmedsfnamefind,classnum.ToLower() + "/" + subject.ToLower() + "/" + matmedias);
                                matchstr = matchstr.Replace(rightreplace, matmedsdata);
                            }


                            if (righttemp.Contains("Media-V"))
                            {
                                string matmedv = righttemp.Substring(righttemp.IndexOf("#Media-V#"));
                                string matmediav = matmedv.Substring(9);
                                matmediav = matmediav.Trim();
                                //string medfname= Path.GetFileNameWithoutExtension(medias);
                                string matmedvext = Path.GetExtension(matmediav);
                                string matmedvid = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagvideo.txt";
                                string matmedvdata = File.ReadAllText(matmedvid);
                                string matmedvfind = "fileextension";
                                string matmedvfnamefind = "filenamewithextension";
                                matmedvdata = matmedvdata.Replace(matmedvfind, matmedvext);
                                matmedvdata = matmedvdata.Replace(matmedvfnamefind, classnum + "/" + subject + "/" +matmediav);
                                matchstr = matchstr.Replace(rightreplace, matmedvdata);
                            }


                            else
                            {
                                matchstr = matchstr.Replace(rightreplace, righttemp);
                            }
                            if (!mat2 && !mat3)
                            {
                                if (leftcol[k] != null && leftcol[k] != "" && leftcol[k] != " ")
                                {
                                    String opt = "Type option here";
                                    string finaloption = @"<select class='form-control' id='uniqueid' name='same-uniqueid-as-label'>
				    <option></option>" + optionmatch + @"</select>";
                                    matchstr = matchstr.Replace(opt, finaloption);
                                }
                                else
                                {
                                    String opt = "Type option here";
                                    matchstr = matchstr.Replace(opt, "");
                                }
                            }
                            if (col == 3)
                            {
                                string thirdplace = "column 3";
                                string thirdtemp = thirdcol[k];
                                if ((thirdtemp != null) && (thirdtemp.Contains("Pix") || thirdtemp.Contains("pix")))
                                {
                                    int pi = thirdtemp.IndexOf("#Pix#");
                                    string mpic = thirdtemp.Substring(thirdtemp.IndexOf("#Pix#"));
                                    string mapic = mpic.Substring(5) + ".jpg";
                                    mapic = mapic.Trim();
                                    string pixmatch = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagimage.txt";
                                    string pixmdata = File.ReadAllText(pixmatch);
                                    string pixfindmatch = "imagename";
                                    pixmdata = pixmdata.Replace(pixfindmatch, classnum.ToLower() + "/" + subject.ToLower() + "/" + mapic);
                                    pixmdata = " " + (k + 1) + ". " + pixmdata;
                                    matchstr = matchstr.Replace(thirdplace, pixmdata);
                                }
                                if ((thirdtemp != null) && thirdtemp.Contains("Media-S"))
                                {
                                    string matmeds = thirdtemp.Substring(thirdtemp.IndexOf("#Media-S#"));
                                    string matmedias = matmeds.Substring(9);
                                    matmedias = matmedias.Trim();
                                    //string medfname= Path.GetFileNameWithoutExtension(medias);
                                    string matmedsext = Path.GetExtension(matmedias);
                                    string matmedsou = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagaudio.txt";
                                    string matmedsdata = File.ReadAllText(matmedsou);
                                    string matmedsfind = "fileextension";
                                    string matmedsfnamefind = "filenamewithextension";
                                    matmedsdata = matmedsdata.Replace(matmedsfind, matmedsext);
                                    matmedsdata = matmedsdata.Replace(matmedsfnamefind,classnum.ToLower() + "/" + subject.ToLower() + "/" + matmedias);
                                    matchstr = matchstr.Replace(thirdplace, matmedsdata);
                                }


                                if ((thirdtemp != null) && thirdtemp.Contains("Media-V"))
                                {
                                    string matmedv = thirdtemp.Substring(thirdtemp.IndexOf("#Media-V#"));
                                    string matmediav = matmedv.Substring(9);
                                    matmediav = matmediav.Trim();
                                    //string medfname= Path.GetFileNameWithoutExtension(medias);
                                    string matmedvext = Path.GetExtension(matmediav);
                                    string matmedvid = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagvideo.txt";
                                    string matmedvdata = File.ReadAllText(matmedvid);
                                    string matmedvfind = "fileextension";
                                    string matmedvfnamefind = "filenamewithextension";
                                    matmedvdata = matmedvdata.Replace(matmedvfind, matmedvext);
                                    matmedvdata = matmedvdata.Replace(matmedvfnamefind, classnum.ToLower() + "/" + subject.ToLower() + "/" +matmediav);
                                    matchstr = matchstr.Replace(thirdplace, matmedvdata);
                                }
                                else
                                {
                                    matchstr = matchstr.Replace(thirdplace, thirdtemp);
                                }
                                if (!mat3)
                                {
                                    // option is written here
                                    if (rightcol[k] != null && rightcol[k] != "" && rightcol[k] != " ")
                                    {
                                        String opt = "Type option2 here";
                                        string finaloption = @"<select class='form-control' id='uniqueid' name='same-uniqueid-as-label'>
				<option></option>" + optionmatch2 + @"</select>";
                                        matchstr = matchstr.Replace(opt, finaloption);
                                    }
                                    else
                                    {
                                        String opt = "Type option here";
                                        matchstr = matchstr.Replace(opt, "");
                                        string amatch = lines.Substring(lines.IndexOf("#A#"));

                                    }
                                }

                            }
                            File.AppendAllText(dirpath + "\\" + foutputfile, matchstr);
                        }
                        //for loop ends here
                        // Option is written here
                        if ((mat2) || (mat3))
                        {
                            // write statement for match 2 version 2 option
                            for (int k = 0; k < ileft; k++)
                            {
                                if (leftcol[k] != null && leftcol[k] != "" && leftcol[k] != " ")
                                {
                                    matchvans = matchans;
                                    string questionnumber = "question number";
                                    matchvans = matchvans.Replace(questionnumber, (k + 1).ToString());
                                    string mat = newmatchcolumnstag;
                                    string mat1 = mat.Substring(10);

                                    string[] matsplit = mat1.Split(new[] { ":" }, StringSplitOptions.None);
                                    string[] removehash = matsplit[1].Split(new[] { "#" }, StringSplitOptions.None);

                                    String opt = "Type option here";
                                    string finaloption = "";
                                    int options = Convert.ToInt16(removehash[0]);
                                    for (int x = 0; x < options; x++)
                                    {
                                        if ((options > 1) && (x != (options - 1)))
                                        {
                                            finaloption += @"<select class='form-control match_v1' id='uniqueid' name='same-uniqueid-as-label'>
				        <option></option>" + optionmatch + @"</select><label class='col-form-label question'>,</label>";

                                        }
                                        else if ((options == 1) || (x == (options - 1)))
                                        {
                                            finaloption += @"<select class='form-control match_v1' id='uniqueid' name='same-uniqueid-as-label'>
				        <option></option>" + optionmatch + @"</select>";
                                            if (mat3)
                                            {
                                                finaloption += "<label class='col-form-label question'>-</label>";
                                                finaloption += @"<select class='form-control match_v1' id='uniqueid' name='same-uniqueid-as-label'>
				<option></option>" + optionmatch2 + @"</select>";
                                            }
                                        }
                                    }

                                    matchvans = matchvans.Replace(opt, finaloption);
                                    File.AppendAllText(dirpath + "\\" + foutputfile, matchvans);
                                }




                            }
                            matchvans = matchans;
                        }

                        mat2 = false;
                        mat3 = false;
                        newmatchcolumnstag = "";
                        ileft = 0;
                        iright = 0;
                        col = 0;
                        threecol = 0;



                        //  write final answer here
                        string anmatch = lines.Substring(lines.IndexOf("#A#"));
                        string anmatchas = anmatch.Substring(4);
                        if (anmatchas.Contains("*"))
                        {
                            string ansstar = "<span style='visibility:hidden' class='splitstar'>*</span>";
                            anmatchas = anmatchas.Replace("*", ansstar);
                        }
                        if (anmatchas.Contains("&"))
                        {
                            anmatchas = anmatchas.Replace("&", "<span style='color: black;' class='splitor'>OR</span>");
                        }
                        string taganmatch = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagmatchanswer.txt";
                        string outfilematchr = File.ReadAllText(taganmatch);
                        string serans = "Type answer here";
                        outfilematchr = outfilematchr.Replace(serans, anmatchas);
                        File.AppendAllText(dirpath + "\\" + foutputfile, outfilematchr);
                        matchcheck = false;

                    }

                    else
                    {



                        if (!mat2 && !mat3 && !headercheck && !lines.Contains("#Columns2#") && !lines.Contains("#Columns3#"))
                        {
                            if ((ileft == 0) || (leftmatch == true))
                            {
                                if (lines.ToString().Trim() == "")
                                { 
                                }
                                else
                                leftcol[ileft++] = lines.ToString();
                                // ileft++;
                                leftmatch = false;
                                rightmatch = true;
                            }
                            else if (rightmatch)
                            {
                               
                                    rightcol[iright++] = lines.ToString();
                                
                                // iright++;
                                rightmatch = false;
                                if (col == 2)
                                {
                                    leftmatch = true;
                                }

                                if (col == 3)
                                {
                                    thirdcolmatch = true;
                                }
                            }
                            else if (thirdcolmatch)
                            {
                                thirdcolmatch = false;
                                leftmatch = true;
                                thirdcol[threecol++] = lines.ToString();
                            }
                        }
                    }

                    if ((matchcheck) && ((mat2) || (mat3)) && !headercheck && !lines.Contains("#Columns2-") && !lines.Contains("#Columns3-"))
                    {
                        bool columnmatch = !(lines.Contains("#Columns2-"));
                        bool match2 = ((matchcheck) && (mat2) && !(lines.Contains("#Columns2-")));
                        if ((ileft == 0) || (leftmatch == true))
                        {
                            leftcol[ileft++] = lines.ToString();
                            // ileft++;
                            leftmatch = false;
                            rightmatch = true;
                        }
                        else if (rightmatch)
                        {
                            
                           rightcol[iright++] = lines.ToString();
                           // iright++;
                            rightmatch = false;
                            if (mat2)
                            {
                                leftmatch = true;
                            }

                            if (mat3)
                            {
                                thirdcolmatch = true;
                            }
                        }
                        else if (thirdcolmatch)
                        {
                            thirdcolmatch = false;
                           
                            leftmatch = true;
                            thirdcol[threecol++] = lines.ToString();
                        }

                    }

                }

                
                }//  end of for each loop// end of splittiong of line by line of doc file
                string submit2 = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\tagsubmit.txt";
                string submitfinal = File.ReadAllText(submit2);
   //             File.AppendAllText(dirpath + "\\" + foutputfile, "</div>");
                File.AppendAllText(dirpath + "\\" + foutputfile, submitfinal);

    //            File.AppendAllText(dirpath + "\\" + foutputfile, "</form>");
                IniFile loadtext = new IniFile();
                //loadtext.uploadtextfile(dirpath + "\\" + foutputfile);
                string resulttxt;
                IniFile loadtextfile = new IniFile();
                resulttxt = loadtextfile.uploadtextfile(dirpath + "\\" + foutputfile, classnum,subject);

                if (resulttxt == "success")
                {
                    loadfile = Path.GetFileNameWithoutExtension(foutputfile);
                    loadfile = loadfile + ".php";
                    //string weblink;
                    string site = ini.readlink("LinkInfo", "Link");
                    string weblink = site + "/forms/" + classnum.ToLower() + "/" + subject.ToLower() + "/";
                    MessageBox.Show("Uploaded Successfully : Please Go To link " + weblink +loadfile);
                    //MessageBox.Show("Uploaded Successfully : Please Go To link :https://halantbooks.com/bbpd/upload/forms/" + loadfile);
                   // linkLabel1.Text += "https://halantbooks.com/bbpd/upload/forms/" + loadfile + Environment.NewLine;
                    //linkLabel1.Text = weblink + loadfile + Environment.NewLine;
                    linkLabel1.Text += weblink + loadfile + Environment.NewLine;
                    MessageBox.Show("All Files Are Uploaded");

                }
                else
                    MessageBox.Show("Uploading Failed");
                
                
              
               // var doc_close = (Microsoft.Office.Interop.Word._Document)doc;
                //doc_close.Close();
               // Marshal.FinalReleaseComObject(doc);
            }
            }
             else if (resultmsg == DialogResult.Cancel)
             {

             }

    }
        


        private void button3_Click(object sender, EventArgs e)
        {
            
            
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            /*string fpath;

            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
                txtfile.Text = dialog.FileName;
            fpath = txtfile.Text;
            File.SetAttributes(fpath, FileAttributes.Normal);
            // Microsoft.Office.Interop.Word.Application oWordApp = new Microsoft.Office.Interop.Word.Application();

            word.Word.Application app = new word.Word.Application();
            // app.DisplayAlerts = false;
            word.Word.Document doc;
            object missing = Type.Missing;
            object readOnly = false;


            doc = app.Documents.Open(fpath, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);

            doc.Activate();

            try
            {
                //if (Path.GetExtension(fpath) == ".doc")
                //{
                //    doc.SaveAs(Path.GetDirectoryName(fpath) + "/" + Path.GetFileNameWithoutExtension(fpath) + ".docx", word.Word.WdSaveFormat.wdFormatXMLDocument);
                //    doc.Close();
                //    fpath = Path.GetDirectoryName(fpath) + "/" + Path.GetFileNameWithoutExtension(fpath) + ".docx";
                //    doc = app.Documents.Open(fpath, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
                //}
                //doc.Activate();
                // saving as html
                if (Path.GetExtension(fpath) == ".doc") { 
                }
                else
                {
                    var htmlfilepath = Path.GetDirectoryName(fpath) + "/" + Path.GetFileNameWithoutExtension(fpath) + ".html";
                    doc.SaveAs(htmlfilepath, word.Word.WdSaveFormat.wdFormatHTML);

                    //Necessary to close file
                    doc.Close();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    doc = new word.Word.Document();
                    app = null;
                    app = new word.Word.Application();
                    doc = app.Documents.Open(fpath, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);

                    doc.Activate();
                    string textcontent = doc.Content.Text;
                    string classnum = "";
                    string subject = "";
                    //replace here tcopied text
                    string[] Doclines = textcontent.Split(new[] { "\r\n" }, StringSplitOptions.None);
                    foreach (string lines in Doclines)
                    {
                        if (lines.Contains("#Class#"))
                        {
                            int cl = lines.IndexOf("#Class#");
                            string cls = lines.Substring(lines.IndexOf("#Class#"));
                            classnum = cls.Substring(7);
                            classnum = classnum.Trim();
                        }

                        if (lines.Contains("#Subject#"))
                        {
                            int posline = lines.IndexOf("t#");
                            subject = lines.Substring(posline + 2);
                            subject = subject.Trim();
                        }
                    }
                    // Get all the equations in array format
                    var math = doc.OMaths;
                    var count = math.Count;
                    // Text of all equations
                    List<string> alltext = new List<string>();
                    
                    // Take all the images 
                    var images_path = Path.GetDirectoryName(fpath) + "\\" + Path.GetFileNameWithoutExtension(fpath) + "_files";
                    //var images = Directory.GetFiles(images_path, "*.png", SearchOption.AllDirectories);
                    var listimages = Directory.EnumerateFiles(images_path, "*.*", SearchOption.AllDirectories)
                .Where(s => s.EndsWith(".gif") || s.EndsWith(".jpg") || s.EndsWith(".jpeg") || s.EndsWith(".png")).ToArray();

                    List<string> images = new List<string>();

                    for (int l = 0; l < listimages.Length; l++)
                    {
                        int resultString = Convert.ToInt32(Regex.Match(Path.GetFileNameWithoutExtension(listimages[l]), @"\d+").Value);
                        if (resultString % 2 == 1)
                        {
                            images.Add(listimages[l]);
                        }
                        else
                        {

                        }
                    }
                    var imagelist = images.ToList();
                    int j = 0;

                    // replace repeated images with reference
                    for (int i = 0; i < count; i++)
                    {
                        if (alltext.Contains(math[i + 1].Range.Text))
                        {
                            //int position = Array.IndexOf(alltext, math[i + 1].Range.Text);
                            int position = alltext.IndexOf(math[i + 1].Range.Text);
                            imagelist.Insert(i, images[position]);
                            images = imagelist;
                        }
                        //alltext[i] = math[i + 1].Range.Text;
                          alltext.Insert(i, math[i + 1].Range.Text);
                    }

                    // before equation put image tag
                    for (int i = 1; i <= count; i++)
                    {
                        //if (alltext.Contains(math[i].Range.Text))
                        //{
                        //    var sdjh = alltext.Contains(math[i].Range.Text);
                        //}
                        math[i].Range.Select();
                        //math[i].Range.Bold = 1;
                        math[i].Range.InsertBefore("<img src='../../../images/"+ classnum + "/" + subject + "/" + Path.GetFileName(imagelist[i - 1].ToString()) + "'> ");
                        //math[i].Range.InlineShapes.AddPicture(imagelist[i - 1].ToString());
                    }

                    // equation deleted by deleting first element
                    for (int i = count; i >= 1; i--)
                    {
                        math[1].Range.Delete();
                    }

                    // imges zip is created
                    string datetime = DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss");
                    string newfilename = Path.GetDirectoryName(fpath) + "\\" + Path.GetFileNameWithoutExtension(fpath) + "_" + datetime + ".docx";
                    doc.SaveAs(newfilename);

                    string directoryname = Path.GetDirectoryName(fpath) + "\\" + Path.GetFileNameWithoutExtension(fpath) + "_" + datetime;
                    if (!Directory.Exists(directoryname))
                    {
                        Directory.CreateDirectory(directoryname);
                    }
                    for (int i = 0; i < images.Count(); i++)
                    {
                        string sourcefile = images[i].ToString();
                        string destinationfile = directoryname + "\\" + Path.GetFileName(sourcefile);
                        File.Copy(sourcefile, destinationfile, true);
                    }
                    string startPath = directoryname;
                    string zipPath = Path.GetDirectoryName(fpath) + "\\" + Path.GetFileName(fpath) + "_" + datetime + ".zip";
                    System.IO.Compression.ZipFile.CreateFromDirectory(startPath, zipPath);

                    DirectoryInfo di = new DirectoryInfo(directoryname);
                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }
                    foreach (DirectoryInfo dir in di.GetDirectories())
                    {
                        dir.Delete(true);
                    }
                    Directory.Delete(directoryname);

                    di = new DirectoryInfo(images_path);
                    foreach (FileInfo file in di.GetFiles())
                    {
                        file.Delete();
                    }
                    foreach (DirectoryInfo dir in di.GetDirectories())
                    {
                        dir.Delete(true);
                    }
                    Directory.Delete(images_path);

                    File.Delete(htmlfilepath);
                }

                MessageBox.Show("Process Complete");

                doc.Close();
                app.Quit();
            }
            catch (Exception ex)
            {
                doc.Close();
                app.Quit();
                MessageBox.Show(ex.ToString());
            }*/


            //17-2-2021
            linkLabel1.Text = "";
            
            DialogResult resultmsg = MessageBox.Show("Please Close All Word Documents Before Click On Ok Button", "Confirm", MessageBoxButtons.OKCancel);
            
            if (resultmsg == DialogResult.OK)
            {
                Process[] word_apps = Process.GetProcessesByName("winword");
                foreach (var word_app in word_apps)
                {
                    word_app.Kill();
                }
            string fpath;

            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Word Files|*.doc;*.docx;";
            if (dialog.ShowDialog() == DialogResult.OK)
                txtfile.Text = dialog.FileName;
            if ((dialog.FileName == "") || (dialog.FileName == null))
            {
                MessageBox.Show("Please select valid file.");
            }
            else if (Path.GetExtension(dialog.FileName).ToLower() == ".doc") {
                MessageBox.Show("Please Select .docx file","Math Pre-process");
            }
            else
            {
                var sdhj = Path.GetExtension(dialog.FileName);
                fpath = txtfile.Text;
                File.SetAttributes(fpath, FileAttributes.Normal);
                // Microsoft.Office.Interop.Word.Application oWordApp = new Microsoft.Office.Interop.Word.Application();

                word.Word.Application app = new word.Word.Application();
                // app.DisplayAlerts = false;
                word.Word.Document doc;
                object missing = Type.Missing;
                object readOnly = false;


                doc = app.Documents.Open(fpath, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
                var mathtemp = doc.OMaths;
                if (mathtemp != null)
                {
                    if (mathtemp.Count > 0)
                    {
                        for (int l = 1; l <= mathtemp.Count; l++)
                        {
                            mathtemp[l].Range.Font.ColorIndex = word.Word.WdColorIndex.wdAuto;
                        }
                    }
                }
                // save the current document to new document
                var getfilename = "";
                var copymathfile = false;
                try
                {
                    doc.Select();
                    app.Selection.WholeStory();
                    app.Selection.Copy();
                    app.Documents.Add(DocumentType: 0);
                    app.Selection.Paste();
                    app.Selection.Move();
                    getfilename = fpath.Replace(Path.GetFileNameWithoutExtension(fpath), Path.GetFileNameWithoutExtension(fpath) + "erl");
                    //app.ActiveDocument.SaveAs2(getfilename);
                    var savename = getfilename;
                    string version = app.Version;
                    switch (version)
                    {
                        case "7.0":
                        case "8.0":
                        case "9.0":
                        case "10.0":
                            app.ActiveDocument.SaveAs2000(savename, FileFormat: word.Word.WdSaveFormat.wdFormatXMLDocument, LockComments: false, Password: "", AddToRecentFiles: true, WritePassword: "", ReadOnlyRecommended: false, EmbedTrueTypeFonts: false, SaveNativePictureFormat: false, SaveFormsData: false, SaveAsAOCELetter: false);
                            break;
                        case "11.0":
                        case "12.0":
                            app.ActiveDocument.SaveAs(savename, FileFormat: word.Word.WdSaveFormat.wdFormatXMLDocument, LockComments: false, Password: "", AddToRecentFiles: true, WritePassword: "", ReadOnlyRecommended: false, EmbedTrueTypeFonts: false, SaveNativePictureFormat: false, SaveFormsData: false, SaveAsAOCELetter: false);
                            break;
                        case "14.0":
                        case "15.0":
                            app.ActiveDocument.SaveAs2(savename, FileFormat: word.Word.WdSaveFormat.wdFormatXMLDocument, LockComments: false, Password: "", AddToRecentFiles: true, WritePassword: "", ReadOnlyRecommended: false, EmbedTrueTypeFonts: false, SaveNativePictureFormat: false, SaveFormsData: false, SaveAsAOCELetter: false, CompatibilityMode: 15);
                            break;
                        default:
                            app.ActiveDocument.SaveAs2(savename, FileFormat: word.Word.WdSaveFormat.wdFormatXMLDocument, LockComments: false, Password: "", AddToRecentFiles: true, WritePassword: "", ReadOnlyRecommended: false, EmbedTrueTypeFonts: false, SaveNativePictureFormat: false, SaveFormsData: false, SaveAsAOCELetter: false, CompatibilityMode: 15);
                            break;
                    }
                    app.ActiveDocument.Close();
                    doc.Close();
                    app.Quit();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    app = new word.Word.Application();
                    fpath = getfilename;
                    doc = app.Documents.Open(fpath, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
                    copymathfile = true;
                }
                catch (Exception)
                {
                    try
                    {
                        app.ActiveDocument.Close();
                        doc.Close();
                        app.Quit();
                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                    }
                    catch (Exception)
                    {
                        
                    }
                    copymathfile = false;
                }
                
                doc.Activate();
                string textcontent = doc.Content.Text;
                textcontent = textcontent.Replace("\r", Environment.NewLine);
                textcontent = textcontent.Replace("\r\n", Environment.NewLine);
                string classnum = "";
                string subject = "";
                string chaptname = "";
                string assignnum = "";
                string chapnum = "";
                //replace here tcopied text
                string[] Doclines = textcontent.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
                foreach (string lines in Doclines)
                {
                    if (lines.Contains("#Class#"))
                    {
                        int cl = lines.IndexOf("#Class#");
                        string cls = lines.Substring(lines.IndexOf("#Class#"));
                        classnum = cls.Substring(7);
                        classnum = classnum.Trim();
                        classnum = classnum.ToLower();
                    }

                    if (lines.Contains("#Subject#"))
                    {
                        int posline = lines.IndexOf("t#");
                        subject = lines.Substring(posline + 2);
                        subject = subject.Trim();
                        subject = subject.ToLower();
                    }
                    if (lines.Contains("#ChapterName#"))
                    {
                        int poschptno = lines.IndexOf("r#");
                        string chaptno = lines.Substring(poschptno + 3);
                        int posname = lines.IndexOf("e#");
                        chaptname = lines.Substring(posname + 2);
                        chaptname = chaptname.Trim();
                        chaptname = chaptname.ToLower();
                    }
                    if (lines.Contains("#AssignmentNo#"))
                    {
                        string assn = "#AssignmentNo#";
                        int assnt = assn.Length;
                        int asn = lines.IndexOf("#AssignmentNo#");
                        string assignt = lines.Substring(lines.IndexOf("#AssignmentNo#"));
                        assignnum = assignt.Substring(assnt);
                        assignnum = assignnum.Trim();
                        assignnum = assignnum.ToLower();

                    }
                    if (lines.Contains("#ChapterNumber#"))
                    {
                        int cl = lines.IndexOf("#ChapterNumber#");
                        string cls = lines.Substring(lines.IndexOf("#ChapterNumber#"));
                        chapnum = cls.Substring(15);
                        chapnum = chapnum.Trim();
                        chapnum = chapnum.ToLower();
                    }
                }
                try
                {
                    //if (Path.GetExtension(fpath) == ".doc")
                    //{
                    //    doc.SaveAs(Path.GetDirectoryName(fpath) + "/" + Path.GetFileNameWithoutExtension(fpath) + ".docx", word.Word.WdSaveFormat.wdFormatXMLDocument);
                    //    doc.Close();
                    //    fpath = Path.GetDirectoryName(fpath) + "/" + Path.GetFileNameWithoutExtension(fpath) + ".docx";
                    //    doc = app.Documents.Open(fpath, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
                    //}
                    //doc.Activate();
                    // saving as html
                    if (Path.GetExtension(fpath) == ".doc")
                    {
                    }
                    else
                    {
                        var htmlfilepath = Path.GetDirectoryName(fpath) + "/" + Path.GetFileNameWithoutExtension(fpath) + ".html";
                        doc.SaveAs(htmlfilepath, word.Word.WdSaveFormat.wdFormatHTML);

                        //Necessary to close file
                        doc.Close();
                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                        doc = new word.Word.Document();
                        app = null;
                        app = new word.Word.Application();
                        doc = app.Documents.Open(fpath, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);
                        doc.AcceptAllRevisions();
                        doc.Activate();
                        doc.Revisions.AcceptAll();
                        // Get all the equations in array format
                        var math = doc.OMaths;
                        var count = math.Count;
                        // Text of all equations
                        List<string> alltext = new List<string>();

                        // Take all the images 
                        var images_path = Path.GetDirectoryName(fpath) + "\\" + Path.GetFileNameWithoutExtension(fpath) + "_files";

                        //rename the files
                        /* DirectoryInfo d = new DirectoryInfo(images_path);
                         FileInfo[] infos = d.GetFiles();
                         foreach (FileInfo f in infos)
                         {
                             File.Move(f.FullName, f.FullName.Replace(Path.GetFileNameWithoutExtension(f.Name), Path.GetFileNameWithoutExtension(f.Name) + classnum + subject + chapnum + assignnum));
                         }*/

                        //var images = Directory.GetFiles(images_path, "*.png", SearchOption.AllDirectories);
                        var listimages = Directory.EnumerateFiles(images_path, "*.*", SearchOption.AllDirectories)
                    .Where(s => s.EndsWith(".gif") || s.EndsWith(".jpg") || s.EndsWith(".jpeg") || s.EndsWith(".png")).ToArray();

                        List<string> images = new List<string>();

                        for (int l = 0; l < listimages.Length; l++)
                        {
                            int resultString = Convert.ToInt32(Regex.Match(Path.GetFileNameWithoutExtension(listimages[l]), @"\d+").Value);
                            if (resultString % 2 == 1)
                            {
                                images.Add(listimages[l]);
                            }
                            else
                            {

                            }
                        }
                        var imagelist = images.ToList();
                        int j = 0;

                        // replace repeated images with reference
                        for (int i = 0; i < count; i++)
                        {
                            if (alltext.Contains(math[i + 1].Range.Text))
                            {
                                //int position = Array.IndexOf(alltext, math[i + 1].Range.Text);
                                int position = alltext.IndexOf(math[i + 1].Range.Text);
                                imagelist.Insert(i, images[position]);
                                images = imagelist;
                            }
                            //alltext[i] = math[i + 1].Range.Text;
                            alltext.Insert(i, math[i + 1].Range.Text);
                        }

                        // before equation put image tag
                        for (int i = 1; i <= count; i++)
                        {
                            //if (alltext.Contains(math[i].Range.Text))
                            //{
                            //    var sdjh = alltext.Contains(math[i].Range.Text);
                            //}
                            math[i].Range.Select();
                            var temp_prev = math[i].Range.Previous().Text;
                            if (temp_prev == "\r\a")
                            {
                                math[i].ParentOMath.Range.InsertParagraph();
                            }
                            //math[i].Range.Bold = 1;
                            math[i].Range.InsertBefore("<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + Path.GetFileName(imagelist[i - 1].ToString()).Replace(Path.GetFileNameWithoutExtension(imagelist[i - 1].ToString()), Path.GetFileNameWithoutExtension(imagelist[i - 1].ToString()) + classnum + subject + chapnum + assignnum) + "'> ");
                            //math[i].Range.InlineShapes.AddPicture(imagelist[i - 1].ToString());
                        }

                        // equation deleted by deleting first element
                        for (int i = count; i >= 1; i--)
                        {
                            math[1].Range.Delete();
                        }

                        // imges zip is created
                        string datetime = DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss");
                        string newfilename = Path.GetDirectoryName(fpath) + "\\" + Path.GetFileNameWithoutExtension(fpath) + "_" + datetime + ".docx";
                        doc.SaveAs(newfilename);

                        string directoryname = Path.GetDirectoryName(fpath) + "\\" + Path.GetFileNameWithoutExtension(fpath) + "_" + datetime;
                        if (!Directory.Exists(directoryname))
                        {
                            Directory.CreateDirectory(directoryname);
                        }
                        for (int i = 0; i < images.Count(); i++)
                        {
                            string sourcefile = images[i].ToString();
                            string destinationfile = directoryname + "\\" + Path.GetFileName(sourcefile);
                            File.Copy(sourcefile, destinationfile, true);
                        }
                        DirectoryInfo d = new DirectoryInfo(directoryname);
                        FileInfo[] infos = d.GetFiles();
                        foreach (FileInfo f in infos)
                        {
                            File.Move(f.FullName, f.FullName.Replace(Path.GetFileNameWithoutExtension(f.Name), Path.GetFileNameWithoutExtension(f.Name) + classnum + subject + chapnum + assignnum));
                        }
                        string startPath = directoryname;
                        string zipPath = Path.GetDirectoryName(fpath) + "\\" + Path.GetFileName(fpath) + "_" + datetime + ".zip";
                        System.IO.Compression.ZipFile.CreateFromDirectory(startPath, zipPath);

                        DirectoryInfo di = new DirectoryInfo(directoryname);
                        foreach (FileInfo file in di.GetFiles())
                        {
                            file.Delete();
                        }
                        foreach (DirectoryInfo dir in di.GetDirectories())
                        {
                            dir.Delete(true);
                        }
                        Directory.Delete(directoryname);

                        di = new DirectoryInfo(images_path);
                        foreach (FileInfo file in di.GetFiles())
                        {
                            file.Delete();
                        }
                        foreach (DirectoryInfo dir in di.GetDirectories())
                        {
                            dir.Delete(true);
                        }
                        Directory.Delete(images_path);

                        File.Delete(htmlfilepath);
                    }

                    MessageBox.Show("Process Complete","Math Pre-process");

                    doc.Close(word.Word.WdSaveOptions.wdDoNotSaveChanges);
                    app.Quit();
                    if (copymathfile)
                    {
                        copymathfile = false;
                        File.Delete(getfilename);
                    }
                }
                catch (Exception ex)
                {
                    doc.Close(word.Word.WdSaveOptions.wdDoNotSaveChanges);
                    app.Quit();
                    MessageBox.Show(ex.ToString(),"Math Pre-process");
                }

            }
            }
            else if (resultmsg == DialogResult.Cancel)
            {

            }
        }

        ////private void timer1_Tick(object sender, EventArgs e)
        ////{
        ////    progressBar1.Increment(100);
        ////}

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //linkLabel1.Text = "Click Here";
            //Process.Start("https://halantbooks.com/bbpd/upload/");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string zippath;

            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Zip Files|*.zip";
            if (dialog.ShowDialog() == DialogResult.OK)
                txtzip.Text = dialog.FileName;
                zippath = txtzip.Text;
                           
            IniFile loadzipfile = new IniFile();
            string result = loadzipfile.uploadzipfile(zippath,"","");
            if (result == "success")
                MessageBox.Show("Images Are Uploaded");
            else
                MessageBox.Show("Images Uploading Failed");
        }

        private void TestPaper_Load(object sender, EventArgs e)
        {
            label1.Text = "Please Visit Below Links For Assignments" + Environment.NewLine;
            string uploadzip = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\uploadzip.ini";
            IniFile ini = new IniFile(uploadzip);
            string upzipcmb1 = ini.uploadzipini("ClassInfo", "class");
            string[] zipitemcmb1 = upzipcmb1.Split(',');
            for (int i = 0; i < zipitemcmb1.Length; i++)
            {
                comboBox1.Items.Add(zipitemcmb1[i]);
            }

            string upzipcmb2 = ini.uploadzipini("SubjectInfo", "subject");
            string[] zipitemcmb2 = upzipcmb2.Split(',');
            for (int z = 0; z < zipitemcmb2.Length; z++)
            {
                comboBox2.Items.Add(zipitemcmb2[z]);
            }
        
        
        }

        private void linkLabel1_Click(object sender, EventArgs e)
        {
           

        }
        private void linkLabel1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Clipboard.SetText(linkLabel1.Text);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        

        public bool AsisParent(word.Word.Range textRange, int parentCounter)
        {
            try
            {
                var parent = textRange.Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 1).Text;
                // 2 = asis
                // 1 = some other tag
                // 3 = don't know - do recursive
                if ((parent == null) || parent.ToLower().Contains("#asisend#".ToLower()))
                {
                    return false;
                }
                else
                {
                    if (!parent.ToLower().Contains("#Instruction#".ToLower()))
                    {
                        if (!parent.ToLower().Contains("#Columns".ToLower()))
                        {
                            if (!parent.ToLower().Contains("#Type".ToLower()))
                            {
                                if (parent.ToLower().Contains("#Asis#".ToLower()))
                                {
                                    // send for conversion
                                    return true;
                                }
                                else if (parent.ToLower().Contains("\r".ToLower()) || parent.ToLower().Contains("\r\n".ToLower()) || parent.ToLower().Contains("\n\r".ToLower()) || parent.ToLower().Contains("\t".ToLower()) || parent.ToLower().Contains("\n".ToLower()) || parent.ToLower().Contains("\v".ToLower()))
                                {
                                    if (parentCounter > 0 && parentCounter < 15)
                                    {
                                        return AsisParent(textRange.Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 1), parentCounter + 1);
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                }
                                else
                                {
                                    return false;
                                }
                            }
                            else
                            {
                                return false;
                            }
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public void asispreprocess(word.Word.Document doc, word.Word.Application app)
        {
            foreach (word.Word.Paragraph objparagraph in doc.Paragraphs)
            {
                var text = objparagraph.Range.Text;
                objparagraph.Range.Select();
                if (text.ToLower().Trim().StartsWith("#asis"))
                {
                    object findText = "#asis#";
                    object missing = Type.Missing;
                    app.Selection.Find.ClearFormatting();
                    app.Selection.Find.MatchCase = false;

                    //app.Selection.Find.Execute(ref findText, ref missing, ref missing, ref missing, ref missing,
                    //    ref missing, ref missing, ref missing, ref missing, ref missing,
                    //    ref missing, ref missing, ref missing, ref missing, ref missing);
                    //app.Selection.InsertParagraphAfter();
                    //if (text.ToLower().Contains("\r") || text.ToLower().Contains("\n") || text.ToLower().Contains("\r\n"))
                    //{
                    //}
                    //else
                    //{
                        app.Selection.Find.Execute(ref findText, ref missing, ref missing, ref missing, ref missing,
                       ref missing, ref missing, ref missing, ref missing, ref missing,
                       ref missing, ref missing, ref missing, ref missing, ref missing);
                        app.Selection.InsertParagraphAfter();
                    //}

                    findText = "#asisend#";
                    app.Selection.Find.Execute(ref findText, ref missing, ref missing, ref missing, ref missing,
                        ref missing, ref missing, ref missing, ref missing, ref missing,
                        ref missing, ref missing, ref missing, ref missing, ref missing);
                    app.Selection.InsertParagraphBefore();

                }
                else if (text.ToLower().Contains("#asis#"))
                {
                    object findText = "#asis#";
                    object missing = Type.Missing;
                    object replaceAll = word.Word.WdReplace.wdReplaceAll;
                    app.Selection.Find.ClearFormatting();
                    app.Selection.Find.Replacement.Text = "";
                    app.Selection.Find.MatchCase = false;

                    app.Selection.Find.Execute(ref findText, ref missing, ref missing, ref missing, ref missing,
                        ref missing, ref missing, ref missing, ref missing, ref missing,
                        ref replaceAll, ref missing, ref missing, ref missing, ref missing);

                    findText = "#asisend#";
                    app.Selection.Find.Execute(ref findText, ref missing, ref missing, ref missing, ref missing,
                        ref missing, ref missing, ref missing, ref missing, ref missing,
                        ref replaceAll, ref missing, ref missing, ref missing, ref missing);

                }

            }
                       
            //doc.Content.Text = doc.Content.Text.Replace("#asisend#\r\n\r\n\r\n\r\n", "#asisend#\r\n");
            //doc.Content.Text = doc.Content.Text.Replace("#asisend#\r\n\r\n\r\n", "#asisend#\r\n");
        }

        public string asisconverter(string inputtext)
        {
            string rawcontent = inputtext;
          //  rawcontent = rawcontent.Replace("\v",Environment.NewLine);
           // rawcontent = rawcontent.Replace("\a", Environment.NewLine);
            var oldName = "#Asis#";
            var newName = "#Asis#"+ Environment.NewLine + "<div class='form-group row asisdiv'><label class='col-md-12 asislabel col-form-label'>";
            var oldSentence = rawcontent;
            var regex = new Regex(oldName, RegexOptions.IgnoreCase);
            var newSentence = regex.Replace(oldSentence, newName);
            oldName = "#AsisEnd#";
            newName = "</label></div>" + Environment.NewLine + "#AsisEnd#";
            regex = new Regex(oldName, RegexOptions.IgnoreCase);
            newSentence = regex.Replace(newSentence, newName);
            bool foundasis = false;
            newSentence = newSentence.Replace("\r", Environment.NewLine);
            int asisendcounter = 0;
            string classnum = "";
            string subject = "";
            string[] lines = newSentence.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
            for (int linecounter = 0; linecounter < lines.Length; linecounter++)
            {
                if (lines[linecounter].Contains("#Class#"))
                {
                    int cl = lines[linecounter].IndexOf("#Class#");
                    string cls = lines[linecounter].Substring(lines[linecounter].IndexOf("#Class#"));
                    classnum = cls.Substring(7);
                    classnum = classnum.Trim();
                }

                if (lines[linecounter].Contains("#Subject#"))
                {
                    int posline = lines[linecounter].IndexOf("t#");
                    subject = lines[linecounter].Substring(posline + 2);
                    subject = subject.Trim();
                }

                if (lines[linecounter].ToLower().IndexOf(@"#asisend#") > -1)
                {
                    foundasis = false;
                }
                else if (lines[linecounter].ToLower().IndexOf(@"#asis#") > -1)
                //else if (lines[linecounter].Contains("#Asis#"))
                {
                    foundasis = true;
                    lines[linecounter] = lines[linecounter] + "<p class='asisparaenter' style='margin:0'></p>";
                }
                else
                {
                    if (foundasis)
                    {
                        lines[linecounter] = lines[linecounter].Replace("\v", "<br/>");
                        lines[linecounter] = lines[linecounter].Replace("\a", "<br/>");
                        if (asisendcounter++ > 1000)
                        {
                            MessageBox.Show("Please verify the #AsisEnd# tag. Because it took a while to locate it.");
                            foundasis = false;
                            break;
                        }
                        else
                        {
                            if ((lines[linecounter].ToLower().IndexOf(@"<td>") > -1) || (lines[linecounter].ToLower().IndexOf(@"</td>") > -1))
                            {

                            }
                            else
                            {
                                if (linecounter - 1 >= 0) {
                                    var temp_clear = lines[linecounter].Replace("\r","");
                                    temp_clear = lines[linecounter].Replace("\n", "");
                                    temp_clear = lines[linecounter].Replace("\a", "");
                                    temp_clear = lines[linecounter].Replace("\v", "");
                                    temp_clear = lines[linecounter].Replace("\t", "");
                                    temp_clear = temp_clear.Trim();
                                    if ((lines[linecounter - 1] == "</br>") || (temp_clear == "")) { }
                                    else if (temp_clear.Contains("asislabel"))
                                    {
                                        lines[linecounter] = lines[linecounter] + "<p class='asisparaenter' style='margin:0'></p>";
                                    }
                                    else
                                    {
                                        lines[linecounter] = lines[linecounter] + "</br>";
                                    }
                                }
                                //lines[linecounter] = lines[linecounter] + "</br>";
                            }
                        }

                        if (lines[linecounter].ToLower().IndexOf(@"#pix#") > -1)
                        {
                            oldName = "#pix#";
                            IniFile loadimg = new IniFile();
                            string imagename = loadimg.getimagename(lines[linecounter]);
                            newName = @"<img src='../../../images/" + classnum.ToLower() + "/" + subject.ToLower() + "/" + imagename + @".jpg'>";
                            regex = new Regex(oldName, RegexOptions.IgnoreCase);
                            lines[linecounter] = regex.Replace(oldSentence, newName);
                        }
                    }
                    else
                    {
                        foundasis = false;
                    }
                }

            }
            newSentence = String.Join("\r", lines);
            return newSentence;
        }

        
        public bool typegridparent(word.Word.Range textRange, int parentCounter)
        {
            try
            {
                var parent = textRange.Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 1).Text;
                // 2 = asis
                // 1 = some other tag
                // 3 = don't know - do recursive
                if (parent == null)
                {
                    return false;
                }
                else
                {
                    if (parent.ToLower().Contains("#asisend".ToLower())) { 
                        asisendfoundintypegrid = true;
                    }
                    if (!parent.ToLower().Contains("#Columns".ToLower()))
                    {
                        if (!parent.ToLower().Contains("#Asis#".ToLower()))
                        {
                            if (parent.ToLower().Contains("#Type‐Grid#".ToLower()) || parent.ToLower().Contains("#Type-Grid#".ToLower()))
                            {
                                // send for conversion
                                return true;
                            }
                            else if (parent.ToLower().Contains("\r".ToLower()) || parent.ToLower().Contains("\r\n".ToLower()) || parent.ToLower().Contains("\n\r".ToLower()) || parent.ToLower().Contains("\t".ToLower()) || parent.ToLower().Contains("\n".ToLower()) || parent.ToLower().Contains("\v".ToLower()))
                            {
                                if (parentCounter > 0 && parentCounter < 70)
                                {
                                    return typegridparent(textRange.Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 1), parentCounter + 1);
                                }
                                else
                                {
                                    return false;
                                }
                            }
                            else
                            {
                                return false;
                            }
                        }
                        else
                        {
                            if (asisendfoundintypegrid) {
                                if (parentCounter > 0 && parentCounter < 70)
                                {
                                    return typegridparent(textRange.Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 1), parentCounter + 1);
                                }
                                else
                                {
                                    return false;
                                }
                            }
                            else
                            {
                                return false;
                            }
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public string[] superorsubscript(string xml_of_word)
        {
            XmlDocument string_to_xml = new XmlDocument();
            string[] return_value = new string[2] { "novalue", "novalue" };
            string_to_xml.LoadXml(xml_of_word);
            var string_to_xml_runs = string_to_xml.GetElementsByTagName("w:r");
            for (int string_to_xml_runsindex = 0; string_to_xml_runsindex < string_to_xml_runs.Count; string_to_xml_runsindex++)
            {
                var child_nodes = string_to_xml_runs[string_to_xml_runsindex].ChildNodes;
                // get text in run
                var text_in_string_to_xml_runs = string_to_xml_runs[string_to_xml_runsindex].InnerText;
                for (int childnodes_index = 0; childnodes_index < child_nodes.Count; childnodes_index++)
                {
                    var rpr_node = child_nodes[childnodes_index].LocalName;
                    if (rpr_node.ToString() == "rPr")
                    {
                        var rpr_node_child = child_nodes[childnodes_index].ChildNodes;
                        for (int rprindex = 0; rprindex < rpr_node_child.Count; rprindex++)
                        {
                            var get_verticalalign = rpr_node_child[rprindex].LocalName;
                            if (get_verticalalign.ToString() == "vertAlign")
                            {
                                // get attribute and check value 
                                // subscript
                                var verticalalign_attr = rpr_node_child[rprindex].Attributes;
                                for (int verticalalign_attr_index = 0; verticalalign_attr_index < verticalalign_attr.Count; verticalalign_attr_index++)
                                {
                                    var verticalslign_attr_name = verticalalign_attr[verticalalign_attr_index].LocalName;
                                    if (verticalslign_attr_name.ToString() == "val")
                                    {
                                        var getvalue = verticalalign_attr[verticalalign_attr_index].Value;
                                        if (getvalue.ToString() == "subscript")
                                        {
                                            // subscript found
                                            return_value[0] = "subscript";
                                            return_value[1] = text_in_string_to_xml_runs;
                                            return return_value;
                                        }
                                        else if (getvalue.ToString() == "superscript")
                                        {
                                            // superscript found
                                            return_value[0] = "superscript";
                                            return_value[1] = text_in_string_to_xml_runs;
                                            return return_value;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return return_value;
        }
        public string trimcellstring(string cellstring)
        {
            //[i 567 5 ] value
            List<string> splitarray = new List<string>();
            string temp = "";
            // trim end and start space
            cellstring = cellstring.Trim();

            // split by [ and trim
            if (cellstring.Contains('['))
            {
                splitarray = cellstring.Split('[').ToList();
                for (int splitarrayindex = 0; splitarrayindex < splitarray.Count; splitarrayindex++)
                {
                    splitarray[splitarrayindex] = splitarray[splitarrayindex].Trim();
                }
                cellstring = string.Join("[", splitarray);
            }



            splitarray = new List<string>();
            // split by ] and trim
            if (cellstring.Contains(']'))
            {
                splitarray = cellstring.Split(']').ToList();
                for (int splitarrayindex = 0; splitarrayindex < splitarray.Count; splitarrayindex++)
                {
                    splitarray[splitarrayindex] = splitarray[splitarrayindex].Trim();
                    // remove all the spaces inside []
                    List<string> removespaces = new List<string>();
                    if (splitarray[0].Contains(" ") && (splitarray[0] != ""))
                    {
                        removespaces = splitarray[0].Split(' ').ToList();
                        splitarray[0] = string.Join("", removespaces);
                    }
                }
                cellstring = string.Join("]", splitarray);
            }

            return cellstring;
             
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try 
	        {	        
		        string zippath;

                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "Zip Files|*.zip";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    if ((comboBox1.SelectedItem.ToString() == null) && (comboBox1.SelectedItem.ToString() == "") && (comboBox2.SelectedItem.ToString() == null) && (comboBox2.SelectedItem.ToString() == ""))
                    { 
                        MessageBox.Show("Please select Class and subject.","Upload Zip File");
                    }
                    else
	                {
                        if (dialog.FileName == null || dialog.FileName == "")
                        {
                        }
                        else {
                            txtzip.Text = dialog.FileName;
                            zippath = txtzip.Text;

                            IniFile loadzipfile = new IniFile();
                            string result = loadzipfile.uploadzipfile(zippath, comboBox1.SelectedItem.ToString(), comboBox2.SelectedItem.ToString());
                            if (result == "success")
                                MessageBox.Show("Images Are Uploaded");
                            else
                                MessageBox.Show("Images Uploading Failed");
                        }
	                }
                }
           
	        }
	        catch (Exception)
	        {
		        MessageBox.Show("There was some error uploadind the zip file.","Upload Zip File");
	        }

           
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string uploadzip = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\uploadzip.ini";
            IniFile ini = new IniFile(uploadzip);
            string upzipcmb1 = ini.uploadzipini("ClassInfo", "class");
            string[] zipitemcmb1 = upzipcmb1.Split(',');
            for (int i = 0; i < zipitemcmb1.Length; i++)
            {
                comboBox1.Items.Add(zipitemcmb1[i]);
            }

            string upzipcmb2 = ini.uploadzipini("SubjectInfo", "subject");
            string[] zipitemcmb2 = upzipcmb2.Split(',');
            for (int z = 0; z < zipitemcmb2.Length; z++)
            {
                comboBox2.Items.Add(zipitemcmb2[z]);
            }

        }

        private void RunMacro(object oApp, object[] oRunArgs)
        {
            oApp.GetType().InvokeMember("Run",
                System.Reflection.BindingFlags.Default |
                System.Reflection.BindingFlags.InvokeMethod,
                null, oApp, oRunArgs);
        }

// macro conversion
        public string GetRGB(long RGBvalue)
        {
            string StrTmp;
            if (RGBvalue < 0 | RGBvalue > 16777215)
                RGBvalue = 0;
            StrTmp = Convert.ToString(RGBvalue / Math.Pow(256, 0) % 256);
            StrTmp = "rgb(" + StrTmp + "," + RGBvalue / Math.Pow(256, 1) % 256;
            StrTmp = StrTmp + "," + RGBvalue / Math.Pow(256, 2) % 256;
            return StrTmp + ")";
        }

        //public string GetBasicRGB(long color, word.Word.Application app)
        //{
        //    int[] colorIndexLookup = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 2, 1, 4, 3 };
        //    int colorIndex;
        //    long finalColor;
        //    colorIndex = colorIndexLookup[Convert.ToUInt32(((color & 0xF000000) / (double)0x1000000) + colorIndexLookup.GetLowerBound(0))];
        //    finalColor = app.ActiveDocument.DocumentTheme.ThemeColorScheme.GetCustomColor(colorIndex.ToString());
        //    return "rgb(" + (finalColor & 0xFF) + "," + (finalColor / 0x100 & 0xFF) + "," + (finalColor & 0xFF0000) / 0x10000 + ")";

        //}
        public string GetBasicRGB(long color, word.Word.Application app)
        {
            int[] colorIndexLookup = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 2, 1, 4, 3 };
            long colorIndex;
            long finalColor = 0;
            MsoThemeColorSchemeIndex msotheme = MsoThemeColorSchemeIndex.msoThemeAccent1;
            colorIndex = colorIndexLookup[Convert.ToUInt32(((color & 0xF000000) / (double)0x1000000) + colorIndexLookup.GetLowerBound(0))];
            if (colorIndex == 1)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeDark1;
            }
            else if (colorIndex == 2)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeLight1;
            }
            else if (colorIndex == 3)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeDark2;
            }
            else if (colorIndex == 4)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeLight2;
            }
            else if (colorIndex == 5)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeAccent1;
            }
            else if (colorIndex == 6)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeAccent2;
            }
            else if (colorIndex == 7)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeAccent3;
            }
            else if (colorIndex == 8)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeAccent4;
            }
            else if (colorIndex == 9)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeAccent5;
            }
            else if (colorIndex == 10)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeAccent6;
            }
            else if (colorIndex == 11)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeHyperlink;
            }
            else if (colorIndex == 12)
            {
                msotheme = MsoThemeColorSchemeIndex.msoThemeFollowedHyperlink;
            }
            finalColor = app.ActiveDocument.DocumentTheme.ThemeColorScheme.Colors(msotheme).RGB;

            return "rgb(" + (finalColor & 0xFF) + "," + (finalColor / 0x100 & 0xFF) + "," + (finalColor & 0xFF0000) / 0x10000 + ")";

        }
        public string GetThemeColor(word.Word.WdThemeColorIndex ThemeColor, word.Word.Application app)
        {
            switch (ThemeColor)
            {
                case word.Word.WdThemeColorIndex.wdThemeColorAccent1:
                    {
                        return "Accent color 1";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorAccent2:
                    {
                        return "Accent color 2";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorAccent3:
                    {
                        return "Accent color 3";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorAccent4:
                    {
                        return "Accent color 4";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorAccent5:
                    {
                        return "Accent color 5";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorAccent6:
                    {
                        return "Accent color 6";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorBackground1:
                    {
                        return "Background color 1";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorBackground2:
                    {
                        return "Background color 2";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorHyperlink:
                    {
                        return "Hyperlink color";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorHyperlinkFollowed:
                    {
                        return "Followed hyperlink color";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorMainDark1:
                    {
                        return "Dark main color 1";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorMainDark2:
                    {
                        return "Dark main color 2";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorMainLight1:
                    {
                        return "Light main color 1";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorMainLight2:
                    {
                        return "Light main color 2";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorText1:
                    {
                        return "Text color 1";
                    }

                case word.Word.WdThemeColorIndex.wdThemeColorText2:
                    {
                        return "Text color 2";
                    }
                default:
                    return "No color";
            }
        }

        public void colorreplace(Microsoft.Office.Interop.Word.WdColor color, string htmltag, word.Word.Application app)
        {
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Font.Color = color;
            app.Selection.Find.Replacement.ClearFormatting();
            string rgbcolor;
            if (htmltag == "rgb(0,0,0)")
                rgbcolor = "^&";
            else
               rgbcolor = "<span style='color:" + htmltag + "'>^&</span>";
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "";
                withBlock.Replacement.Text = rgbcolor;
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchWildcards = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchAllWordForms = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
        }

        public void bbpdconverter(word.Word.Application app)
        {
            // 
            // bbpdconverter Macro
            // 
            // 
            string savename;
            savename = app.ActiveDocument.Path + "/converted" + app.ActiveDocument.Name;
            app.Selection.WholeStory();
            app.Selection.Copy();
            app.Selection.EndKey(Unit: word.Word.WdUnits.wdStory);
            object oMissing = System.Reflection.Missing.Value;
            app.Visible = false;
            app.Documents.Add(ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            app.Selection.PasteAndFormat(word.Word.WdRecoveryType.wdPasteDefault);
            app.Selection.EndOf();
            app.Selection.HomeKey(Unit: word.Word.WdUnits.wdStory);

            //math symbol
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = char.ConvertFromUtf32((int)61485);
                withBlock.Replacement.Text = "-";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindAsk;
                withBlock.Format = false;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchKashida = false;
                withBlock.MatchDiacritics = false;
                withBlock.MatchAlefHamza = false;
                withBlock.MatchControl = false;
                withBlock.MatchWildcards = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchAllWordForms = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = char.ConvertFromUtf32((int)61620);
                withBlock.Replacement.Text = "×";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindAsk;
                withBlock.Format = false;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchKashida = false;
                withBlock.MatchDiacritics = false;
                withBlock.MatchAlefHamza = false;
                withBlock.MatchControl = false;
                withBlock.MatchWildcards = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchAllWordForms = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = char.ConvertFromUtf32((int)61624);
                withBlock.Replacement.Text = "÷";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindAsk;
                withBlock.Format = false;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchKashida = false;
                withBlock.MatchDiacritics = false;
                withBlock.MatchAlefHamza = false;
                withBlock.MatchControl = false;
                withBlock.MatchWildcards = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchAllWordForms = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = char.ConvertFromUtf32((int)61625);
                withBlock.Replacement.Text = "≠";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindAsk;
                withBlock.Format = false;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchKashida = false;
                withBlock.MatchDiacritics = false;
                withBlock.MatchAlefHamza = false;
                withBlock.MatchControl = false;
                withBlock.MatchWildcards = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchAllWordForms = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
            app.Options.AutoFormatReplaceQuotes = false;
            app.Options.AutoFormatAsYouTypeReplaceQuotes = false;

            // #*#^13 is a wildcard to replace all the tags between # with no formatting
            // formatting removed : bold,italic,superscript, subscript,underline(single),color(wdAutomatic)
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "#*#*^13";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = true;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // #*#^13 is a wildcard to replace all the tags between # with no formatting
            // formatting removed : bold,italic,superscript, subscript,underline(single),color(wdAutomatic)
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "#*#";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = true;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);


            //// [i]
            //app.Selection.Find.ClearFormatting();
            //app.Selection.Find.Replacement.ClearFormatting();
            //{
            //    var withBlock = app.Selection.Find.Replacement.Font;
            //    withBlock.Bold = 0;
            //    withBlock.Italic = 0;
            //    withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
            //    withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
            //    withBlock.Superscript = 0;
            //    withBlock.Subscript = 0;
            //}
            //{
            //    var withBlock = app.Selection.Find;
            //    withBlock.Text = @"\[*\]* @";
            //    withBlock.Replacement.Text = "";
            //    withBlock.Forward = true;
            //    withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
            //    withBlock.Format = true;
            //    withBlock.MatchCase = false;
            //    withBlock.MatchWholeWord = false;
            //    withBlock.MatchAllWordForms = false;
            //    withBlock.MatchSoundsLike = false;
            //    withBlock.MatchWildcards = true;
            //}
            //app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            ////[i]
            //app.Selection.Find.ClearFormatting();
            //app.Selection.Find.Replacement.ClearFormatting();
            //{
            //    var withBlock = app.Selection.Find.Replacement.Font;
            //    withBlock.Bold = 0;
            //    withBlock.Italic = 0;
            //    withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
            //    withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
            //    withBlock.Superscript = 0;
            //    withBlock.Subscript = 0;
            //}
            //{
            //    var withBlock = app.Selection.Find;
            //    withBlock.Text = @"[*]* @";
            //    withBlock.Replacement.Text = "";
            //    withBlock.Forward = true;
            //    withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
            //    withBlock.Format = true;
            //    withBlock.MatchCase = false;
            //    withBlock.MatchWholeWord = false;
            //    withBlock.MatchAllWordForms = false;
            //    withBlock.MatchSoundsLike = false;
            //    withBlock.MatchWildcards = true;
            //}
            //app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
            // [i] with space before and after
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = @" @\[*\]* @";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = true;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // [i] with space before
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = @" @\[*\]";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = true;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // [i] with space after
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = @"\[*\]* @";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = true;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            //[i] without space
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = @"\[*\]";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = true;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
           
            // formatted space starting with tab to no formattting
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "^t @";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = true;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // remove formatting from para
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "^p";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // remove formatting from tab
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "^t";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // remove formatting from line enter
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "^n";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // remove formatting from ^l
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "^l";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // remove formatting from ^m
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "^m";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
            
            // remove formatting from ^b
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "^b";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // equation converted to html
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Bold = 0;
                withBlock.Italic = 0;
                withBlock.Underline = word.Word.WdUnderline.wdUnderlineNone;
                withBlock.ColorIndex = word.Word.WdColorIndex.wdAuto;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = @"\<img*\>";
                withBlock.Replacement.Text = "";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchAllWordForms = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchWildcards = true;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

           
            // bold to html
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Font.Bold = 1;
            app.Selection.Find.Replacement.ClearFormatting();
            app.Selection.Find.Replacement.Font.Bold = 0;
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "";
                withBlock.Replacement.Text = "<span style=\"font-weight:bold\">^&</span>";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchWildcards = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchAllWordForms = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Font.Italic = 1;
            app.Selection.Find.Replacement.ClearFormatting();
            app.Selection.Find.Replacement.Font.Italic = 0;
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "";
                withBlock.Replacement.Text = "<span style=\"font-style: italic\">^&</span>";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchWildcards = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchAllWordForms = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // italics to html
            app.Selection.Find.ClearFormatting();
            app.Selection.Find.Font.Underline = word.Word.WdUnderline.wdUnderlineSingle;
            app.Selection.Find.Replacement.ClearFormatting();
            app.Selection.Find.Replacement.Font.Underline = word.Word.WdUnderline.wdUnderlineNone;
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "";
                withBlock.Replacement.Text = "<span style=\"text-decoration: underline\">^&</span>";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchWildcards = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchAllWordForms = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // superscript to html
            app.Selection.Find.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Font;
                withBlock.Superscript = 1;
                withBlock.Subscript = 0;
            }
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "";
                withBlock.Replacement.Text = "<sup>^&</sup>";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchWildcards = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchAllWordForms = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);

            // subscript to html
            app.Selection.Find.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Font;
                withBlock.Superscript = 0;
                withBlock.Subscript = 1;
            }
            app.Selection.Find.Replacement.ClearFormatting();
            {
                var withBlock = app.Selection.Find.Replacement.Font;
                withBlock.Superscript = 0;
                withBlock.Subscript = 0;
            }
            {
                var withBlock = app.Selection.Find;
                withBlock.Text = "";
                withBlock.Replacement.Text = "<sub>^&</sub>";
                withBlock.Forward = true;
                withBlock.Wrap = word.Word.WdFindWrap.wdFindContinue;
                withBlock.Format = true;
                withBlock.MatchCase = false;
                withBlock.MatchWholeWord = false;
                withBlock.MatchWildcards = false;
                withBlock.MatchSoundsLike = false;
                withBlock.MatchAllWordForms = false;
            }
            app.Selection.Find.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
           
            // color
            app.ScreenUpdating = false;
            string StrClrArr = "";
            string StrClr;
            string htmltag = "";
            string replacementstring;
            long lngColor;
            {
                var withBlock = app.Selection.Range;
                withBlock.Font.Hidden = 0;
                {
                    var withBlock1 = withBlock.Find;
                    withBlock1.ClearFormatting();
                    withBlock1.Replacement.ClearFormatting();
                    withBlock1.MatchWildcards = true;
                    withBlock1.Text = "*";
                    withBlock1.Forward = true;
                    withBlock1.MatchWholeWord = true;
                    withBlock1.Format = true;
                    withBlock1.Font.Hidden = 0;
                    withBlock1.Wrap = word.Word.WdFindWrap.wdFindStop;
                    withBlock1.Execute();
                }

                
                   /*while (withBlock.Find.Found)
                    {
                        try
                        {
                            int cl = (int)withBlock.Font.Color;
                            var colorextract = System.Drawing.ColorTranslator.FromOle(cl);
                            var cl1 = GetRGB((long)withBlock.Font.Color);
                            var cl2 = GetBasicRGB((long)withBlock.Font.Color, app);

                            if ((cl1 == "rgb(0,0,0)") && (cl2 == "rgb(0,0,0)"))
                            {
                                htmltag = "rgb(0,0,0)";
                            }
                            else if ((cl2 != "rgb(0,0,0)"))
                            {
                                if (colorextract.Name == "Black")
                                {
                                    htmltag = "rgb(0,0,0)";
                                }
                                else
                                {
                                    htmltag = cl2;
                                }
                            }
                            else
                            {
                                if (colorextract.Name != "Black")
                                {
                                    htmltag = "rgb(" + colorextract.R + "," + colorextract.G + "," + colorextract.B + ");";
                                }
                            }


                            colorreplace(withBlock.Font.Color, htmltag, app);
                            {
                                var withBlock1 = withBlock.Duplicate.Find;
                                withBlock1.ClearFormatting();
                                withBlock1.Replacement.ClearFormatting();
                                withBlock1.Font.Color = withBlock.Font.Color;
                                withBlock1.Replacement.Font.Hidden = 1;
                                withBlock1.Wrap = word.Word.WdFindWrap.wdFindStop;
                                withBlock1.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
                            }
                            withBlock.Collapse(word.Word.WdCollapseDirection.wdCollapseEnd);
                            withBlock.Find.Execute();
                            /*var colorextract = System.Drawing.ColorTranslator.FromOle((int)withBlock.Font.Color);
                            if (colorextract.Name != "Black")
                            {
                                htmltag = "rgb(" + colorextract.R + "," + colorextract.G + "," + colorextract.B + ");";
                            }
                            colorreplace(withBlock.Font.Color, htmltag, app);
                            {
                                var withBlock1 = withBlock.Duplicate.Find;
                                withBlock1.ClearFormatting();
                                withBlock1.Replacement.ClearFormatting();
                                withBlock1.Font.Color = withBlock.Font.Color;
                                withBlock1.Replacement.Font.Hidden = 1;
                                withBlock1.Wrap = word.Word.WdFindWrap.wdFindStop;
                                withBlock1.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
                            }
                            withBlock.Collapse(word.Word.WdCollapseDirection.wdCollapseEnd);
                            withBlock.Find.Execute();
                            //lngColor = withBlock.Font.TextColor.RGB;
                            /*lngColor = (long)withBlock.Font.Color;
                            switch (withBlock.Font.Fill.ForeColor.Type)
                            {
                                case Microsoft.Office.Core.MsoColorType.msoColorTypeRGB:
                                    {
                                        //StrClr = GetRGB(withBlock.Font.TextColor.RGB);
                                        //htmltag = GetRGB(withBlock.Font.TextColor.RGB);
                                        htmltag = GetRGB((long)withBlock.Font.Color);
                                        break;
                                    }

                                case Microsoft.Office.Core.MsoColorType.msoColorTypeScheme:
                                    {
                                        //StrClr = GetThemeColor(withBlock.Font.TextColor.ObjectThemeColor, app);
                                        //htmltag = GetBasicRGB(withBlock.Font.TextColor.RGB, app);
                                        htmltag = GetBasicRGB((long)withBlock.Font.Color, app);
                                        break;
                                    }

                                default:
                                    {
                                        StrClr = "Other";
                                        break;
                                    }
                            }
                            
                            //StrClrArr = StrClrArr + "\n" + htmltag;
                            colorreplace(withBlock.Font.Color, htmltag, app);
                            {
                                var withBlock1 = withBlock.Duplicate.Find;
                                withBlock1.ClearFormatting();
                                withBlock1.Replacement.ClearFormatting();
                                //withBlock1.Font.TextColor.RGB = (int)lngColor;
                                withBlock1.Font.Color = withBlock.Font.Color;
                                withBlock1.Replacement.Font.Hidden = 1;
                                withBlock1.Wrap = word.Word.WdFindWrap.wdFindStop;
                                withBlock1.Execute(Replace: word.Word.WdReplace.wdReplaceAll);
                            }
                            withBlock.Collapse(word.Word.WdCollapseDirection.wdCollapseEnd);
                            withBlock.Find.Execute();
                        }
                        catch (Exception)
                        {

                        }

                    }*/
                
            }
            
            app.Selection.WholeStory();
            app.Selection.Font.Hidden = 0;
            app.ScreenUpdating = true;
            app.Selection.EndOf();
            // MsgBox "Process Complete"
            // Dim dlgSaveAs As FileDialog
            // Set dlgSaveAs = Application.FileDialog(FileDialogType:=msoFileDialogSaveAs)
            // dlgSaveAs.Show
            // Application.Dialogs(wdDialogFileSaveAs).Show
            string version = app.Version;
            switch (version)
            {
                case "7.0":
                case "8.0":
                case "9.0":
                case "10.0":
                    app.ActiveDocument.SaveAs2000(savename, FileFormat: word.Word.WdSaveFormat.wdFormatXMLDocument, LockComments: false, Password: "", AddToRecentFiles: true, WritePassword: "", ReadOnlyRecommended: false, EmbedTrueTypeFonts: false, SaveNativePictureFormat: false, SaveFormsData: false, SaveAsAOCELetter: false);
                    break;
                case "11.0":
                case "12.0":
                    app.ActiveDocument.SaveAs(savename, FileFormat: word.Word.WdSaveFormat.wdFormatXMLDocument, LockComments: false, Password: "", AddToRecentFiles: true, WritePassword: "", ReadOnlyRecommended: false, EmbedTrueTypeFonts: false, SaveNativePictureFormat: false, SaveFormsData: false, SaveAsAOCELetter: false);
                    break;
                case "14.0":
                case "15.0":
                    app.ActiveDocument.SaveAs2(savename, FileFormat: word.Word.WdSaveFormat.wdFormatXMLDocument, LockComments: false, Password: "", AddToRecentFiles: true, WritePassword: "", ReadOnlyRecommended: false, EmbedTrueTypeFonts: false, SaveNativePictureFormat: false, SaveFormsData: false, SaveAsAOCELetter: false, CompatibilityMode: 15);
                    break;
                default:
                    app.ActiveDocument.SaveAs2(savename, FileFormat: word.Word.WdSaveFormat.wdFormatXMLDocument, LockComments: false, Password: "", AddToRecentFiles: true, WritePassword: "", ReadOnlyRecommended: false, EmbedTrueTypeFonts: false, SaveNativePictureFormat: false, SaveFormsData: false, SaveAsAOCELetter: false, CompatibilityMode: 15);
                    break;
            } 
            //app.ActiveDocument.SaveAs2(savename, FileFormat: word.Word.WdSaveFormat.wdFormatXMLDocument, LockComments: false, Password: "", AddToRecentFiles: true, WritePassword: "", ReadOnlyRecommended: false, EmbedTrueTypeFonts: false, SaveNativePictureFormat: false, SaveFormsData: false, SaveAsAOCELetter: false, CompatibilityMode: 15);
        
        
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Please Close All Word Documents Before Click On Ok Button", "Confirm", MessageBoxButtons.OKCancel);
            Process[] word_apps = Process.GetProcessesByName("winword");
            foreach (var word_app in word_apps)
            {
                word_app.Kill();
            }



            string fpath;
            string inputtext;
            //string ParaText;
            string filename = null;
            String tagcrssentence = string.Empty;
            filename = Path.GetFileName(txtfile.Text);
            fpath = txtfile.Text;
            string fname = Path.GetFileName(fpath);
            string dirpath = Path.GetDirectoryName(fpath);
            bool macrocomplete = false;

            string foutputfile = string.Empty;

            File.SetAttributes(fpath, FileAttributes.Normal);
            word.Word.Application app = new word.Word.Application();
            word.Word.Document doc;
            object missing = Type.Missing;
            object readOnly = false;
            // object 
            doc = app.Documents.Open(fpath, ref missing, ref readOnly, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing, ref missing);


            doc.Activate();
            app.Visible = true;
            asispreprocess(doc,app);
            //bbpdconverter(app);
            
            MessageBox.Show("1");
            app.ActiveDocument.Range().Select();
            MessageBox.Show("01");
            
        }
    }
    public class IniFile
    {
        public IniFile()
        {
        }

        public string inipath;

        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        public IniFile(string filename)
        {
            this.inipath = filename;

        }

        public String readinitag(string section, string key)
        {
            StringBuilder sb = new StringBuilder(255);
            int i = GetPrivateProfileString(section, key, "", sb, 255, System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\settings.ini");
            return sb.ToString();

        }
        public String readlink(string section, string key)
        {
            StringBuilder lk = new StringBuilder(255);
            int i = GetPrivateProfileString(section, key, "", lk, 255, System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\link.ini");
            return lk.ToString();

        }
        public String uploadzipini(string section, string key)
        {
            StringBuilder uz = new StringBuilder(255);
            int i = GetPrivateProfileString(section, key, "", uz, 255, System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\uploadzip.ini");
            return uz.ToString();

        }
        public String readinimetadata(string section, string key)
        {
            StringBuilder sb1 = new StringBuilder(255);
            int i = GetPrivateProfileString(section, key, "", sb1, 255, System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\metdata.ini");
            return sb1.ToString();

        }
        public  string preprocess(string documentlines)
        {
            documentlines = documentlines.Replace(" #", "#");
            //documentlines = documentlines.Replace("    ", " ");
            //documentlines = documentlines.Replace("   ", " ");
            documentlines = documentlines.Replace("  ", " ");
            documentlines = documentlines.Replace("\t\t\t\t\t\t", "\t");
            documentlines = documentlines.Replace("\t\t\t\t\t", "\t");
            documentlines = documentlines.Replace("\t\t\t\t", "\t");
            documentlines = documentlines.Replace("\t\t\t", "\t");
            documentlines = documentlines.Replace("\t\t", "\t");
            documentlines = documentlines.Replace("\v", "\t");
            documentlines = documentlines.Replace("\a", "\t");
            documentlines = documentlines.Replace("#ChapterName# ", "#ChapterName#");
            //documentlines = documentlines.Replace("char(0xF02D)", "chr(0x2d)");
            // documentlines = documentlines.Replace("-" );
            documentlines = documentlines.Replace("#pix# ", "#Pix#");
            documentlines = documentlines.Replace("#pix#", "#Pix#");
            documentlines = documentlines.Replace("#A-Exact#", "#A##A-Exact#");
            documentlines = documentlines.Replace("#A-Case#", "#A##A-Case#");
            documentlines = documentlines.Replace("#A-Order#", "#A##A-Order#");
            documentlines = documentlines.Replace("#A-order#", "#A##A-order#");
            documentlines = documentlines.Replace("#A-strip0#", "#A##A-strip0#");
            //documentlines = documentlines.Replace("#IgnoreCase# #BestVariant-any#", "#A##IgnoreCase# #BestVariant-any#");
            //documentlines = documentlines.Replace("#BestVariant-any#", "#A##BestVariant-any#");
            //documentlines = documentlines.Replace("#IgnoreCase#", "#A##IgnoreCase#");
            //documentlines = documentlines.Replace("#IgnoreMathEval#", "#A##IgnoreMathEval#");
            //documentlines = documentlines.Replace("#AlwaysPunctuation#", "#A##AlwaysPunctuation#");
            //documentlines = documentlines.Replace("#IgnorePunctuation#", "#A##IgnorePunctuation#");
            //documentlines = documentlines.Replace("#AlwaysIgnorePunctuation#", "#A##AlwaysIgnorePunctuation#");
            //documentlines = documentlines.Replace("#IgnoreSpace#", "#A##IgnoreSpace#");
            //documentlines = documentlines.Replace("#AlwaysIgnoreSpace#", "#A##AlwaysIgnoreSpace#");
            //documentlines = documentlines.Replace("#CheckSpace#", "#A##CheckSpace#");
            //documentlines = documentlines.Replace("#AlwaysCheckSpace#", "#A##AlwaysCheckSpace#");
           // documentlines = documentlines.Replace("#A-SameRules#", "#A##A-SameRules#");
            //documentlines = documentlines.Replace("#A-Math#", "#A##A-Math#");
            //documentlines = documentlines.Replace("#AlwaysIgnoreTrailing0#", "#A##AlwaysIgnoreTrailing0#");
            //documentlines = documentlines.Replace("#CheckTrailing0#", "#A##CheckTrailing0#");
            //documentlines = documentlines.Replace("#AlwaysCheckTrailing0#", "#A##AlwaysCheckTrailing0#");
            //documentlines = documentlines.Replace("#IgnoreTrailing0#", "#A##IgnoreTrailing0#");
            //documentlines = documentlines.Replace("#AlwaysMathEval#", "#A##AlwaysMathEval#");
            //documentlines = documentlines.Replace("#IgnoreTrailing0#", "#A##IgnoreTrailing0#");
           // documentlines = documentlines.Replace("#CheckMathEval#", "#A##CheckMathEval#");
           // documentlines = documentlines.Replace("#IgnoreTrailing0#", "#A##IgnoreTrailing0#");
            //documentlines = documentlines.Replace("#CheckMathEval#", "#A##CheckMathEval#");
           // documentlines = documentlines.Replace("#IgnoreTrailing0#", "#A##IgnoreTrailing0#");
            //documentlines = documentlines.Replace("#IgnoreMathEval#", "#A##IgnoreMathEval#");
          //  documentlines = documentlines.Replace("#AlwaysIgnoreMathEval#", "#A##AlwaysIgnoreMathEval#");
           // documentlines = documentlines.Replace("#AlwaysCheckMathEval#", "#A##AlwaysCheckMathEval#");
            documentlines = documentlines.Replace("#A#", "#A# ");
            documentlines = documentlines.Replace("#A#  ", "#A# ");
            documentlines = documentlines.Replace("#instruction#", "#Instruction#");
            documentlines = documentlines.Replace("#Instruction#", "#Instruction# ");
            documentlines = documentlines.Replace("#Instruction#  ", "#Instruction# ");
           // documentlines = documentlines.Replace("\v(a)", "\t(a)");
           // documentlines = documentlines.Replace("\v(b)", "\t(b)");
           // documentlines = documentlines.Replace("\v(c)", "\t(c)");
           // documentlines = documentlines.Replace("\v(d)", "\t(d)");
           // documentlines = documentlines.Replace("\r\r\r\r\r\r", "\r");
            documentlines = documentlines.Replace("–", "-");
            documentlines = documentlines.Replace("—", "-");
            documentlines = documentlines.Replace("‐", "-");
            documentlines = documentlines.Replace("\r\r\r\r\r\r\r\r\r\r", "\r");
            documentlines = documentlines.Replace("\r\r\r\r\r\r\r\r\r", "\r");
            documentlines = documentlines.Replace("\r\r\r\r\r\r\r\r", "\r");
            documentlines = documentlines.Replace("\r\r\r\r\r\r\r", "\r");
            documentlines = documentlines.Replace("\r\r\r\r\r\r", "\r");
            documentlines = documentlines.Replace("\r\r\r\r\r", "\r");
            documentlines = documentlines.Replace("\r\r\r\r", "\r");
            documentlines = documentlines.Replace("\r\r\r", "\r");
            documentlines = documentlines.Replace("\r\r", "\r");
            documentlines = documentlines.Replace("\r\f\r", "\r");
            documentlines = documentlines.Replace("\f\r", "\r");
            documentlines = documentlines.Replace("\r\a\r\a", "\r\a");
            documentlines = documentlines.Replace("\r\a", "\r");
            documentlines = documentlines.Replace("\r\t\r\t", "\r\t");
            documentlines = documentlines.Replace("\r\t", "\r");
            
           documentlines = documentlines.Replace("\r", "\r\n");
           documentlines = documentlines.Replace("\r\n \r\n", "\r\n\r\n");
            documentlines = documentlines.Replace("\r\n#A#", "\t#A#");

          //documentlines = documentlines.ToLower().Replace("#asisend#", "\r\n"+"#asisend#");
           
          //  documentlines = documentlines.Replace("&", " OR ");
          //  documentlines = documentlines.Replace("*", " ");
           // documentlines = documentlines.Replace("  *  ", " ");        
           // documentlines = documentlines.Replace("  OR  ", " OR ");
            return documentlines.ToString();
        }

        public string mcqpreprocess(string mclines)
        {
            mclines = mclines.Replace("1.\t", "1. ");
            mclines = mclines.Replace("2.\t", "2. ");
            mclines = mclines.Replace("3.\t", "3. ");
            mclines = mclines.Replace("4.\t", "4. ");
            mclines = mclines.Replace("5.\t", "5. ");
            mclines = mclines.Replace("6.\t", "6. ");
            mclines = mclines.Replace("7.\t", "7. ");
            mclines = mclines.Replace("8.\t", "8. ");
            mclines = mclines.Replace("9.\t", "9. ");
            mclines = mclines.Replace("10.\t","10. ");

            if (mclines.StartsWith("a.\t"))
            {
                mclines = mclines.Replace("a.\t", "a. ");
            }
            if (mclines.StartsWith("b.\t"))
            {
                mclines = mclines.Replace("b.\t", "b. ");
            }
            if (mclines.StartsWith("c.\t"))
            {
                 mclines = mclines.Replace("c.\t", "c. ");
            }
            if (mclines.StartsWith("d.\t"))
            { 
                mclines = mclines.Replace("d.\t", "d. ");
            }
            if (mclines.StartsWith("e.\t"))
            {
                mclines = mclines.Replace("e.\t", "e. ");
            }
            if (mclines.StartsWith("f.\t"))
            {
                mclines = mclines.Replace("f.\t", "f. ");
            }
            if (mclines.StartsWith("g.\t"))
            {
                mclines = mclines.Replace("g.\t", "g. ");
            }
            if (mclines.StartsWith("h.\t"))
            {
                mclines = mclines.Replace("h.\t", "h. ");
            }
            if (mclines.StartsWith("i.\t"))
            {
                mclines = mclines.Replace("i.\t", "i. ");
            }
            if (mclines.StartsWith("j.\t"))
            {
                mclines = mclines.Replace("j.\t", "j. ");
            }
            /*mclines = mclines.Replace("A.\t", "A. ");
            mclines = mclines.Replace("B.\t", "B. ");
            mclines = mclines.Replace("C.\t", "C. ");
            mclines = mclines.Replace("D.\t", "D. ");
            mclines = mclines.Replace("E.\t", "E. ");
            mclines = mclines.Replace("F.\t", "F. ");
            mclines = mclines.Replace("G.\t", "G. ");
            mclines = mclines.Replace("H.\t", "H. ");
            mclines = mclines.Replace("I.\t", "I. ");
            mclines = mclines.Replace("J.\t", "J. ");

            mclines = mclines.Replace("I.\t", "I. ");
            mclines = mclines.Replace("II.\t", "II. ");
            mclines = mclines.Replace("III.\t", "III. ");
            mclines = mclines.Replace("IV.\t", "IV. ");
            mclines = mclines.Replace("V.\t", "V. ");
            mclines = mclines.Replace("VI.\t", "VI. ");
            mclines = mclines.Replace("VII.\t", "VII. ");
            mclines = mclines.Replace("VIII.\t", "VIII. ");
            mclines = mclines.Replace("IX.\t", "IX. ");
            mclines = mclines.Replace("X.\t", "X. ");

            mclines = mclines.Replace("i.\t", "i. ");
            mclines = mclines.Replace("ii.\t", "ii. ");
            mclines = mclines.Replace("III.\t", "III. ");
            mclines = mclines.Replace("iii.\t", "iii. ");
            mclines = mclines.Replace("iv.\t", "iv. ");
            mclines = mclines.Replace("v.\t", "v. ");
            mclines = mclines.Replace("vi.\t", "vi. ");
            mclines = mclines.Replace("vii.\t", "vii. ");
            mclines = mclines.Replace("viii.\t", "viii. ");
            mclines = mclines.Replace("ix.\t", "ix. ");
            mclines = mclines.Replace("x.\t", "x. ");*/

            return mclines.ToString();
        }

      /*public string uploadtextfile(string filename, string classname, string subject)
        {
            try
            {
                bool internetavailable = false;
                internetavailable = CheckForInternetConnection();
                if (internetavailable)
                {
                    System.Net.WebClient Client = new System.Net.WebClient();
                    System.Collections.Specialized.NameValueCollection parameters = new System.Collections.Specialized.NameValueCollection();
                    parameters.Add("classname", classname);
                    parameters.Add("subject", subject);
                    Client.QueryString = parameters;

                    Client.Headers.Add("Content-Type", "binary/octet-stream");
                    IniFile ini = new IniFile(inipath);
                    string site = ini.readlink("LinkInfo", "Link");
                    string weblink = site + "/bbpd/upload/uploadtextfile.php";
                
                   // byte[] result = Client.UploadFile("https://halantbooks.com/bbpd/upload/uploadtextfile.php", "POST",
                                       //               filename);

                    byte[] result = Client.UploadFile(weblink, "POST",
                                                      filename);
                    //http://localhost:1234/bbpd_forms_project/newupload/uploadtextfile.php
                    string s = System.Text.Encoding.UTF8.GetString(result, 0, result.Length);
                    string matchsuccess = Path.GetFileNameWithoutExtension(filename) + ".php success";
                    if (s == matchsuccess)
                    {
                        return "success";
                    }
                    else
                    {
                        return "failure";
                    }
                }
                else
                {
                    MessageBox.Show("Please check your internet connection.");
                    return "failure";
                }



            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not reach the site.");
                return "failure";
            }
        }*/
        public string uploadtextfile(string filename, string classname, string subject)
        {
            bool internetavailable = false;
            internetavailable = CheckForInternetConnection();
            if (internetavailable)
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                System.Net.WebClient Client = new System.Net.WebClient();
                System.Collections.Specialized.NameValueCollection parameters = new System.Collections.Specialized.NameValueCollection();
                string sub = subject.Trim();
                string classn = classname.Trim();
                parameters.Add("classname", classn);
                parameters.Add("subject", sub);
                Client.QueryString = parameters;
                Client.Headers.Add("Content-Type", "binary/octet-stream");
                string linkini = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\link.ini";
                IniFile ini = new IniFile(linkini);
                string site = ini.readlink("LinkInfo", "Link");
                string weblink = site + "/uploadtextfile.php";
                byte[] result = Client.UploadFile(weblink, "POST",
                                                  filename);//"https://halantbooks.com/bbpd/newupload/upload/uploadtextfile.php"
                string s = System.Text.Encoding.UTF8.GetString(result, 0, result.Length);
                string matchsuccess = Path.GetFileNameWithoutExtension(filename) + ".php success";
                if (s == matchsuccess)
                {
                    return "success";
                }
                else
                {
                    return "failure";
                }
            }
            else
            {
                MessageBox.Show("Please check your internet connection.");
                return "failure";
            }
        }

        public static bool CheckForInternetConnection()
        {
            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                string linkini = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\link.ini";
                IniFile ini = new IniFile(linkini);
                string site = ini.readlink("LinkInfo", "Link");
                string weblink = site;
                  using (var client = new System.Net.WebClient())

                //using (client.OpenRead("https://halantbooks.com/bbpd/upload"))

                  using (client.OpenRead(weblink));
                    return true;
            }
            //http://google.com/generate_204
            catch
            {
                return false;
            }
        }

        public string uploadzipfile(string filename, string classname, string subject)
        {
            try
            {
                bool internetavailable = false;
                internetavailable = CheckForInternetConnection();
                if (internetavailable)
                {
                    ServicePointManager.Expect100Continue = true;
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    System.Net.WebClient Client = new System.Net.WebClient();
                    System.Collections.Specialized.NameValueCollection parameters = new System.Collections.Specialized.NameValueCollection();
                    string sub = subject.Trim();
                    string classn = classname.Trim();
                    parameters.Add("classname", classn);
                    parameters.Add("subject", sub);
                    Client.QueryString = parameters;
                    Client.Headers.Add("Content-Type", "binary/octet-stream");
                    string linkini = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\link.ini";
                    IniFile ini = new IniFile(linkini);
                    string site = ini.readlink("LinkInfo", "Link");
                    string weblink = site + "/uploadzipfile.php";

                    // byte[] result = Client.UploadFile("https://halantbooks.com/bbpd/upload/uploadzipfile.php", "POST",
                    //filename);
                    byte[] result = Client.UploadFile(weblink, "POST",
                    filename);
                    string s = System.Text.Encoding.UTF8.GetString(result, 0, result.Length);
                    if (s == "success")
                    {
                        return "success";
                    }
                    else
                    {
                        return "failure";
                    }
                }
                else {
                    MessageBox.Show("Please check your internet connection.");
                    return "failure";
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not reach the site.");
                return "failure";
            }
        }

        public string getimagename(string line)
        {
            string imagename = "";
            string[] lines_array = line.Split(new[] { "#Pix#" }, StringSplitOptions.None);
            int lines_array_count = lines_array.Length;
            if (lines_array_count > 1)
            {
                for (int i = 1; i < lines_array_count; i++)
                {
                    if (lines_array[i] != null && lines_array[i] != "" && lines_array[i] != " " && lines_array[i] != "  ")
                    {
                        char[] delimiterChars = { ' ', ',', '.', ':','\t'  };
                        string[] splitbyspace = lines_array[i].Split(delimiterChars);
                        for (int j = 0; j < splitbyspace.Length; j++)
                        {
                            if (splitbyspace[j] != null && splitbyspace[j] != "" && splitbyspace[j] != " " && splitbyspace[j] != "  ")
                            {
                                imagename = splitbyspace[j];
                               
                                if(imagename.Contains("#"))
                                {
                                    string[] splitbyhash = imagename.Split(new[] { "#" }, StringSplitOptions.None);
                                    imagename = splitbyhash[0];
                                }
                                if (imagename.Contains("\t("))
                                {

                                    imagename = imagename.Replace("\t(", "\t (");
                                }
                                break;
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            else
            {
                return "";
            }

            return imagename;
        }

        public int asisparent(string parent) {
            // 2 = asis
            // 1 = some other tag
            // 3 = don't know - do recursive
            if (!parent.ToLower().Contains("#Instruction#"))
            {
                if (!parent.ToLower().Contains("#Columns"))
                {
                    if (!parent.ToLower().Contains("#Type"))
                    {
                        if (parent.ToLower().Contains("#Asis#".ToLower()))
                        {
                            // send for conversion
                            return 2;
                        }
                        else if (parent.ToLower().Contains("\r".ToLower()) || parent.ToLower().Contains("\r\n".ToLower()) || parent.ToLower().Contains("\n\r".ToLower()) || parent.ToLower().Contains("\t".ToLower()) || parent.ToLower().Contains("\n".ToLower()) || parent.ToLower().Contains("\v".ToLower()))
                        {
                            return 3;
                        }
                        else {
                            return 1;
                        }
                    }
                    else
                    {
                        return 1;
                    }
                }
                else
                {
                    return 1;
                }
            }
            else {
                return 1;
            }
        }

        public void convertasis(word.Word.Document doc)
        {
            List<word.Word.Range> TablesRanges = new List<word.Word.Range>();
            for (int iCounter = 1; iCounter <= doc.Tables.Count; iCounter++)
            {
                word.Word.Range TRange = doc.Tables[iCounter].Range;
                TablesRanges.Add(TRange);
                int parentcounter = 1;
                var parent = doc.Tables[iCounter].Range.Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 1).Text; //Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, 2).Text;

                if (asisparent(parent) == 2)
                {
                    // asis = convert to tables
                    parentcounter = 1;
                    int rowcount = doc.Tables[iCounter].Rows.Count;
                    int columncount = doc.Tables[iCounter].Columns.Count;
                    for (var rowcounter = 1; rowcounter <= rowcount; rowcounter++)
                    {
                        for (var columncounter = 1; columncounter <= columncount; columncounter++)
                        {
                            if (rowcounter == 1 && columncounter == 1)
                            {
                                doc.Tables[iCounter].Cell(rowcounter, columncounter).Range.InsertBefore("<table style='width:100%;table-layout:fixed;'><tr><td>");
                            }
                            else if (columncounter == 1)
                            {
                                doc.Tables[iCounter].Cell(rowcounter, columncounter).Range.InsertBefore("<tr><td>");
                            }
                            else
                            {
                                doc.Tables[iCounter].Cell(rowcounter, columncounter).Range.InsertBefore("<td>");
                            }
                            doc.Tables[iCounter].Cell(rowcounter, columncounter).Range.InsertAfter("</td>");
                        }
                        doc.Tables[iCounter].Cell(rowcounter, columncount).Range.InsertAfter("</tr>");
                    }
                    doc.Tables[iCounter].Cell(rowcount, columncount).Range.InsertAfter("</table>");
                    string content = doc.Tables[iCounter].ConvertToText(word.Word.WdSeparatorType.wdSeparatorHyphen).Text;
                }
                else if (asisparent(parent) == 1)
                {
                    // no need to do anything
                    parentcounter = 1;
                }
                else if (asisparent(parent) == 3)
                {
                    // send parent of parent
                    parentcounter++;
                    if (parentcounter > 0 && parentcounter < 10)
                    {
                        parent = doc.Tables[iCounter].Range.Previous(Microsoft.Office.Interop.Word.WdUnits.wdParagraph, parentcounter).Text;
                    }
                }


            }
        }

        // Bold, italic format of word

       /* public void wordtohtml(word.Word.Document doc)
        {
            foreach (word.Word.Paragraph objparagraph in doc.Paragraphs)
            {
                int TRUE_CODE = -1;
                bool bold_found = false;
                bool italicfound = false;
                Microsoft.Office.Interop.Word.Range rWords = objparagraph.Range;
                foreach (Microsoft.Office.Interop.Word.Range word in rWords.Words)
                {
                    // sequence of if is important for closing the tags if word is bold and italics together
                    if (italicfound)
                    {
                        word.InsertBefore("</span>");
                        italicfound = false;
                        continue;
                    }
                    if (bold_found)
                    {
                        word.InsertBefore("</span>");
                        bold_found = false;
                        continue;
                    }
                    if (word.Bold == TRUE_CODE)
                    {
                        // handle bold cse
                        word.InsertBefore("<span style='font-style:bold;'>");
                        bold_found = true;
                    }
                    if (word.Italic == TRUE_CODE)
                    {
                        // handle italic case
                        word.InsertBefore("<span style='font-style:italics;'>");
                        italicfound = true;
                    }
                }
            }
            MessageBox.Show("Conversion complete");
        }*/

       // public String wordpreprocess(string doc)
       // {

            //Microsoft.Office.Interop.Word.Find fnd = app.ActiveWindow.Selection.Find;
            
           // return doc.ToString();
       // }



    }
    

    }

